import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { CalendarEvent, GenericFormModalProps, SystemOptions } from '../../types';
import { CALENDAR_EVENT_TYPE_OPTIONS as constantCalendarEventTypes, CALENDAR_EVENT_COLOR_OPTIONS } from '../../constants';

interface AddEventModalProps extends GenericFormModalProps<CalendarEvent> {
    systemOptions?: SystemOptions;
}

const AddEventModal: React.FC<AddEventModalProps> = ({ isOpen, onClose, onSave, existingItem, systemOptions, addToast }) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];

  // Get a safe array for event types from system or constants, default to empty array if both somehow fail
  const safeEventTypeOptionsProvider = (systemOptions?.calendarEventTypes || constantCalendarEventTypes) || [];

  // Use this safe array to derive the default event type
  const defaultEventType = safeEventTypeOptionsProvider[0]?.value || 'reminder';

  const initialEventState: Omit<CalendarEvent, 'id'> = {
    title: '',
    date: getTodayDateString(),
    startTime: '',
    endTime: '',
    type: defaultEventType,
    description: '',
    color: 'blue',
  };

  const [event, setEvent] = useState<Omit<CalendarEvent, 'id'>>(initialEventState);

  useEffect(() => {
    // Recalculate defaultEventType inside useEffect if systemOptions might change during component lifecycle affecting it
    // For now, defaultEventType derived above is sufficient for initialization logic.
    const currentDefaultEventType = ((systemOptions?.calendarEventTypes || constantCalendarEventTypes) || [])[0]?.value || 'reminder';

    if (isOpen) { 
        if (existingItem) {
          setEvent({
            title: existingItem.title || '',
            date: existingItem.date ? new Date(existingItem.date).toISOString().split('T')[0] : getTodayDateString(),
            startTime: existingItem.startTime || '',
            endTime: existingItem.endTime || '',
            type: existingItem.type || currentDefaultEventType,
            description: existingItem.description || '',
            color: existingItem.color || 'blue',
            relatedId: existingItem.relatedId || undefined,
          });
        } else {
          // Re-initialize with potentially updated defaultEventType if modal reopens for a new item
          const newInitialState: Omit<CalendarEvent, 'id'> = {
            title: '',
            date: existingItem?.date ? new Date(existingItem.date).toISOString().split('T')[0] : getTodayDateString(), // Use existingItem's date if pre-filled by date click
            startTime: '',
            endTime: '',
            type: existingItem?.type || currentDefaultEventType, // Use existingItem's type if pre-filled
            description: '',
            color: 'blue',
          };
          setEvent(newInitialState);
        }
    }
  }, [existingItem, isOpen, systemOptions?.calendarEventTypes]); // Listen to systemOptions change for default type


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setEvent(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    if (!event.title || !event.date) {
      if (addToast) {
        addToast('Judul Acara dan Tanggal harus diisi.', 'error');
      } else {
        alert('Judul Acara dan Tanggal harus diisi.');
      }
      return;
    }
    onSave({
      id: existingItem?.id || `event-${Date.now().toString()}`,
      ...event,
    } as CalendarEvent);
    onClose();
  };
  
  const typeOptions = safeEventTypeOptionsProvider.map(opt => ({ value: opt.value, label: opt.label}));
  const colorOptions = CALENDAR_EVENT_COLOR_OPTIONS.map(opt => ({ value: opt.value, label: opt.label}));


  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={existingItem?.id ? "Edit Acara Kalender" : "Tambah Acara Baru ke Kalender"}
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>{existingItem?.id ? "Simpan Perubahan" : "Simpan Acara"}</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-6">
        {existingItem?.id ? "Ubah detail acara di bawah ini." : "Masukkan detail acara baru di bawah ini."}
      </p>
      <div className="space-y-4">
        <Input label="Judul Acara*" name="title" value={event.title} onChange={handleChange} placeholder="Contoh: Meeting Klien A" />
        <Input label="Tanggal Acara*" name="date" type="date" value={event.date} onChange={handleChange} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Waktu Mulai (Opsional)" name="startTime" type="time" value={event.startTime} onChange={handleChange} />
            <Input label="Waktu Selesai (Opsional)" name="endTime" type="time" value={event.endTime} onChange={handleChange} />
        </div>
        <Select label="Jenis Acara" name="type" value={event.type} onChange={handleChange} options={typeOptions} />
        <Select label="Warna Label Acara" name="color" value={event.color} onChange={handleChange} options={colorOptions} />
        <TextArea label="Deskripsi (Opsional)" name="description" value={event.description} onChange={handleChange} rows={3} placeholder="Detail tambahan mengenai acara..." />
      </div>
    </Modal>
  );
};

export default AddEventModal;