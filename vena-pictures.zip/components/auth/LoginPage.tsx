
import React, { useState } from 'react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { BuildingOfficeIcon } from '../../constants';
import { LoginPageProps } from '../../types';

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess, addToast }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(''); 

    if (username === 'admin' && password === 'password') {
      onLoginSuccess();
    } else {
      setError('Username atau password salah. Silakan coba lagi.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center items-center mb-6">
          <div className="p-3 bg-gray-800 rounded-xl shadow-lg">
            <BuildingOfficeIcon className="h-10 w-10 text-white" />
          </div>
        </div>
        <h2 className="text-center text-3xl font-bold tracking-tight text-gray-900">
          Login ke Vena Pictures
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Masukkan kredensial Anda untuk melanjutkan.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-xl rounded-xl sm:px-10 border border-gray-200">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <Input
              id="username"
              name="username"
              type="text"
              label="Username"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="admin"
            />

            <Input
              id="password"
              name="password"
              type="password"
              label="Password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password"
            />
            
            {error && (
                <div className="bg-gray-700 p-3 rounded-md border border-gray-600">
                    <p className="text-sm text-white">{error}</p>
                </div>
            )}

            <div>
              <Button type="submit" variant="primary" fullWidth>
                Login
              </Button>
            </div>
          </form>
           <p className="mt-6 text-center text-xs text-gray-500">
            Demo: Gunakan <code className="bg-gray-200 p-1 rounded text-gray-700">admin</code> / <code className="bg-gray-200 p-1 rounded text-gray-700">password</code>
          </p>
        </div>
      </div>
       <footer className="mt-12 text-center text-xs text-gray-500">
          &copy; {new Date().getFullYear()} Vena Pictures.
        </footer>
    </div>
  );
};

export default LoginPage;