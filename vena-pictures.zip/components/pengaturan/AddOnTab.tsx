
import React, { useState } from 'react';
import { AddOn, Currency, GlobalSettingsTabProps, ToastMessage } from '../../types';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Table from '../ui/Table';
import { PlusCircleIcon, PencilSquareIcon, TrashIcon } from '../../constants';
import AddAddOnModal from './AddAddOnModal';

interface AddOnTabContentProps extends GlobalSettingsTabProps<AddOn> {
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

const AddOnTab: React.FC<AddOnTabContentProps> = ({ items: addOns, onAddItem, onUpdateItem, onDeleteItem, addToast }) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingAddOn, setEditingAddOn] = useState<AddOn | null>(null);

  const handleSaveAddOn = (addOn: AddOn) => {
    if (editingAddOn) {
        onUpdateItem(addOn);
    } else {
        const { id, ...addOnData } = addOn;
        onAddItem(addOnData);
    }
    setEditingAddOn(null);
  };

  const openEditModal = (addOn: AddOn) => {
    setEditingAddOn(addOn);
    setIsAddModalOpen(true);
  };

  const handleDeleteAddOn = (addOnId: string) => {
    if (window.confirm("Apakah Anda yakin ingin menghapus add-on ini?")) {
        onDeleteItem(addOnId);
    }
  };

  const columns = [
    { key: 'name', header: 'Nama Add-On', render: (addon:AddOn) => <span className="font-medium">{addon.name}</span> },
    { key: 'price', header: 'Harga', render: (addon: AddOn) => `${Currency.IDR} ${addon.price.toLocaleString('id-ID')}` },
    { key: 'unit', header: 'Unit', render: (addon: AddOn) => addon.unit || '-' },
    { key: 'description', header: 'Deskripsi', render: (addon: AddOn) => addon.description || '-' },
    {
      key: 'actions',
      header: 'Aksi',
      render: (addon: AddOn) => (
        <div className="flex space-x-1">
          <Button variant="ghost" size="sm" onClick={() => openEditModal(addon)}><PencilSquareIcon className="w-4 h-4 text-blue-600" /></Button>
          <Button variant="ghost" size="sm" onClick={() => handleDeleteAddOn(addon.id)}><TrashIcon className="w-4 h-4 text-red-500" /></Button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-end items-center">
        <Button onClick={() => {setEditingAddOn(null); setIsAddModalOpen(true);}} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
          Tambah Add-On
        </Button>
      </div>
      
      <Card title="Daftar Add-On">
        <p className="text-sm text-gray-500 mb-4">Kelola add-on yang tersedia untuk paket fotografi.</p>
        <Table columns={columns} data={addOns} rowKey="id"/>
      </Card>
      
      <AddAddOnModal 
        isOpen={isAddModalOpen} 
        onClose={() => { setIsAddModalOpen(false); setEditingAddOn(null);}}
        onSave={handleSaveAddOn}
        existingAddOn={editingAddOn}
        addToast={addToast} // Pass addToast to the modal
      /> 
    </div>
  );
};

export default AddOnTab;
