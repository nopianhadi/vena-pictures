
import React from 'react';
import { ToastMessage } from '../../types';
import { CheckCircleIcon, XCircleIcon, InformationCircleIcon, BellAlertIcon as WarningIcon, XMarkIcon } from '../../constants';

interface ToastMessageDisplayProps {
  toast: ToastMessage;
  onDismiss: (id: string) => void;
}

const ToastMessageDisplay: React.FC<ToastMessageDisplayProps> = ({ toast, onDismiss }) => {
  const getIcon = () => {
    // Icon colors are updated to reflect monochrome theme emphasis
    switch (toast.type) {
      case 'success': return <CheckCircleIcon className="w-5 h-5 text-gray-700" />; // Darker icon for light bg
      case 'error': return <XCircleIcon className="w-5 h-5 text-white" />;      // White icon for dark bg
      case 'info': return <InformationCircleIcon className="w-5 h-5 text-gray-700" />; // Darker icon
      case 'warning': return <WarningIcon className="w-5 h-5 text-gray-700" />;     // Darker icon
      default: return null;
    }
  };

  const getStyles = () => {
    let baseStyle = "shadow-lg rounded-lg pointer-events-auto ring-1 ring-black ring-opacity-5 overflow-hidden border mb-3";
    // Monochrome toast styles
    switch (toast.type) {
      case 'success': return `${baseStyle} bg-gray-100 border-gray-300 text-gray-700`; // Light gray, dark text
      case 'error': return `${baseStyle} bg-black border-gray-800 text-white`;         // Black, white text
      case 'info': return `${baseStyle} bg-gray-200 border-gray-400 text-gray-800`;    // Medium gray, dark text
      case 'warning': return `${baseStyle} bg-gray-300 border-gray-500 text-gray-800`;  // Slightly darker gray, dark text
      default: return `${baseStyle} bg-gray-100 border-gray-300 text-gray-700`;
    }
  };

  return (
    <div
      className={`max-w-sm w-full ${getStyles()} animate-fadeIn`}
      role="alert"
    >
      <div className="p-3">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            {getIcon()}
          </div>
          <div className="ml-2 w-0 flex-1 pt-0.5">
            <p className="text-sm font-medium">{toast.message}</p>
          </div>
          <div className="ml-3 flex-shrink-0 flex">
            <button
              onClick={() => onDismiss(toast.id)}
              className="bg-transparent rounded-md inline-flex text-current hover:opacity-75 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-gray-500 p-0.5" // Adjusted focus ring
            >
              <span className="sr-only">Close</span>
              <XMarkIcon className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};


interface ToastContainerProps {
  toasts: ToastMessage[];
  removeToast: (id: string) => void;
}

const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, removeToast }) => {
  return (
    <div
      aria-live="assertive"
      className="fixed inset-0 flex items-end px-4 py-6 pointer-events-none sm:p-6 sm:items-start z-[200]"
    >
      <div className="w-full flex flex-col items-center space-y-2 sm:items-end">
        {toasts.map((toast) => (
          <ToastMessageDisplay key={toast.id} toast={toast} onDismiss={removeToast} />
        ))}
      </div>
    </div>
  );
};

export default ToastContainer;