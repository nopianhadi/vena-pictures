
import React, { Fragment } from 'react';
import { XMarkIcon } from '../../constants';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: React.ReactNode; 
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl' | '5xl';
  footer?: React.ReactNode;
  headerActions?: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, size = 'md', footer, headerActions }) => {
  if (!isOpen) return null;

  const sizeClasses = {
    sm: 'sm:max-w-sm',
    md: 'sm:max-w-md',
    lg: 'sm:max-w-lg',
    xl: 'sm:max-w-xl',
    '2xl': 'sm:max-w-2xl',
    '3xl': 'sm:max-w-3xl',
    '4xl': 'sm:max-w-4xl',
    '5xl': 'sm:max-w-5xl',
  };

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/75 backdrop-blur-sm transition-opacity duration-300 ease-in-out px-2 sm:px-4" // Darker overlay
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title-wrapper"
    >
      <div
        className={`bg-white rounded-xl shadow-2xl transform transition-all sm:my-8 w-full ${sizeClasses[size]} m-2 sm:m-4 flex flex-col max-h-[90vh] border border-gray-300`} // Monochrome border
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 sm:px-6 py-3 sm:py-4 border-b border-gray-200"> {/* Adjusted padding, monochrome border */}
          {typeof title === 'string' ? (
            <h3 id="modal-title" className="text-lg sm:text-xl font-semibold leading-6 text-gray-800">{title}</h3> // Adjusted font size
          ) : (
            <div id="modal-title-wrapper" className="text-lg sm:text-xl font-semibold leading-6 text-gray-800">{title}</div> // Adjusted font size
          )}
          <div className="flex items-center space-x-1 sm:space-x-2">
            {headerActions}
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-full hover:bg-gray-100"
              aria-label="Close modal"
            >
              <XMarkIcon className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="px-4 sm:px-6 py-4 sm:py-5 overflow-y-auto flex-grow custom-scrollbar"> {/* Adjusted padding */}
          {children}
        </div>
        {footer && (
          <div className="px-4 sm:px-6 py-3 sm:py-4 bg-gray-50 border-t border-gray-200 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 rounded-b-xl"> {/* Monochrome footer bg & border */}
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};

export default Modal;
