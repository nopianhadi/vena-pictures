
import React from 'react';

type BadgeColor = 'green' | 'yellow' | 'red' | 'blue' | 'gray' | 'indigo' | 'purple'; 

interface BadgeProps {
  text: string;
  color?: BadgeColor;
  size?: 'sm' | 'md';
  className?: string;
}

const Badge: React.FC<BadgeProps> = ({ text, color = 'gray', size = 'sm', className = '' }) => {
  // Monochrome color mapping
  // Using Tailwind's gray scale for consistency, adjust if needed.
  const monochromeColorClasses: Record<BadgeColor, string> = {
    green: 'bg-gray-700 text-white',      // Was green, now dark gray with white text (e.g., for "Paid", "Completed")
    yellow: 'bg-gray-300 text-gray-800',   // Was yellow, now light gray (e.g., for "Pending", "Unpaid")
    red: 'bg-black text-white',           // Was red, now black with white text (e.g., for "Cancelled", "Overdue")
    blue: 'bg-gray-600 text-white',       // Was blue/indigo, now medium-dark gray (e.g., "In Progress", "Partial", "Sent")
    gray: 'bg-gray-200 text-gray-700',    // Default gray
    indigo: 'bg-gray-600 text-white',     // Map indigo to a medium-dark gray
    purple: 'bg-gray-500 text-white',     // Map purple to another shade of gray
  };

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs', // Poppins might need slightly larger base size for xs
    md: 'px-2.5 py-0.5 text-sm',
  };

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full ${sizeClasses[size]} ${monochromeColorClasses[color]} ${className}`}
    >
      {text}
    </span>
  );
};

export default Badge;
