
import React, { useState } from 'react';
import { TabItem } from '../../types';


interface TabsProps {
  tabs: TabItem[];
  initialTabId?: string;
  onTabChange?: (tabId: string) => void;
}

const Tabs: React.FC<TabsProps> = ({ tabs, initialTabId, onTabChange }) => {
  const [activeTab, setActiveTab] = useState(initialTabId || (tabs.length > 0 ? tabs[0].id : ''));

  const handleTabClick = (tabId: string) => {
    setActiveTab(tabId);
    if (onTabChange) {
      onTabChange(tabId);
    }
  };

  const activeTabContent = tabs.find(tab => tab.id === activeTab)?.content;

  return (
    <div>
      <div className="border-b border-gray-200"> {/* Monochrome border */}
        <nav className="-mb-px flex space-x-6 sm:space-x-8" aria-label="Tabs"> {/* Adjusted space for Poppins */}
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.id)}
              className={`whitespace-nowrap pb-3 pt-1 px-1 border-b-2 font-medium text-sm transition-colors duration-150
                ${activeTab === tab.id
                  ? 'border-gray-700 text-gray-800' // Monochrome active
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' // Monochrome hover
                }`}
              aria-current={activeTab === tab.id ? 'page' : undefined}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
      <div key={activeTab} className="mt-5 sm:mt-6 animate-fadeIn"> {/* Adjusted margin for Poppins */}
        {activeTabContent}
      </div>
    </div>
  );
};

export default Tabs;
