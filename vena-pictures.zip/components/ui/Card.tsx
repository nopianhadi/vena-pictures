
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  titleAction?: React.ReactNode;
  onClick?: () => void;
  titleClassName?: string;
  contentClassName?: string;
}

const Card: React.FC<CardProps> = ({ 
  children, 
  className = '', 
  title, 
  titleAction, 
  onClick, 
  titleClassName = '', 
  contentClassName 
}) => {
  // Default content padding, can be overridden by contentClassName
  const finalContentClassName = contentClassName !== undefined ? contentClassName : (title ? 'p-4 sm:p-5' : 'p-4 sm:p-5');

  return (
    <div 
      className={`bg-white shadow-md rounded-xl border border-gray-200 ${className} ${onClick ? 'cursor-pointer transition-all duration-150 ease-in-out hover:shadow-lg hover:border-gray-300' : ''}`} // Monochrome: bg-white, border-gray-200, hover:border-gray-300
      onClick={onClick}
    >
      {title && (
        <div className={`px-4 sm:px-5 py-3 border-b border-gray-200 flex justify-between items-center ${titleClassName}`}> {/* Adjusted padding, monochrome border */}
          <h3 className="text-base md:text-lg leading-6 font-semibold text-gray-800">{title}</h3> {/* Adjusted font size & color */}
          {titleAction && <div>{titleAction}</div>}
        </div>
      )}
      <div className={finalContentClassName}>
         {children}
      </div>
    </div>
  );
};

export default Card;
