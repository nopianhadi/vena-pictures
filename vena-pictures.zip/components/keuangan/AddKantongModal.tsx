import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { Kantong, Currency, KantongType, SystemOptions, ToastMessage } from '../../types'; // Added SystemOptions, ToastMessage

interface AddKantongModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (kantong: Kantong) => void;
  existingKantong?: Kantong | null;
  systemOptions?: SystemOptions; // Added for kantong type options
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

const AddKantongModal: React.FC<AddKantongModalProps> = ({ isOpen, onClose, onSave, existingKantong, systemOptions, addToast }) => {

  const kantongTypeOptions = systemOptions?.kantongTypes || [
    { value: 'Umum', label: 'Umum' },
    { value: 'Bayar', label: 'Bayar' },
    { value: 'Nabung', label: 'Nabung' },
    { value: 'Terkunci', label: 'Terkunci' },
    { value: 'Bersama', label: 'Bersama' },
  ];

  const initialKantongState: Omit<Kantong, 'id'> = {
    name: '',
    balance: 0,
    description: '',
    type: kantongTypeOptions[0].value as KantongType,
    targetAmount: undefined,
    interestRate: undefined,
    lockEndDate: undefined,
  };

  const [kantong, setKantong] = useState<Omit<Kantong, 'id'>>(initialKantongState);

  useEffect(() => {
    if (isOpen) {
        if (existingKantong) {
        setKantong({
            name: existingKantong.name,
            balance: existingKantong.balance,
            description: existingKantong.description || '',
            type: existingKantong.type,
            targetAmount: existingKantong.targetAmount,
            interestRate: existingKantong.interestRate,
            lockEndDate: existingKantong.lockEndDate,
        });
        } else {
        setKantong(initialKantongState);
        }
    }
  }, [existingKantong, isOpen, initialKantongState]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;

    let processedValue = value;
    if (name === 'balance' || name === 'targetAmount' || name === 'interestRate') {
        processedValue = parseFloat(value) ? parseFloat(value).toString() : ''; // Keep as string for controlled input, parse on save
    }

    setKantong(prev => ({
        ...prev,
        [name]: processedValue
    }));

    // Reset conditional fields if type changes
    if (name === 'type') {
        setKantong(prev => ({
            ...prev,
            targetAmount: undefined,
            interestRate: undefined,
            lockEndDate: undefined,
        }));
    }
  };

  const handleSubmit = () => {
    if (!kantong.name) {
      addToast?.('Nama Kantong harus diisi.', 'error');
      return;
    }

    const finalKantongData: Kantong = {
      id: existingKantong?.id || `kantong-${Date.now().toString()}`,
      name: kantong.name,
      balance: parseFloat(kantong.balance.toString()) || 0,
      type: kantong.type,
      description: kantong.description,
      targetAmount: kantong.type === 'Nabung' ? (parseFloat(kantong.targetAmount?.toString() || '0') || undefined) : undefined,
      interestRate: (kantong.type === 'Nabung' || kantong.type === 'Terkunci') ? (parseFloat(kantong.interestRate?.toString() || '0') || undefined) : undefined,
      lockEndDate: kantong.type === 'Terkunci' ? kantong.lockEndDate : undefined,
    };

    onSave(finalKantongData);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={existingKantong ? "Edit Kantong Custom" : "Tambah Kantong Custom Baru"}
      size="lg" // Increased size for more fields
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>{existingKantong ? "Simpan Perubahan" : "Simpan Kantong"}</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-6">
        {existingKantong ? "Ubah detail kantong di bawah ini." : "Masukkan detail kantong baru di bawah ini."}
      </p>
      <div className="space-y-4">
        <Input label="Nama Kantong*" name="name" value={kantong.name} onChange={handleChange} placeholder="Contoh: Dana Darurat, Belanja Bulanan" />
        <Input
            label="Saldo Awal (Opsional)"
            name="balance"
            type="number"
            value={kantong.balance.toString()}
            onChange={handleChange}
            placeholder={`${Currency.IDR} 0`}
            disabled={!!existingKantong} // Usually, initial balance is only for new kantongs
            className={existingKantong ? "bg-gray-100" : ""}
        />
        <Select
            label="Jenis Kantong*"
            name="type"
            value={kantong.type}
            onChange={handleChange}
            options={kantongTypeOptions}
        />

        {kantong.type === 'Nabung' && (
          <>
            <Input
              label="Target Tabungan (Opsional)"
              name="targetAmount"
              type="number"
              value={kantong.targetAmount?.toString() || ''}
              onChange={handleChange}
              placeholder={`${Currency.IDR} 0`}
            />
            <Input
              label="Estimasi Bunga (% p.a.) (Info)"
              name="interestRate"
              type="number"
              step="0.01"
              value={kantong.interestRate?.toString() || ''}
              onChange={handleChange}
              placeholder="cth: 3.75"
            />
          </>
        )}

        {kantong.type === 'Terkunci' && (
          <>
            <Input
              label="Tanggal Selesai Kunci (Opsional)"
              name="lockEndDate"
              type="date"
              value={kantong.lockEndDate || ''}
              onChange={handleChange}
            />
            <Input
              label="Estimasi Bunga (% p.a.) (Info)"
              name="interestRate"
              type="number"
              step="0.01"
              value={kantong.interestRate?.toString() || ''}
              onChange={handleChange}
              placeholder="cth: 5.00"
            />
          </>
        )}

        {kantong.type === 'Bersama' && (
            <TextArea
                label="Dibagikan Dengan (Info)"
                name="sharedWith"
                value={(kantong as any).sharedWith || ''} // Temporary cast if not in current state structure
                onChange={handleChange}
                rows={2}
                placeholder="Nama pengguna atau grup (fitur lanjutan)"
                disabled
                className="bg-gray-100"
            />
        )}

        <TextArea label="Deskripsi (Opsional)" name="description" value={kantong.description || ''} onChange={handleChange} rows={3} placeholder="Tujuan atau detail kantong..." />
      </div>
    </Modal>
  );
};

export default AddKantongModal;