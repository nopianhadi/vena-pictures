
import React, { useState, useMemo } from 'react';
import Button from '../ui/Button';
import Table from '../ui/Table';
import Badge from '../ui/Badge';
import AddKlienModal from '../klien/AddKlienModal';
import KlienDetailModal from '../klien/KlienDetailModal';
import RecordPaymentModal from '../klien/RecordPaymentModal';
import CreateBillingInvoiceModal from '../klien/CreateBillingInvoiceModal'; // Import new modal
import { Client, PaymentStatus, Currency, Package, AddOn, Transaction, PaymentRecord, Project, BankDetail, SystemOptions, UserProfile, Invoice, InvoiceStatus, ActivityItem, KlienPageProps, ToastMessage } from '../../types';
import { PlusCircleIcon, MagnifyingGlassIcon, EyeIcon, PencilSquareIcon, TrashIcon, CurrencyDollarIcon, UsersIcon, DocumentTextIcon as InvoiceIcon } from '../../constants';
import Input from '../ui/Input';
import Card from '../ui/Card';


const KlienPage: React.FC<KlienPageProps> = ({
  clients, addClient, updateClient, deleteClient,
  addTransaction, addProject, allPackages, allAddOns, allProjects, bankDetails, systemOptions,
  updateProject, userProfile, openViewInvoiceModalById, addActivityLogItem, addToast, generateInvoiceNumber,
  addBillingInvoice
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isRecordPaymentModalOpen, setIsRecordPaymentModalOpen] = useState(false);
  const [isCreateBillingInvoiceModalOpen, setIsCreateBillingInvoiceModalOpen] = useState(false); // New state
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [selectedClientForDetail, setSelectedClientForDetail] = useState<Client | null>(null);
  const [selectedClientForPaymentRecord, setSelectedClientForPaymentRecord] = useState<Client | null>(null);
  const [selectedClientForBilling, setSelectedClientForBilling] = useState<Client | null>(null); // New state
  const [searchTerm, setSearchTerm] = useState('');

  const handleOpenAddModal = () => {
    setEditingClient(null);
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (client: Client) => {
    setEditingClient(client);
    setIsAddModalOpen(true);
  };

  const handleOpenRecordPaymentModal = (client: Client) => {
    setSelectedClientForPaymentRecord(client);
    setIsRecordPaymentModalOpen(true);
  };

  const handleOpenCreateBillingInvoiceModal = (client: Client) => {
    setSelectedClientForBilling(client);
    setIsCreateBillingInvoiceModalOpen(true);
  };

  const handleSaveClient = (clientToSave: Client, projectToSave?: Project) => {
    const existing = clients.find(c => c.id === clientToSave.id);
    if (existing) {
      updateClient(clientToSave);
    } else {
      addClient(clientToSave, projectToSave);
    }
    setIsAddModalOpen(false);
    setEditingClient(null);
  };

  const handleDeleteClient = (clientId: string) => {
    if (window.confirm('Apakah Anda yakin ingin menghapus klien ini? Ini tidak akan menghapus proyek atau invoice terkait.')) {
      deleteClient(clientId);
    }
  };

  const handleViewClient = (client: Client) => {
    setSelectedClientForDetail(client);
    setIsDetailModalOpen(true);
  };

  const handleSaveNewPaymentRecord = (paymentDetails: Omit<PaymentRecord, 'id' | 'invoiceId'>, projectId?: string) => {
    if (!selectedClientForPaymentRecord) return;

    const clientToUpdate = clients.find(c => c.id === selectedClientForPaymentRecord.id);
    if (!clientToUpdate) return;

    const newPaymentRecordBase: PaymentRecord = {
        id: `pay-${selectedClientForPaymentRecord.id}-${Date.now()}`,
        projectId,
        ...paymentDetails,
    };

    let targetInvoice: Invoice | undefined;
    const clientInvoices = clientToUpdate.invoices || [];

    if (projectId) {
        targetInvoice = clientInvoices.find(inv => inv.projectId === projectId && inv.status !== InvoiceStatus.Paid && inv.status !== InvoiceStatus.Cancelled);
    }
    if (!targetInvoice) {
        targetInvoice = clientInvoices.find(inv => !inv.projectId && inv.status !== InvoiceStatus.Paid && inv.status !== InvoiceStatus.Cancelled);
    }

    let updatedClient = { ...clientToUpdate };
    let invoiceIdForTransaction: string | undefined;

    if (targetInvoice) {
        const updatedAmountPaid = targetInvoice.amountPaid + paymentDetails.amount;
        const updatedBalanceDue = targetInvoice.totalAmount - updatedAmountPaid;
        const updatedInvoiceStatus = updatedBalanceDue <= 0 ? InvoiceStatus.Paid : InvoiceStatus.Partial;

        const updatedPaymentRecordForInvoice = { ...newPaymentRecordBase, invoiceId: targetInvoice.id };

        const finalTargetInvoice = {
            ...targetInvoice,
            amountPaid: updatedAmountPaid,
            balanceDue: updatedBalanceDue,
            status: updatedInvoiceStatus,
            paymentHistory: [...targetInvoice.paymentHistory, updatedPaymentRecordForInvoice]
        };
        invoiceIdForTransaction = finalTargetInvoice.id;

        updatedClient.invoices = clientInvoices.map(inv => inv.id === finalTargetInvoice.id ? finalTargetInvoice : inv);
        addActivityLogItem({ action: 'Update Pembayaran Invoice', targetType: 'Invoice', targetName: finalTargetInvoice.invoiceNumber, targetId: finalTargetInvoice.id, amount: paymentDetails.amount});

    } else {
        const newInvoiceId = `inv-${clientToUpdate.id}-${Date.now()}`;
        const newInvoice: Invoice = {
            id: newInvoiceId,
            invoiceNumber: generateInvoiceNumber(clientToUpdate.id, new Date(paymentDetails.date)),
            clientId: clientToUpdate.id,
            projectId: projectId,
            issueDate: paymentDetails.date,
            items: [{ id: `item-adhoc-${Date.now()}`, description: `Pembayaran untuk ${projectId ? allProjects.find(p=>p.id===projectId)?.name || 'Proyek' : 'Layanan Klien'}`, quantity: 1, unitPrice: paymentDetails.amount, amount: paymentDetails.amount }],
            subtotal: paymentDetails.amount,
            totalAmount: paymentDetails.amount,
            amountPaid: paymentDetails.amount,
            balanceDue: 0,
            status: InvoiceStatus.Paid,
            paymentHistory: [{ ...newPaymentRecordBase, invoiceId: newInvoiceId }],
            paymentInstructions: userProfile.invoiceTerms
        };
        invoiceIdForTransaction = newInvoice.id;
        updatedClient.invoices = [...clientInvoices, newInvoice];
        addActivityLogItem({ action: 'Buat Invoice Otomatis', targetType: 'Invoice', targetName: newInvoice.invoiceNumber, targetId: newInvoice.id, amount: newInvoice.totalAmount});
    }

    updatedClient.paymentHistory = [...(updatedClient.paymentHistory || []), { ...newPaymentRecordBase, invoiceId: invoiceIdForTransaction }];
    const totalPaidByClient = (updatedClient.paymentHistory || []).reduce((sum,p) => sum + p.amount, 0);
    updatedClient.downPayment = totalPaidByClient;
    updatedClient.remainingPayment = (updatedClient.invoices || []).reduce((sum, inv) => sum + inv.balanceDue, 0);
    updatedClient.paymentStatus = updatedClient.remainingPayment <= 0 ? PaymentStatus.Paid : PaymentStatus.Partial;

    if (projectId) {
        updatedClient.paymentsPerProject = {
            ...(updatedClient.paymentsPerProject || {}),
            [projectId]: ((updatedClient.paymentsPerProject || {})[projectId] || 0) + paymentDetails.amount
        };
    }

    updateClient(updatedClient);

    if (projectId) {
        const projectToUpdate = allProjects.find(p => p.id === projectId);
        if (projectToUpdate) {
            updateProject({
                ...projectToUpdate,
                totalClientPayments: (projectToUpdate.totalClientPayments || 0) + paymentDetails.amount,
            });
        }
    }

    addTransaction({
        id: `trans-${newPaymentRecordBase.id}`,
        date: paymentDetails.date,
        description: `Pembayaran Klien: ${clientToUpdate.name}${projectId ? ` (Proyek: ${allProjects.find(p=>p.id===projectId)?.name || 'N/A'})` : ''}${paymentDetails.notes ? ` - ${paymentDetails.notes}`:''}`,
        category: 'Pemasukan Proyek',
        type: 'Pemasukan',
        amount: paymentDetails.amount,
        method: paymentDetails.method || 'Transfer Bank',
        linkedClientId: clientToUpdate.id,
        linkedProjectId: projectId,
        invoiceId: invoiceIdForTransaction,
    });
    addToast(`Pembayaran sebesar ${paymentDetails.amount.toLocaleString('id-ID')} dari ${clientToUpdate.name} berhasil dicatat.`, 'success');
    setIsRecordPaymentModalOpen(false);
    setSelectedClientForPaymentRecord(null);
  };

   const handleSaveBillingInvoice = (invoice: Invoice, clientId: string, projectId?: string): string => {
    const newInvoiceId = addBillingInvoice(invoice, clientId, projectId); // Use the prop
    const clientToUpdate = clients.find(c => c.id === clientId);

    addActivityLogItem({ 
        action: 'Buat Invoice Penagihan', 
        targetType: 'Invoice', 
        targetName: invoice.invoiceNumber, 
        targetId: newInvoiceId, 
        details: `Untuk klien ${clientToUpdate?.name || clientId}`, 
        amount: invoice.totalAmount 
    });
    // Toast is handled by addBillingInvoice via App.tsx

    setIsCreateBillingInvoiceModalOpen(false);
    setSelectedClientForBilling(null);
    if (newInvoiceId) {
        openViewInvoiceModalById(newInvoiceId, clientId);
    }
    return newInvoiceId;
  };


  const filteredClients = useMemo(() => {
    if (!searchTerm) return clients;
    return clients.filter(client =>
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (client.phone && client.phone.includes(searchTerm))
    );
  }, [clients, searchTerm]);

  const getPaymentStatusColor = (status: PaymentStatus): 'green' | 'blue' | 'yellow' | 'red' | 'gray' => {
    switch (status) {
      case PaymentStatus.Paid: return 'green';
      case PaymentStatus.Partial: return 'blue';
      case PaymentStatus.Unpaid: return 'yellow';
      case PaymentStatus.Overdue: return 'red';
      default: return 'gray';
    }
  };

  const columns = [
    {
      key: 'name',
      header: 'Nama',
      render: (client: Client) => (
        <div>
          <div className="font-medium text-gray-900">{client.name}</div>
          <div className="text-xs text-gray-500">{client.email}</div>
          <div className="text-xs text-gray-500">{client.instagram || '-'}</div>
        </div>
      )
    },
    {
      key: 'contact',
      header: 'Kontak & Tgl Daftar',
      render: (client: Client) => (
        <div>
            <div className="text-sm text-gray-700">{client.phone}</div>
            <div className="text-xs text-gray-500">{client.dateAdded ? new Date(client.dateAdded).toLocaleDateString('id-ID') : '-'}</div>
        </div>
      )
    },
    {
      key: 'package',
      header: 'Paket Info',
      render: (client: Client) => (
        <div>
            <div className="text-sm text-gray-900">{client.packageName || '-'}</div>
            <div className="text-xs text-gray-500">Nilai: {client.totalProjectValue ? `${Currency.IDR} ${client.totalProjectValue.toLocaleString('id-ID')}`: '-'}</div>
        </div>
      )
    },
    { key: 'downPayment', header: 'Total Dibayar', render: (client: Client) => `${Currency.IDR} ${(client.downPayment || 0).toLocaleString('id-ID')}` },
    { key: 'remainingPayment', header: 'Sisa Global', render: (client: Client) => <span className="font-semibold text-red-600">{Currency.IDR} ${(client.remainingPayment || 0).toLocaleString('id-ID')}</span> },
    {
      key: 'paymentStatus',
      header: 'Status Global',
      render: (client: Client) => <Badge text={client.paymentStatus} color={getPaymentStatusColor(client.paymentStatus)} />
    },
    {
      key: 'actions',
      header: 'Aksi',
      render: (client: Client) => (
        <div className="flex space-x-0.5">
          <Button variant="ghost" size="xs" title="Lihat Detail" onClick={() => handleViewClient(client)}><EyeIcon className="w-4 h-4 text-gray-500 hover:text-indigo-600" /></Button>
          <Button variant="ghost" size="xs" title="Edit Klien" onClick={() => handleOpenEditModal(client)}><PencilSquareIcon className="w-4 h-4 text-blue-500 hover:text-blue-700" /></Button>
          <Button variant="ghost" size="xs" title="Buat Tagihan/Invoice" onClick={() => handleOpenCreateBillingInvoiceModal(client)}><InvoiceIcon className="w-4 h-4 text-purple-500 hover:text-purple-700" /></Button>
          <Button variant="ghost" size="xs" title="Catat Pembayaran" onClick={() => handleOpenRecordPaymentModal(client)}><CurrencyDollarIcon className="w-4 h-4 text-green-500 hover:text-green-700" /></Button>
          <Button variant="ghost" size="xs" title="Hapus Klien" onClick={() => handleDeleteClient(client.id)}><TrashIcon className="w-4 h-4 text-red-500 hover:text-red-700" /></Button>
        </div>
      ),
    },
  ];

  const clientTableEmptyState = (
    <div className="text-center py-10">
        <UsersIcon className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">Belum ada klien</h3>
        <p className="mt-1 text-sm text-gray-500">Mulai dengan menambahkan klien pertama Anda.</p>
        <div className="mt-6">
            <Button onClick={handleOpenAddModal} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
                Tambah Klien Baru
            </Button>
        </div>
    </div>
  );


  return (
    <div className="space-y-5">
       <Card className="p-0">
        <div className="px-4 py-3 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-800">Manajemen Klien</h2>
        </div>
        <div className="p-4 flex flex-col sm:flex-row justify-between items-center gap-3">
            <div className="relative flex-grow w-full sm:w-auto sm:max-w-xs">
                <Input
                type="text"
                placeholder="Cari klien..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full"
                leftIcon={<MagnifyingGlassIcon className="w-4 h-4 text-gray-400" />}
                />
            </div>
            <Button onClick={handleOpenAddModal} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
                Tambah Klien Baru
            </Button>
        </div>
      </Card>

      <Card>
        <Table columns={columns} data={filteredClients} rowKey="id" emptyStateNode={clientTableEmptyState} />
      </Card>

      {isAddModalOpen && (
        <AddKlienModal
            isOpen={isAddModalOpen}
            onClose={() => { setIsAddModalOpen(false); setEditingClient(null); }}
            onSave={handleSaveClient}
            existingItem={editingClient}
            allPackages={allPackages}
            allAddOns={allAddOns}
            systemOptions={systemOptions}
            addTransaction={addTransaction}
            updateProject={updateProject}
            addToast={addToast}
        />
      )}
      {isDetailModalOpen && selectedClientForDetail && (
        <KlienDetailModal
            isOpen={isDetailModalOpen}
            onClose={() => setIsDetailModalOpen(false)}
            client={selectedClientForDetail}
            allPackages={allPackages}
            allAddOns={allAddOns}
            allProjects={allProjects}
            bankDetails={bankDetails}
            onUpdateClient={updateClient}
            systemOptions={systemOptions}
            userProfile={userProfile}
            openViewInvoiceModalById={openViewInvoiceModalById}
            addToast={addToast}
        />
      )}
      {isRecordPaymentModalOpen && selectedClientForPaymentRecord && (
        <RecordPaymentModal
            isOpen={isRecordPaymentModalOpen}
            onClose={() => setIsRecordPaymentModalOpen(false)}
            onSave={handleSaveNewPaymentRecord}
            clientName={selectedClientForPaymentRecord.name}
            remainingAmount={selectedClientForPaymentRecord.remainingPayment || 0}
            clientProjects={allProjects.filter(p => p.clientId === selectedClientForPaymentRecord.id)}
            addToast={addToast}
        />
      )}
      {isCreateBillingInvoiceModalOpen && selectedClientForBilling && (
        <CreateBillingInvoiceModal
          isOpen={isCreateBillingInvoiceModalOpen}
          onClose={() => { setIsCreateBillingInvoiceModalOpen(false); setSelectedClientForBilling(null); }}
          onSave={handleSaveBillingInvoice}
          client={selectedClientForBilling}
          allPackages={allPackages}
          allAddOns={allAddOns}
          allClientProjects={allProjects.filter(p => p.clientId === selectedClientForBilling.id)}
          userProfile={userProfile}
          generateInvoiceNumber={generateInvoiceNumber}
          addToast={addToast}
        />
      )}
    </div>
  );
};

export default KlienPage;
