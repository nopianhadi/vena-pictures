
import React, { useState } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import { Client, Package, AddOn, Currency, PaymentStatus, PaymentRecord, KlienDetailModalProps, Project, ProjectStatus, CommunicationEntry, SystemOptions, UserProfile, Invoice, InvoiceStatus, ToastMessage } from '../../types';
import { ShareIcon, ArrowDownTrayIcon, CheckCircleIcon, EyeIcon, DocumentTextIcon } from '../../constants';
import Tabs from '../ui/Tabs'; 
import Table, { TableColumn } from '../ui/Table';
import Badge from '../ui/Badge';
import Input, { Select as UiSelect, TextArea as UiTextArea } from '../ui/Input';


const DetailItem: React.FC<{ label: string; value?: string | number | React.ReactNode; className?: string; valueClassName?: string }> = ({ label, value, className, valueClassName }) => (
    <div className={`grid grid-cols-3 gap-2 py-1.5 ${className}`}>
        <dt className="text-sm font-medium text-gray-500 col-span-1">{label}</dt>
        <dd className={`text-sm text-gray-800 col-span-2 ${valueClassName}`}>{value || '-'}</dd>
    </div>
);

const KlienDetailModal: React.FC<KlienDetailModalProps> = ({ 
    isOpen, onClose, client, allPackages, allAddOns, allProjects, bankDetails, 
    onUpdateClient, systemOptions, userProfile, openViewInvoiceModalById, addToast
}) => {
  if (!client) return null;

  const [newCommDate, setNewCommDate] = useState(new Date().toISOString().split('T')[0]);
  const [newCommType, setNewCommType] = useState<CommunicationEntry['type']>('Call');
  const [newCommNotes, setNewCommNotes] = useState('');


  const clientPackage = allPackages.find(p => p.name === client.packageName);
  const clientAddOns = client.addOns || [];
  const paymentHistory = client.paymentHistory || [];
  const relatedProjects = allProjects.filter(p => p.clientId === client.id);
  const communicationLog = client.communicationLog || [];
  const clientInvoices = client.invoices || [];

  const handleAddCommunicationLog = () => { 
    if (!newCommNotes.trim()) {
        addToast?.("Catatan komunikasi tidak boleh kosong.", 'error');
        return;
    }
    const newEntry: CommunicationEntry = {
        id: `comm-${client.id}-${Date.now()}`,
        date: newCommDate,
        type: newCommType,
        notes: newCommNotes,
    };
    const updatedClient = {
        ...client,
        communicationLog: [...(client.communicationLog || []), newEntry],
    };
    onUpdateClient(updatedClient);
    addToast?.('Log komunikasi berhasil ditambahkan.', 'success');
    setNewCommDate(new Date().toISOString().split('T')[0]);
    setNewCommType('Call');
    setNewCommNotes('');
  };

  const InfoSection: React.FC = () => (
    <div className="space-y-1 px-1 py-2">
      <h3 className="text-lg font-semibold text-gray-700 mb-3 border-b pb-2">Informasi Dasar Klien</h3>
      <DetailItem label="Nama Klien" value={client.name} valueClassName="font-semibold"/>
      <DetailItem label="Email" value={client.email} />
      <DetailItem label="Telepon" value={client.phone} />
      <DetailItem label="Instagram" value={client.instagram} />
      <DetailItem label="Tanggal Daftar" value={client.dateAdded} />
      <DetailItem label="Sumber Klien" value={client.source || <span className="italic text-gray-500">Belum diisi</span>} />
      <DetailItem 
        label="Tag Klien" 
        value={client.tags && client.tags.length > 0 
            ? <div className="flex flex-wrap gap-1">{client.tags.map(tag => <Badge key={tag} text={tag} color="blue" size="sm"/>)}</div> 
            : <span className="italic text-gray-500">Belum ada tag</span>} 
      />
      <DetailItem label="Alamat Acara/Domisili" value={client.address} />
      <DetailItem label="Tanggal Acara" value={client.eventDate ? new Date(client.eventDate).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : '-'} />
      {client.additionalNotes && <DetailItem label="Catatan Klien" value={<p className="whitespace-pre-wrap">{client.additionalNotes}</p>} />}
      {client.accommodation && <DetailItem label="Akomodasi" value={client.accommodation} />}
    </div>
  );

  const PackageDetailsSection: React.FC = () => ( 
    <div className="space-y-3 px-1 py-2 text-sm">
      <h3 className="text-lg font-semibold text-gray-700 mb-3 border-b pb-2">Rincian Paket & Layanan</h3>
      <DetailItem label="Nama Paket" value={client.packageName || '-'} valueClassName="font-semibold"/>
      <DetailItem label="Harga Paket" value={`${Currency.IDR} ${client.packagePrice?.toLocaleString('id-ID') || '0'}`} />
      {clientPackage && clientPackage.duration && <DetailItem label="Durasi Paket" value={clientPackage.duration} />}
      <div className="mt-3">
        <dt className="text-sm font-medium text-gray-500 mb-1">Layanan Paket Termasuk:</dt>
        {clientPackage && clientPackage.services.length > 0 ? (
          <ul className="list-none space-y-1 pl-1">
            {clientPackage.services.map((service, idx) => ( <li key={idx} className="flex items-start"> <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0"/> <span className="text-gray-800">{service}</span> </li> ))}
          </ul>
        ) : <dd className="text-gray-600 ml-5">- Tidak ada layanan terdefinisi.</dd>}
      </div>
      <div className="mt-4">
        <dt className="text-sm font-medium text-gray-500 mb-1">Add-On Terpilih:</dt>
        {clientAddOns.length > 0 ? (
          <ul className="list-none space-y-1 pl-1">
            {clientAddOns.map(addon => ( <li key={addon.id} className="flex items-start"> <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0"/> <span className="text-gray-800">{addon.name} ({Currency.IDR} {addon.price.toLocaleString('id-ID')})</span> </li> ))}
          </ul>
        ) : <dd className="text-gray-600 ml-5">- Tidak ada add-on.</dd>}
      </div>
    </div>
  );

  const PaymentSummarySection: React.FC = () => { 
    const paymentStatusDescription = () => {
        if (!client) return '';
        switch (client.paymentStatus) {
            case PaymentStatus.Paid: return "Pembayaran telah lunas seluruhnya.";
            case PaymentStatus.Partial: return `Klien telah melakukan pembayaran sebagian. Sisa tagihan: ${Currency.IDR} ${client.remainingPayment?.toLocaleString('id-ID') || '0'}.`;
            case PaymentStatus.Unpaid: return "Belum ada pembayaran yang diterima untuk tagihan ini.";
            default: return "";
        }
    };
    return (
        <div className="space-y-3 px-1 py-2 text-sm">
            <h3 className="text-lg font-semibold text-gray-700 mb-4 border-b pb-2">Ringkasan Pembayaran Global Klien</h3>
            <DetailItem label="Total Nilai Proyek Terkait" value={`${Currency.IDR} ${(client.invoices || []).reduce((sum, inv) => sum + inv.totalAmount, 0).toLocaleString('id-ID')}`} valueClassName="font-bold text-lg text-gray-800"/>
            <DetailItem label="Total Telah Dibayar (Global)" value={`${Currency.IDR} ${client.downPayment?.toLocaleString('id-ID') || '0'}`} />
            <DetailItem label="Sisa Pembayaran (Global)" value={`${Currency.IDR} ${client.remainingPayment?.toLocaleString('id-ID') || '0'}`} valueClassName="font-bold text-lg text-red-600"/>
            <div className="grid grid-cols-3 gap-2 py-1.5">
                <dt className="text-sm font-medium text-gray-500 col-span-1">Status Pembayaran Global</dt>
                <dd className={`text-sm text-gray-800 col-span-2 font-semibold ${ client.paymentStatus === PaymentStatus.Paid ? 'text-green-600' : client.paymentStatus === PaymentStatus.Partial ? 'text-blue-600' : client.paymentStatus === PaymentStatus.Unpaid ? 'text-yellow-600 animate-pulse' : 'text-gray-600' }`}>{client.paymentStatus}</dd>
                {paymentStatusDescription() && ( <dd className="text-xs text-gray-500 col-span-2 col-start-2 mt-0.5">{paymentStatusDescription()}</dd> )}
            </div>
            {client.paymentsPerProject && Object.keys(client.paymentsPerProject).length > 0 && (
                <div className="mt-4 pt-3 border-t">
                    <h4 className="text-md font-semibold text-gray-600 mb-2">Alokasi Pembayaran per Proyek (General):</h4>
                    <ul className="space-y-1 text-xs">
                        {Object.entries(client.paymentsPerProject).map(([projectId, amount]) => { const projectDetails = allProjects.find(p => p.id === projectId); return ( <li key={projectId} className="flex justify-between p-1 bg-gray-50 rounded"> <span>{projectDetails ? projectDetails.name : `ID Proyek: ${projectId}`}</span> <span className="font-medium">{Currency.IDR} {amount.toLocaleString('id-ID')}</span> </li> ); })}
                    </ul>
                </div>
            )}
        </div>
    );
  };

  const PaymentHistorySection: React.FC = () => { 
    const paymentColumns: TableColumn<PaymentRecord>[] = [
        { key: 'date', header: 'Tanggal', render: (p: PaymentRecord) => new Date(p.date).toLocaleDateString('id-ID')},
        { key: 'amount', header: 'Jumlah', render: (p: PaymentRecord) => `${Currency.IDR} ${p.amount.toLocaleString('id-ID')}`},
        { key: 'method', header: 'Metode', render: (p: PaymentRecord) => p.method || '-' },
        { key: 'projectId', header: 'Alokasi Proyek', render: (p: PaymentRecord) => { const project = allProjects.find(proj => proj.id === p.projectId); return project ? project.name : p.projectId ? 'Proyek tidak dikenal' : 'Tidak dialokasikan'; } },
        { key: 'invoiceId', header: 'No. Invoice', render: (p:PaymentRecord) => {
            const inv = client.invoices?.find(i => i.id === p.invoiceId); 
            return inv ? (
                <Button variant="link" size="xs" onClick={() => openViewInvoiceModalById(inv.id, inv.clientId)} className="p-0 text-indigo-600 hover:text-indigo-800">
                    {inv.invoiceNumber}
                </Button>
            ) : '-'; 
          } 
        },
        { key: 'notes', header: 'Catatan', render: (p: PaymentRecord) => p.notes || '-' },
    ];
    return (
        <div className="space-y-3 px-1 py-2 text-sm">
            <h3 className="text-lg font-semibold text-gray-700 mb-3 border-b pb-2">Riwayat Pembayaran Klien (Semua)</h3>
            {paymentHistory.length > 0 ? ( <Table columns={paymentColumns} data={paymentHistory} rowKey="id" emptyStateMessage="Belum ada riwayat pembayaran." /> ) : ( <p className="text-gray-500">Belum ada riwayat pembayaran yang tercatat untuk klien ini.</p> )}
        </div>
    );
  };
  
  const InvoicesSection: React.FC = () => {
    const getInvoiceStatusColor = (status: InvoiceStatus): 'green' | 'blue' | 'yellow' | 'red' | 'gray' | 'purple' => {
        switch(status) {
            case InvoiceStatus.Paid: return 'green';
            case InvoiceStatus.Partial: return 'blue';
            case InvoiceStatus.Sent: return 'blue'; 
            case InvoiceStatus.Overdue: return 'red';
            case InvoiceStatus.Draft: return 'gray';
            case InvoiceStatus.Cancelled: return 'purple';
            default: return 'gray';
        }
    };

    const invoiceColumns: TableColumn<Invoice>[] = [
        { key: 'invoiceNumber', header: 'No. Invoice', render: (inv: Invoice) => <span className="font-medium text-indigo-600">{inv.invoiceNumber}</span>},
        { key: 'issueDate', header: 'Tgl Terbit', render: (inv: Invoice) => new Date(inv.issueDate).toLocaleDateString('id-ID')},
        { key: 'projectId', header: 'Proyek Terkait', render: (inv: Invoice) => { const project = allProjects.find(p => p.id === inv.projectId); return project ? project.name : 'Umum'; }},
        { key: 'totalAmount', header: 'Total Tagihan', render: (inv: Invoice) => `${Currency.IDR} ${inv.totalAmount.toLocaleString('id-ID')}`},
        { key: 'amountPaid', header: 'Dibayar', render: (inv: Invoice) => `${Currency.IDR} ${inv.amountPaid.toLocaleString('id-ID')}`},
        { key: 'balanceDue', header: 'Sisa', render: (inv: Invoice) => <span className="font-semibold text-red-600">{Currency.IDR} ${inv.balanceDue.toLocaleString('id-ID')}</span>},
        { key: 'status', header: 'Status', render: (inv: Invoice) => <Badge text={inv.status} color={getInvoiceStatusColor(inv.status)} />},
        { key: 'actions', header: 'Aksi', render: (inv: Invoice) => (
            <Button variant="ghost" size="xs" onClick={() => openViewInvoiceModalById(inv.id, inv.clientId)} title="Lihat Invoice">
                <EyeIcon className="w-4 h-4 text-gray-500 hover:text-indigo-600"/>
            </Button>
        )},
    ];
    return (
        <div className="space-y-3 px-1 py-2 text-sm">
            <h3 className="text-lg font-semibold text-gray-700 mb-3 border-b pb-2">Daftar Invoice Klien</h3>
            {clientInvoices.length > 0 ? (
                 <Table columns={invoiceColumns} data={clientInvoices} rowKey="id" emptyStateMessage="Belum ada invoice untuk klien ini." />
            ) : (
                <p className="text-gray-500">Belum ada invoice yang tercatat untuk klien ini.</p>
            )}
        </div>
    );
  };

  const getProjectStatusColor = (status: ProjectStatus): 'green' | 'blue' | 'yellow' | 'red' | 'gray' => { 
    switch (status) {
      case ProjectStatus.Completed: return 'green';
      case ProjectStatus.InProgress: return 'blue';
      case ProjectStatus.Pending: return 'yellow';
      case ProjectStatus.Cancelled: return 'red';
      case ProjectStatus.OnHold: return 'gray';
      default: return 'gray';
    }
  };

  const RelatedProjectsSection: React.FC = () => {
    const projectColumns = [
        { key: 'name', header: 'Nama Proyek', render: (p: Project) => <span className="font-medium text-indigo-600 hover:underline cursor-pointer" onClick={() => addToast?.(`Navigasi ke detail proyek ${p.name} (placeholder).`, 'info')}>{p.name}</span> },
        { key: 'eventDate', header: 'Tanggal Acara', render: (p: Project) => p.eventDate ? new Date(p.eventDate).toLocaleDateString('id-ID') : '-' },
        { key: 'status', header: 'Status', render: (p: Project) => <Badge text={p.status} color={getProjectStatusColor(p.status)} /> },
        { key: 'progress', header: 'Progress', render: (p: Project) => ( <div className="flex items-center"> <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2"> <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${p.progress}%` }}></div> </div> <span className="text-xs text-gray-500">{p.progress}%</span> </div> )},
    ];
    return (
        <div className="space-y-3 px-1 py-2 text-sm">
            <h3 className="text-lg font-semibold text-gray-700 mb-3 border-b pb-2">Proyek Terkait Klien Ini</h3>
            {relatedProjects.length > 0 ? ( <Table columns={projectColumns} data={relatedProjects} rowKey="id" emptyStateMessage="Tidak ada proyek terkait untuk klien ini." /> ) : ( <p className="text-gray-500">Tidak ada proyek lain yang tercatat untuk klien ini.</p> )}
        </div>
    );
  };

  const CommunicationLogSection: React.FC = () => { 
    const communicationTypeOptions = systemOptions.communicationTypes || [ { value: 'Call', label: 'Telepon' }, { value: 'Meeting', label: 'Rapat' }, { value: 'Email', label: 'Email' }, { value: 'Other', label: 'Lainnya' }, ];
    return (
      <div className="space-y-4 px-1 py-2">
        <h3 className="text-lg font-semibold text-gray-700 mb-3 border-b pb-2">Log Komunikasi</h3>
        <div className="bg-gray-50 p-4 rounded-md border">
          <h4 className="text-md font-semibold text-gray-600 mb-2">Tambah Entri Baru</h4>
          <div className="space-y-3">
            <Input label="Tanggal Komunikasi" type="date" value={newCommDate} onChange={(e) => setNewCommDate(e.target.value)} />
            <UiSelect label="Jenis Komunikasi" options={communicationTypeOptions} value={newCommType} onChange={(e) => setNewCommType(e.target.value as CommunicationEntry['type'])} />
            <UiTextArea label="Catatan Komunikasi" value={newCommNotes} onChange={(e) => setNewCommNotes(e.target.value)} placeholder="Isi detail komunikasi..." rows={3}/>
            <Button onClick={handleAddCommunicationLog} size="sm">Simpan Log</Button>
          </div>
        </div>
        {communicationLog.length > 0 ? (
          <ul className="space-y-3 max-h-60 overflow-y-auto">
            {communicationLog.slice().reverse().map(log => ( <li key={log.id} className="p-3 border rounded-md shadow-sm bg-white"> <div className="flex justify-between items-start"> <span className="text-sm font-semibold text-indigo-600">{log.type} - {new Date(log.date).toLocaleDateString('id-ID')}</span> </div> <p className="text-sm text-gray-700 mt-1 whitespace-pre-wrap">{log.notes}</p> </li> ))}
          </ul>
        ) : ( <p className="text-gray-500 text-sm">Belum ada log komunikasi.</p> )}
      </div>
    );
  };


  const tabItems = [
    { id: 'info', label: 'Informasi Klien', content: <InfoSection /> },
    { id: 'paket', label: 'Rincian Paket', content: <PackageDetailsSection /> },
    { id: 'pembayaran', label: 'Ringkasan Pembayaran', content: <PaymentSummarySection /> },
    { id: 'riwayat_pembayaran', label: 'Riwayat Pembayaran', content: <PaymentHistorySection /> },
    { id: 'invoices', label: 'Invoices', content: <InvoicesSection /> },
    { id: 'proyek_terkait', label: 'Proyek Terkait', content: <RelatedProjectsSection /> },
    { id: 'komunikasi', label: 'Log Komunikasi', content: <CommunicationLogSection /> },
  ];


  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Detail Klien: ${client.name}`}
      size="4xl" 
      footer={
        <div className="flex justify-between w-full items-center">
            <div></div>
            <Button variant="primary" onClick={onClose}>Tutup</Button>
        </div>
      }
    >
      <div className="p-1 max-h-[70vh] overflow-y-auto">
        <Tabs tabs={tabItems} initialTabId="info"/>
      </div>
    </Modal>
  );
};

export default KlienDetailModal;
