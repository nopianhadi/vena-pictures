
import React, { useState, useMemo } from 'react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Tabs from '../ui/Tabs';
import AddFreelancerOrTeamModal from '../freelancer/AddFreelancerOrTeamModal';
// Removed PayFreelancerModal and SavingsWithdrawalModal imports, AddFreelancerProjectModal is not used here directly for payments.
import { Freelancer, Currency, FreelancerRole, FreelancerType, Transaction, Project as ClientProject, FreelancerProject as IFreelancerProject, SystemOptions, PaymentStatus, Kantong, FreelancerPageProps, TabItem, AppModalState, ToastMessage } from '../../types';
import { PlusCircleIcon, MagnifyingGlassIcon, EyeIcon, PencilSquareIcon, CreditCardIcon as EarningsIcon, BriefcaseIcon, TrashIcon, UserGroupIcon } from '../../constants';

// Helper function to create a sub-component for Freelancer Card
const FreelancerCard: React.FC<{
  freelancer: Freelancer;
  onDetail: (id: string) => void;
  onEdit: (freelancer: Freelancer) => void;
  onEarnings: (id: string) => void;
}> = ({ freelancer, onDetail, onEdit, onEarnings }) => {
  return (
    <div className="bg-white shadow-lg rounded-xl border border-gray-200/75 p-5 flex flex-col justify-between transition-all hover:shadow-indigo-100">
      <div>
        <h3 className="text-lg font-semibold text-indigo-700 truncate">{freelancer.name}</h3>
        <p className="text-sm text-gray-500 mb-3">{freelancer.role}</p>
        
        <div className="space-y-1.5 text-xs text-gray-600">
          <p><span className="font-medium">{freelancer.projectCount}</span> Proyek</p>
          <p>Fee Standar: <span className="font-medium">{Currency.IDR} {freelancer.standardFee.toLocaleString('id-ID')}</span></p>
          <p>Total Penghasilan: <span className="font-medium">{Currency.IDR} {(freelancer.totalEarnings || 0).toLocaleString('id-ID')}</span></p>
          {freelancer.type === 'Tim Internal' && (
            <p>Tabungan (2%): <span className="font-medium">{Currency.IDR} {(freelancer.savings || 0).toLocaleString('id-ID')}</span></p>
          )}
        </div>
      </div>
      <div className="mt-4 pt-4 border-t border-gray-200 flex space-x-2">
        <Button variant="outline" size="sm" onClick={() => onDetail(freelancer.id)} leftIcon={<EyeIcon className="w-4 h-4"/>}>Detail</Button>
        <Button variant="outline" size="sm" onClick={() => onEdit(freelancer)} leftIcon={<PencilSquareIcon className="w-4 h-4"/>}>Edit</Button>
        <Button variant="outline" size="sm" onClick={() => onEarnings(freelancer.id)} leftIcon={<EarningsIcon className="w-4 h-4"/>}>Penghasilan</Button>
      </div>
    </div>
  );
};


const FreelancerPage: React.FC<FreelancerPageProps> = ({ 
  freelancers, addFreelancer, updateFreelancer, deleteFreelancer, 
  allClientProjects, allFreelancerProjects, addFreelancerProject, updateFreelancerProject,
  systemOptions, onViewFreelancerDetail, 
  appModals, setAppModals, addToast
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeRoleFilter, setActiveRoleFilter] = useState<FreelancerRole | 'Semua'>('Semua');
  const [activeTab, setActiveTab] = useState<FreelancerType>('Tim Internal');

  const [isAddOrEditModalOpen, setIsAddOrEditModalOpen] = useState(false);
  const [editingFreelancer, setEditingFreelancer] = useState<Freelancer | null>(null);

  const currentFreelancerRoles = systemOptions.freelancerRoles || [];
  const availableRoleFilters: (FreelancerRole | 'Semua')[] = ['Semua', ...currentFreelancerRoles];

  const handleSaveFreelancerOrTeam = (freelancerToSave: Freelancer, action?: 'saveAndClose' | 'saveAndAddNew') => {
    const isEditing = !!editingFreelancer && freelancers.some(f => f.id === freelancerToSave.id);
    if (isEditing) {
      updateFreelancer(freelancerToSave);
    } else {
      const newId = freelancerToSave.id || `fl-${Date.now()}`;
      addFreelancer({ ...freelancerToSave, id: newId });
    }
    if (action === 'saveAndAddNew' && !isEditing) {
      setEditingFreelancer(null); 
    } else {
      setEditingFreelancer(null);
      setIsAddOrEditModalOpen(false);
    }
  };

  const openEditModal = (freelancer: Freelancer) => {
    setEditingFreelancer(freelancer);
    setIsAddOrEditModalOpen(true);
  };
  
  const openEarningsModal = (freelancerId: string) => {
    setAppModals(prev => ({ ...prev, freelancerEarnings: { isOpen: true, freelancerId } }));
  };

  const filteredFreelancers = useMemo(() => {
    return freelancers.filter(f =>
      f.type === activeTab &&
      (activeRoleFilter === 'Semua' || f.role === activeRoleFilter) &&
      (f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
       (f.email && f.email.toLowerCase().includes(searchTerm.toLowerCase())))
    ).sort((a,b) => a.name.localeCompare(b.name));
  }, [freelancers, activeTab, activeRoleFilter, searchTerm]);

  const RoleFilterButton: React.FC<{label: FreelancerRole | 'Semua'; isActive: boolean; onClick: () => void;}> = ({ label, isActive, onClick }) => (
    <button
        type="button"
        onClick={onClick}
        className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1
            ${isActive 
                ? 'bg-indigo-600 text-white shadow-sm' 
                : 'bg-white text-gray-600 hover:bg-indigo-50 border border-gray-300 hover:border-indigo-300'
            }`}
    >
        {label}
    </button>
);

  const renderFreelancerGrid = () => (
    filteredFreelancers.length > 0 ? (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 mt-4">
        {filteredFreelancers.map(freelancer => (
          <FreelancerCard
            key={freelancer.id}
            freelancer={freelancer}
            onDetail={onViewFreelancerDetail}
            onEdit={openEditModal}
            onEarnings={openEarningsModal}
          />
        ))}
      </div>
    ) : (
      <div className="text-center py-12 text-gray-500">
        <UserGroupIcon className="w-16 h-16 mx-auto mb-4 text-gray-400"/>
        <h3 className="text-lg font-medium text-gray-700">Data Tidak Ditemukan</h3>
        <p className="mt-1">Tidak ada data {activeRoleFilter !== 'Semua' ? activeRoleFilter : ''} {activeTab === 'Tim Internal' ? 'Tim Internal' : 'Freelancer Eksternal'} yang cocok dengan filter.</p>
        <p className="mt-1">Coba ubah filter atau tambahkan data baru.</p>
         <Button 
            onClick={() => { setEditingFreelancer(null); setIsAddOrEditModalOpen(true); }} 
            leftIcon={<PlusCircleIcon className="w-5 h-5" />}
            variant="secondary"
            className="mt-6"
        >
          Tambah {activeTab === 'Tim Internal' ? 'Tim Internal' : 'Freelancer'} Baru
        </Button>
      </div>
    )
  );

  const tabItems: TabItem[] = [
    { id: 'Tim Internal', label: 'Tim Internal', content: renderFreelancerGrid() },
    { id: 'Freelancer Extern', label: 'Freelancer Eksternal', content: renderFreelancerGrid() }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-semibold text-gray-800">Manajemen Tim & Freelancer</h2>
        <Button onClick={() => { setEditingFreelancer(null); setIsAddOrEditModalOpen(true); }} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
          Tambah Baru
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-3 mb-4">
        <div className="relative flex-grow w-full sm:w-auto">
          <Input
            type="text"
            placeholder="Cari freelancer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full"
            leftIcon={<MagnifyingGlassIcon className="w-4 h-4 text-gray-400" />}
          />
        </div>
        <div className="flex flex-wrap gap-2 items-center justify-start sm:justify-end">
            {availableRoleFilters.map(role => (
                 <RoleFilterButton 
                    key={role} 
                    label={role} 
                    isActive={activeRoleFilter === role} 
                    onClick={() => setActiveRoleFilter(role)}
                />
            ))}
        </div>
      </div>
      
      <Tabs tabs={tabItems} initialTabId={activeTab} onTabChange={(tabId) => setActiveTab(tabId as FreelancerType)} />

      {isAddOrEditModalOpen && (
        <AddFreelancerOrTeamModal
          isOpen={isAddOrEditModalOpen}
          onClose={() => { setIsAddOrEditModalOpen(false); setEditingFreelancer(null); }}
          onSave={handleSaveFreelancerOrTeam}
          existingFreelancer={editingFreelancer}
          defaultType={activeTab} 
          systemOptions={systemOptions}
          addToast={addToast}
        />
      )}
    </div>
  );
};

export default FreelancerPage;
