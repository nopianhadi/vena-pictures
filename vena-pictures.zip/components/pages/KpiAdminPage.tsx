
import React, { useMemo } from 'react';
import Card from '../ui/Card';
import { Client, Project, Transaction, Freelancer, FreelancerProject, Kantong, Currency, ProjectStatus } from '../../types';
import { ChartPieIcon, CurrencyDollarIcon, UsersIcon, BriefcaseIcon, WalletIcon, ChartBarIcon as ChartBarIconConstant, ArrowTrendingUpIcon, ArrowTrendingDownIcon, UserGroupIcon, CreditCardIcon } from '../../constants'; // Renamed ChartBarIcon import

// SimpleBarChart Component (can be moved to a shared UI folder if used elsewhere)
const SimpleBarChart: React.FC<{ data: { label: string; value: number; color: string }[]; title: string; unit?: string }> = ({ data, title, unit }) => {
  const maxValue = Math.max(...data.map(d => d.value), 0); // Ensure maxValue is at least 0
  const safeMaxValue = maxValue === 0 ? 1 : maxValue; // Avoid division by zero for height calculation

  return (
    <Card title={title} className="h-full">
      <div className="flex justify-around items-end h-52 p-4 pt-2">
        {data.map((item, index) => {
          const barHeight = (item.value / safeMaxValue) * 100;
          return (
            <div key={index} className="flex flex-col items-center w-1/3 mx-1">
              <div 
                className={`${item.color} rounded-t-md w-10 sm:w-12 transition-all duration-300 ease-out relative group`} 
                style={{ height: `${barHeight}%` }}
              >
                <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-xs text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                  {unit || ''}{item.value.toLocaleString('id-ID')}
                </span>
              </div>
              <p className="text-xs text-center mt-1 text-gray-600 truncate w-full">{item.label}</p>
            </div>
          );
        })}
      </div>
    </Card>
  );
};

// ProjectStatusDistributionChart Component (can be moved to a shared UI folder)
const ProjectStatusDistributionChart: React.FC<{ projects: Project[] }> = ({ projects }) => {
  const statusCounts = useMemo(() => {
    const counts: Record<ProjectStatus, number> = {
      [ProjectStatus.Pending]: 0,
      [ProjectStatus.InProgress]: 0,
      [ProjectStatus.Completed]: 0,
      [ProjectStatus.OnHold]: 0,
      [ProjectStatus.Cancelled]: 0,
    };
    projects.forEach(p => {
      counts[p.status]++;
    });
    return counts;
  }, [projects]);

  const totalProjects = projects.length;
  if (totalProjects === 0) return <Card title="Distribusi Status Proyek"><p className="text-center text-gray-500 py-4">Tidak ada data proyek.</p></Card>;

  // Monochrome status colors for ProjectStatusDistributionChart
  const statusColors: Record<ProjectStatus, string> = {
    [ProjectStatus.Pending]: 'bg-gray-400',       // Was yellow-400
    [ProjectStatus.InProgress]: 'bg-gray-500',    // Was blue-500
    [ProjectStatus.Completed]: 'bg-gray-700',     // Was green-500 (darkest for completed)
    [ProjectStatus.OnHold]: 'bg-gray-300',        // Was gray-400 (lighter)
    [ProjectStatus.Cancelled]: 'bg-black',        // Was red-500
  };
  const statusTextColors: Record<ProjectStatus, string> = {
    [ProjectStatus.Pending]: 'text-gray-700',
    [ProjectStatus.InProgress]: 'text-gray-800', // Adjusted for slightly darker bg
    [ProjectStatus.Completed]: 'text-white', // Text for dark background
    [ProjectStatus.OnHold]: 'text-gray-700',
    [ProjectStatus.Cancelled]: 'text-white', // Text for black background
  };


  return (
    <Card title="Distribusi Status Proyek" className="h-full">
      <div className="flex flex-col items-center p-4">
        <div className="w-full flex h-8 rounded-full overflow-hidden mb-4 border border-gray-300">
          {Object.entries(statusCounts).map(([status, count]) => {
            if (count === 0) return null;
            const percentage = (count / totalProjects) * 100;
            return (
              <div
                key={status}
                className={`${statusColors[status as ProjectStatus]} transition-all duration-300 ease-out`}
                style={{ width: `${percentage}%` }}
                title={`${status}: ${count} (${percentage.toFixed(1)}%)`}
              ></div>
            );
          })}
        </div>
        <div className="text-xs grid grid-cols-2 sm:grid-cols-3 gap-x-3 gap-y-1 w-full">
          {Object.entries(statusCounts).map(([status, count]) => {
             if (count === 0 && status !== ProjectStatus.Pending && status !== ProjectStatus.InProgress && status !== ProjectStatus.Completed ) return null;
             // Determine background for legend item based on statusColor for better contrast with text
             const legendItemBgClass = statusColors[status as ProjectStatus].includes('gray-700') || statusColors[status as ProjectStatus].includes('black') ? 'bg-opacity-10' : 'bg-opacity-50';
             const legendItemTextClass = statusColors[status as ProjectStatus].includes('gray-700') || statusColors[status as ProjectStatus].includes('black') ? statusTextColors[status as ProjectStatus] : 'text-gray-700';

             return (
            <div key={status} className={`flex items-center justify-between p-1 rounded ${statusColors[status as ProjectStatus].replace('bg-','bg-')} ${legendItemBgClass} border border-gray-200`}>
              <div className={`flex items-center ${legendItemTextClass}`}>
                <span className={`w-2 h-2 rounded-full mr-1.5 ${statusColors[status as ProjectStatus]}`}></span>
                {status}
              </div>
              <span className={`font-medium ${legendItemTextClass}`}>{count}</span>
            </div>
          )})}
        </div>
      </div>
    </Card>
  );
};


interface KpiAdminPageProps {
  clients: Client[];
  projects: Project[];
  transactions: Transaction[];
  freelancers: Freelancer[];
  freelancerProjects: FreelancerProject[];
  kantongs: Kantong[];
}

const KpiCard: React.FC<{
  title: string;
  value: string | number;
  icon: React.ReactElement<React.SVGProps<SVGSVGElement>>;
  unit?: string;
  description?: string;
  valueClassName?: string;
}> = ({ title, value, icon, unit, description, valueClassName }) => {
    return (
        <Card className="flex-1 min-w-[220px] shadow-md">
            <div className="flex items-center justify-between mb-1">
                <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider truncate" title={title}>{title}</p>
                <div className="text-gray-500">{React.cloneElement(icon, { className: "w-5 h-5" })}</div>
            </div>
            <p className={`text-2xl font-bold ${valueClassName || 'text-gray-800'}`}>
                {unit && typeof value === 'number' ? `${unit} ` : ''}
                {typeof value === 'number' ? value.toLocaleString('id-ID', {maximumFractionDigits: unit === '%' ? 1 : 0}) : value}
                {unit === '%' && typeof value === 'number' ? '%' : ''}
            </p>
            {description && <p className="text-xs text-gray-500 mt-0.5 truncate" title={description}>{description}</p>}
        </Card>
    );
};


const KpiAdminPage: React.FC<KpiAdminPageProps> = ({
  clients, projects, transactions, freelancers, freelancerProjects, kantongs,
}) => {
  const totalRevenue = useMemo(() => transactions.filter(t => t.type === 'Pemasukan').reduce((sum, t) => sum + t.amount, 0), [transactions]);
  const totalExpense = useMemo(() => transactions.filter(t => t.type === 'Pengeluaran').reduce((sum, t) => sum + t.amount, 0), [transactions]);
  const netProfit = totalRevenue - totalExpense;
  const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  const totalProjects = projects.length;
  const completedProjectsCount = useMemo(() => projects.filter(p => p.status === ProjectStatus.Completed).length, [projects]);
  const projectCompletionRate = totalProjects > 0 ? (completedProjectsCount / totalProjects) * 100 : 0;

  const totalClients = clients.length;
  const averageRevenuePerClient = totalClients > 0 ? totalRevenue / totalClients : 0;

  const totalFreelancerPayments = useMemo(() =>
    transactions.filter(t => t.type === 'Pengeluaran' && (t.category === 'Fee Freelancer' || t.category === 'Gaji Tim'))
                .reduce((sum, t) => sum + t.amount, 0),
  [transactions]);
  const totalClientPaymentsActual = useMemo(() =>
    projects.reduce((sum, p) => sum + (p.totalClientPayments || 0), 0),
  [projects]);


  const financialKpis = [
    { title: 'Total Pendapatan', value: totalRevenue, icon: <CurrencyDollarIcon/>, unit: Currency.IDR, valueClassName: 'text-green-600' },
    { title: 'Total Pengeluaran', value: totalExpense, icon: <CurrencyDollarIcon/>, unit: Currency.IDR, valueClassName: 'text-red-600' },
    { title: 'Profit Bersih', value: netProfit, icon: <ChartPieIcon/>, unit: Currency.IDR, valueClassName: netProfit >= 0 ? 'text-green-700' : 'text-red-700' },
    { title: 'Profit Margin', value: profitMargin, icon: <ChartPieIcon/>, unit: '%', description: `(Profit / Pendapatan)` },
  ];

  const projectKpis = [
    { title: 'Total Proyek', value: totalProjects, icon: <BriefcaseIcon/>, description: `${completedProjectsCount} Selesai` },
    { title: 'Tingkat Penyelesaian Proyek', value: projectCompletionRate, icon: <ChartPieIcon/>, unit: '%' },
  ];

  const clientAndTeamKpis = [
    { title: 'Total Klien', value: totalClients, icon: <UsersIcon/> },
    { title: 'Rata-rata Pendapatan per Klien', value: averageRevenuePerClient, icon: <CreditCardIcon/>, unit: Currency.IDR},
    { title: 'Total Pembayaran ke Tim/Freelancer', value: totalFreelancerPayments, icon: <UserGroupIcon/>, unit: Currency.IDR },
  ];

  // Monochrome chart colors
  const incomeExpenseChartData = [
    { label: 'Pendapatan', value: totalRevenue, color: 'bg-gray-700' }, // Was green
    { label: 'Pengeluaran', value: totalExpense, color: 'bg-gray-500' }, // Was red
    { label: 'Profit', value: netProfit > 0 ? netProfit : 0, color: netProfit >= 0 ? 'bg-gray-300' : 'bg-transparent' }, // Was blue
  ];

  const clientVsFreelancerPaymentChartData = [
    { label: 'Pemasukan dari Klien (Proyek)', value: totalClientPaymentsActual, color: 'bg-gray-600' }, // Was sky
    { label: 'Pembayaran ke Tim/Freelancer', value: totalFreelancerPayments, color: 'bg-gray-400' }, // Was purple
  ];

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-gray-800 tracking-tight">Key Performance Indicators (KPI) Admin</h2>

      <div>
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Ringkasan Finansial Utama</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {financialKpis.map(kpi => <KpiCard key={kpi.title} {...kpi} />)}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <SimpleBarChart data={incomeExpenseChartData} title="Pendapatan vs. Pengeluaran (Total)" unit={Currency.IDR}/>
        <ProjectStatusDistributionChart projects={projects} />
        <SimpleBarChart data={clientVsFreelancerPaymentChartData} title="Pembayaran Klien vs. Tim/Freelancer" unit={Currency.IDR}/>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Analisis Proyek</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {projectKpis.map(kpi => <KpiCard key={kpi.title} {...kpi} />)}
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Statistik Klien & Tim</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {clientAndTeamKpis.map(kpi => <KpiCard key={kpi.title} {...kpi} />)}
        </div>
      </div>

       <Card title="Catatan & Analisis Tambahan">
            <p className="text-sm text-gray-600">
                Halaman KPI Admin ini dirancang untuk memberikan gambaran umum kinerja bisnis.
                Untuk analisis yang lebih mendalam, pertimbangkan untuk menambahkan filter periode atau membandingkan dengan periode sebelumnya.
            </p>
        </Card>
    </div>
  );
};

export default KpiAdminPage;