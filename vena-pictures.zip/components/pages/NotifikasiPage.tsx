
import React from 'react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import { NotificationItem } from '../../types';
import { BellAlertIcon, CheckCircleIcon, TrashIcon, EyeIcon, ClockIcon, CalendarDaysIcon, WalletIcon, CurrencyDollarIcon } from '../../constants';
import { Link } from 'react-router-dom';

interface NotifikasiPageProps {
  notifications: NotificationItem[];
  onMarkAsRead: (id: string) => void;
  onClearAll: () => void;
}

const NotifikasiPage: React.FC<NotifikasiPageProps> = ({ notifications, onMarkAsRead, onClearAll }) => {

  const getNotificationIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'deadline_project':
      case 'deadline_task':
        return <ClockIcon className="w-5 h-5 text-orange-500" />;
      case 'contract_end':
        return <CalendarDaysIcon className="w-5 h-5 text-purple-500" />;
      case 'low_balance':
        return <WalletIcon className="w-5 h-5 text-red-500" />;
      case 'payment_received':
        return <CurrencyDollarIcon className="w-5 h-5 text-green-500" />;
      case 'general_reminder':
      default:
        return <BellAlertIcon className="w-5 h-5 text-blue-500" />;
    }
  };
  
  const sortedNotifications = [...notifications].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-gray-800">Notifikasi</h2>
        {notifications.length > 0 && (
          <Button variant="danger" size="sm" onClick={onClearAll} leftIcon={<TrashIcon className="w-4 h-4"/>}>
            Hapus Semua
          </Button>
        )}
      </div>
      <Card>
        {sortedNotifications.length === 0 ? (
          <div className="p-6 text-center">
            <BellAlertIcon className="mx-auto h-16 w-16 text-gray-300 mb-3" />
            <p className="text-gray-600">Tidak ada notifikasi baru saat ini.</p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200 max-h-[75vh] overflow-y-auto">
            {sortedNotifications.map(notif => (
              <li key={notif.id} className={`p-4 hover:bg-slate-50 transition-colors ${notif.isRead ? 'opacity-60 bg-slate-50' : 'bg-white'}`}>
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 pt-0.5">
                    {getNotificationIcon(notif.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                        <h4 className={`text-sm font-semibold ${notif.isRead ? 'text-gray-600' : 'text-gray-800'}`}>{notif.title}</h4>
                        <span className="text-xs text-gray-400">{new Date(notif.date).toLocaleString('id-ID', {dateStyle: 'medium', timeStyle:'short'})}</span>
                    </div>
                    <p className="text-sm text-gray-600 mt-0.5">{notif.message}</p>
                  </div>
                  <div className="flex-shrink-0 flex items-center space-x-2">
                    {!notif.isRead && (
                        <Button variant="ghost" size="xs" onClick={() => onMarkAsRead(notif.id)} title="Tandai sudah dibaca">
                            <CheckCircleIcon className="w-4 h-4 text-green-500 hover:text-green-700"/>
                        </Button>
                    )}
                    {notif.linkTo && (
                        <Link to={notif.linkTo}>
                            <Button variant="ghost" size="xs" title="Lihat Detail Terkait">
                                <EyeIcon className="w-4 h-4 text-indigo-500 hover:text-indigo-700"/>
                            </Button>
                        </Link>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
};

export default NotifikasiPage;
