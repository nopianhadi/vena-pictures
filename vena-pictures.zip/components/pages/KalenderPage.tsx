import React, { useState, useMemo, useEffect } from 'react';
import Button from '../ui/Button';
import { PlusCircleIcon, CalendarDaysIcon } from '../../constants';
import AddEventModal from '../kalender/AddEventModal';
import { CalendarEvent, SystemOptions, CalendarEvent as CalendarEventType, ToastMessage } from '../../types';
import { CALENDAR_EVENT_COLOR_OPTIONS, CALENDAR_EVENT_TYPE_OPTIONS as constantCalendarEventTypes } from '../../constants';

interface KalenderPageProps {
  events: CalendarEvent[];
  addEvent: (event: CalendarEvent) => void;
  updateEvent: (updatedEvent: CalendarEvent) => void;
  deleteEvent: (eventId: string) => void;
  systemOptions: SystemOptions;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

const KalenderPage: React.FC<KalenderPageProps> = ({
  events: initialEvents,
  addEvent,
  updateEvent,
  deleteEvent,
  systemOptions,
  addToast
}) => {
  const [currentDate, setCurrentDate] = useState(new Date(2025, 4, 1)); // Default to May 2025 for consistency with mock data if used
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);

  const safeEventTypeOptions = useMemo(() => {
    return (systemOptions.calendarEventTypes || constantCalendarEventTypes) || [];
  }, [systemOptions.calendarEventTypes]);


  const [typeFilters, setTypeFilters] = useState<Record<CalendarEventType['type'], boolean>>(() => {
    return safeEventTypeOptions.reduce((acc, typeOpt) => {
      acc[typeOpt.value] = true; // Default all to true
      return acc;
    }, {} as Record<CalendarEventType['type'], boolean>);
  });

  useEffect(() => {
    // Update filters when available options change, preserving existing user toggles if possible
    setTypeFilters(prevFilters => {
      const newActiveFiltersState: Record<CalendarEventType['type'], boolean> = {} as Record<CalendarEventType['type'], boolean>;
      safeEventTypeOptions.forEach(opt => {
        // If option was previously filtered, keep its state, otherwise default to true (visible)
        newActiveFiltersState[opt.value] = prevFilters[opt.value] !== undefined ? prevFilters[opt.value] : true;
      });
      return newActiveFiltersState;
    });
  }, [safeEventTypeOptions]);


  const filteredEvents = useMemo(() => {
    return initialEvents.filter(event => typeFilters[event.type] === undefined ? true : typeFilters[event.type]); // If a filter for a type doesn't exist, show the event
  }, [initialEvents, typeFilters]);


  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthName = currentDate.toLocaleString('id-ID', { month: 'long' });

  const numDays = daysInMonth(year, month);
  let firstDayDisplayIndex = firstDayOfMonth(year, month);
  firstDayDisplayIndex = (firstDayDisplayIndex === 0) ? 6 : firstDayDisplayIndex - 1;

  const calendarDays: ({ day: number | null; dateISO: string | null; events: CalendarEvent[] })[] = Array(firstDayDisplayIndex).fill({ day: null, dateISO: null, events: [] });

  for (let i = 1; i <= numDays; i++) {
    const dateISO = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
    const dayEvents = filteredEvents.filter(event => event.date === dateISO);
    calendarDays.push({ day: i, dateISO: dateISO, events: dayEvents });
  }

  while (calendarDays.length % 7 !== 0) {
    calendarDays.push({ day: null, dateISO: null, events: [] });
  }
  const weeks = [];
  for (let i = 0; i < calendarDays.length; i += 7) {
    weeks.push(calendarDays.slice(i, i + 7));
  }

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const today = () => setCurrentDate(new Date()); // Navigate to current real-world date

  const handleOpenAddEventModal = (dateISO?: string) => {
    setSelectedEvent(null);
    if (dateISO) {
        const defaultEventTypeFromOptions = (safeEventTypeOptions[0]?.value || 'reminder') as CalendarEventType['type'];
        const newEventBase: Partial<CalendarEvent> = {
            title: '',
            date: dateISO,
            type: defaultEventTypeFromOptions,
            color: 'blue',
        };
        setSelectedEvent(newEventBase as CalendarEvent); // Cast as CalendarEvent for the modal
    }
    setIsModalOpen(true);
  };

  const handleEditEvent = (event: CalendarEvent) => {
    setSelectedEvent(event);
    setIsModalOpen(true);
  };

  const handleSaveEvent = (eventToSave: CalendarEvent) => {
    const existing = initialEvents.find(e => e.id === eventToSave.id);
    if (existing) {
      updateEvent(eventToSave);
    } else {
      addEvent(eventToSave);
    }
    setIsModalOpen(false);
  };

  const getEventColorClass = (colorValue?: CalendarEvent['color']): string => {
    const colorOption = CALENDAR_EVENT_COLOR_OPTIONS.find(c => c.value === colorValue);
    return colorOption ? colorOption.class : 'bg-gray-200 text-gray-800 border-gray-300';
  };

  const handleFilterChange = (eventType: CalendarEventType['type']) => {
    setTypeFilters(prev => ({ ...prev, [eventType]: !prev[eventType] }));
  };

  const dayHeaders = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2">
            <h2 className="text-2xl font-semibold text-gray-800">{monthName} {year}</h2>
            <Button variant="outline" size="sm" onClick={today}>Hari Ini</Button>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={prevMonth}>{'<'}</Button>
          <Button variant="outline" size="sm" onClick={nextMonth}>{'>'}</Button>
          <Button onClick={() => handleOpenAddEventModal()} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
            Tambah Acara
          </Button>
        </div>
      </div>

      <div className="p-3 bg-white rounded-md shadow-sm border">
        <div className="flex items-center gap-1 mb-2">
            <CalendarDaysIcon className="w-5 h-5 text-gray-500 mr-1"/>
            <h4 className="text-sm font-medium text-gray-600">Filter Jenis Acara:</h4>
        </div>
        <div className="flex flex-wrap gap-x-3 gap-y-1.5">
            {safeEventTypeOptions.map(typeOpt => (
                <label key={typeOpt.value} className="flex items-center space-x-1.5 cursor-pointer text-xs">
                    <input
                        type="checkbox"
                        checked={typeFilters[typeOpt.value] === undefined ? true : typeFilters[typeOpt.value]} // Default to checked if not in map
                        onChange={() => handleFilterChange(typeOpt.value)}
                        className="form-checkbox h-3.5 w-3.5 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500"
                    />
                    <span>{typeOpt.label}</span>
                </label>
            ))}
        </div>
      </div>


      <div className="bg-white p-4 rounded-lg shadow">
        <div className="grid grid-cols-7 gap-px text-center text-sm font-medium text-gray-600 mb-2">
            {dayHeaders.map(day => <div key={day}>{day}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-px">
          {weeks.map((week, weekIndex) => (
            <React.Fragment key={weekIndex}>
                {week.map((dayObj, dayIndex) => (
                    <div
                        key={dayIndex}
                        className={`p-2 h-32 border border-gray-200 overflow-y-auto transition-colors text-left
                            ${dayObj.day ? 'bg-white hover:bg-gray-50 cursor-pointer' : 'bg-gray-50'}
                            ${new Date().toDateString() === new Date(year, month, dayObj.day || 0).toDateString() ? 'ring-2 ring-indigo-500 bg-indigo-50' : ''}
                        `}
                        onClick={() => dayObj.day && dayObj.dateISO && handleOpenAddEventModal(dayObj.dateISO)}
                    >
                       {dayObj.day && <span className="text-gray-800 font-medium">{dayObj.day}</span>}
                       <div className="mt-1 space-y-1">
                         {dayObj.events.map(event => (
                           <div
                             key={event.id}
                             className={`text-xs p-1 rounded truncate border ${getEventColorClass(event.color)}`}
                             title={event.title}
                             onClick={(e) => { e.stopPropagation(); handleEditEvent(event); }}
                           >
                             {event.startTime && <span className="font-semibold">{event.startTime}</span>} {event.title}
                           </div>
                         ))}
                       </div>
                    </div>
                ))}
            </React.Fragment>
          ))}
        </div>
      </div>

      {isModalOpen && (
        <AddEventModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSave={handleSaveEvent}
          existingItem={selectedEvent}
          systemOptions={systemOptions}
          addToast={addToast}
        />
      )}
    </div>
  );
};

export default KalenderPage;