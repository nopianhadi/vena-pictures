
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Input, { Select as UiSelect, TextArea as UiTextArea } from '../ui/Input';
import Table, { TableColumn } from '../ui/Table';
import Badge from '../ui/Badge';
import { Transaction, Currency, Kantong, SystemOptions, Client, Project, Freelancer, TabItem, KantongType, AutoBudgetRule, ScheduledTransfer, FinancialSummaryCardProps, Invoice, ExpenseVoucher, ToastMessage } from '../../types';
import { PlusCircleIcon, MagnifyingGlassIcon, ArrowTrendingUpIcon, ArrowTrendingDownIcon, PencilSquareIcon, TrashIcon, WalletIcon, ArrowsRightLeftIcon, DocumentChartBarIcon, ChartPieIcon, Cog6ToothIcon, CalendarDaysIcon, LockClosedIcon, UserGroupIcon, BuildingStorefrontIcon, SparklesIcon, EyeIcon, InformationCircleIcon, XCircleIcon, ArrowDownTrayIcon, DocumentTextIcon, UsersIcon as GenericUsersIcon } from '../../constants';
import Tabs from '../ui/Tabs';
import AddTransactionModal from '../keuangan/AddTransactionModal';
import AddKantongModal from '../keuangan/AddKantongModal';
import TransferKantongModal from '../keuangan/TransferKantongModal';
import Modal from '../ui/Modal';
import KantongDetailModal from '../keuangan/KantongDetailModal';


// --- AddAutoBudgetRuleModal START ---
const AddAutoBudgetRuleModal: React.FC<{isOpen: boolean; onClose: () => void; onSave: (rule: Omit<AutoBudgetRule, 'id' | 'lastRunDate' | 'nextRunDate'>) => void; kantongs: Kantong[]; systemOptions: SystemOptions; existingRule?: AutoBudgetRule | null; addToast?: (message: string, type: ToastMessage['type']) => void}> =
    ({isOpen, onClose, onSave, kantongs, systemOptions, existingRule, addToast}) => {

    const getTodayDateString = () => new Date().toISOString().split('T')[0];
    const [description, setDescription] = useState('');
    const [sourceKantongId, setSourceKantongId] = useState('');
    const [destinationKantongId, setDestinationKantongId] = useState('');
    const [amount, setAmount] = useState(0);
    const [frequency, setFrequency] = useState<AutoBudgetRule['frequency']>('monthly');
    const [dayOfMonth, setDayOfMonth] = useState<number | undefined>(1);
    const [isActive, setIsActive] = useState(true);

    useEffect(() => {
        if (isOpen) {
            setDescription(existingRule?.description || '');
            setSourceKantongId(existingRule?.sourceKantongId || '');
            setDestinationKantongId(existingRule?.destinationKantongId || '');
            setAmount(existingRule?.amount || 0);
            setFrequency(existingRule?.frequency || 'monthly');
            setDayOfMonth(existingRule?.dayOfMonth || 1);
            setIsActive(existingRule?.isActive === undefined ? true : existingRule.isActive);
        }
    }, [isOpen, existingRule]);

    const handleSubmit = () => {
        if (!description || !destinationKantongId || amount <= 0) {
            addToast?.("Deskripsi, Kantong Tujuan, dan Jumlah harus diisi dan lebih dari nol.", 'error');
            return;
        }
        onSave({
            description,
            sourceType: sourceKantongId ? 'kantong' : 'main_balance',
            sourceKantongId: sourceKantongId || undefined,
            destinationKantongId,
            amount,
            frequency,
            dayOfMonth: frequency === 'monthly' || frequency === 'specific_date' ? dayOfMonth : undefined,
            dayOfWeek: frequency === 'weekly' ? 1 : undefined, // Default to Monday for weekly
            isActive,
        });
        onClose();
    };

    const kantongOptions = [{value: '', label: 'Dari Saldo Utama (Tidak Direkomendasikan)'}, ...kantongs.map(k => ({value: k.id, label: k.name}))];
    const destKantongOptions = kantongs.map(k => ({value: k.id, label: k.name}));
    const frequencyOptions: {value: AutoBudgetRule['frequency'], label: string}[] = [
        {value: 'monthly', label: 'Bulanan'}, {value: 'weekly', label: 'Mingguan (Hari Senin)'},
        {value: 'daily', label: 'Harian'}, {value: 'on_income', label: 'Saat Ada Pemasukan (Simulasi)'},
    ];

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={existingRule ? "Edit Aturan Auto-Budget" : "Tambah Aturan Auto-Budget"} size="lg" footer={<><Button variant="outline" onClick={onClose}>Batal</Button><Button onClick={handleSubmit}>Simpan Aturan</Button></>}>
            <div className="space-y-4 p-1">
                <Input label="Deskripsi Aturan*" value={description} onChange={e => setDescription(e.target.value)} placeholder="Cth: Tabungan Darurat Bulanan"/>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <UiSelect label="Sumber Dana*" options={kantongOptions} value={sourceKantongId} onChange={e => setSourceKantongId(e.target.value)} />
                    <UiSelect label="Kantong Tujuan*" options={destKantongOptions.filter(k => k.value !== sourceKantongId)} value={destinationKantongId} onChange={e => setDestinationKantongId(e.target.value)} placeholder="-- Pilih Kantong Tujuan --"/>
                </div>
                <Input label="Jumlah Transfer*" type="number" value={amount.toString()} onChange={e => setAmount(parseFloat(e.target.value) || 0)} />
                <UiSelect label="Frekuensi Transfer*" options={frequencyOptions} value={frequency} onChange={e => setFrequency(e.target.value as AutoBudgetRule['frequency'])} />
                {(frequency === 'monthly' || frequency === 'specific_date') && <Input label="Tanggal Transfer (1-28)" type="number" min="1" max="28" value={(dayOfMonth || 1).toString()} onChange={e => setDayOfMonth(parseInt(e.target.value) || 1)} />}
                <label className="flex items-center space-x-2 pt-2">
                    <input type="checkbox" checked={isActive} onChange={e => setIsActive(e.target.checked)} className="form-checkbox rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4" />
                    <span className="text-sm text-gray-700">Aktifkan Aturan Ini</span>
                </label>
            </div>
        </Modal>
    );
};
// --- AddAutoBudgetRuleModal END ---

// --- AddScheduledTransferModal START ---
const AddScheduledTransferModal: React.FC<{isOpen: boolean; onClose: () => void; onSave: (transfer: Omit<ScheduledTransfer, 'id' | 'lastRunDate' | 'nextRunDate'>) => void; kantongs: Kantong[]; systemOptions: SystemOptions; existingTransfer?: ScheduledTransfer | null; addToast?: (message: string, type: ToastMessage['type']) => void}> =
    ({isOpen, onClose, onSave, kantongs, systemOptions, existingTransfer, addToast}) => {

    const getTodayDateString = () => new Date().toISOString().split('T')[0];

    const [description, setDescription] = useState('');
    const [sourceKantongId, setSourceKantongId] = useState('');
    const [recipientType, setRecipientType] = useState<ScheduledTransfer['recipientType']>('internal_kantong');
    const [destinationKantongId, setDestinationKantongId] = useState('');
    const [externalRecipientName, setExternalRecipientName] = useState('');
    const [externalBankName, setExternalBankName] = useState('');
    const [externalAccountNumber, setExternalAccountNumber] = useState('');
    const [amount, setAmount] = useState(0);
    const [frequency, setFrequency] = useState<ScheduledTransfer['frequency']>('monthly');
    const [startDate, setStartDate] = useState(getTodayDateString());
    const [endDate, setEndDate] = useState('');
    const [dayOfMonth, setDayOfMonth] = useState<number | undefined>(1);
    const [dayOfWeek, setDayOfWeek] = useState<number | undefined>(1); // Monday
    const [isActive, setIsActive] = useState(true);

     useEffect(() => {
        if (isOpen) {
            setDescription(existingTransfer?.description || '');
            setSourceKantongId(existingTransfer?.sourceKantongId || (kantongs.length > 0 ? kantongs[0].id : ''));
            setRecipientType(existingTransfer?.recipientType || 'internal_kantong');
            setDestinationKantongId(existingTransfer?.destinationKantongId || '');
            setExternalRecipientName(existingTransfer?.externalRecipientName || '');
            setExternalBankName(existingTransfer?.externalBankName || '');
            setExternalAccountNumber(existingTransfer?.externalAccountNumber || '');
            setAmount(existingTransfer?.amount || 0);
            setFrequency(existingTransfer?.frequency || 'monthly');
            setStartDate(existingTransfer?.startDate || getTodayDateString());
            setEndDate(existingTransfer?.endDate || '');
            setDayOfMonth(existingTransfer?.dayOfMonth || 1);
            setDayOfWeek(existingTransfer?.dayOfWeek || 1);
            setIsActive(existingTransfer?.isActive === undefined ? true : existingTransfer.isActive);
        }
    }, [isOpen, existingTransfer, kantongs]);


    const handleSubmit = () => {
        if (!description || !sourceKantongId || amount <=0) {
            addToast?.("Deskripsi, Kantong Sumber, dan Jumlah harus valid.", 'error'); return;
        }
        if (recipientType === 'internal_kantong' && !destinationKantongId) {
            addToast?.("Kantong Tujuan Internal harus dipilih.", 'error'); return;
        }
        if (recipientType === 'external_account' && (!externalRecipientName || !externalBankName || !externalAccountNumber)) {
            addToast?.("Detail Penerima Eksternal harus lengkap.", 'error'); return;
        }

        onSave({
            description, sourceKantongId, recipientType,
            destinationKantongId: recipientType === 'internal_kantong' ? destinationKantongId : undefined,
            externalRecipientName: recipientType === 'external_account' ? externalRecipientName : undefined,
            externalBankName: recipientType === 'external_account' ? externalBankName : undefined,
            externalAccountNumber: recipientType === 'external_account' ? externalAccountNumber : undefined,
            amount, frequency, startDate, endDate: frequency !== 'once' ? endDate : undefined,
            dayOfMonth: frequency === 'monthly' ? dayOfMonth : undefined,
            dayOfWeek: frequency === 'weekly' ? dayOfWeek : undefined,
            isActive
        });
        onClose();
    };

    const kantongOptions = kantongs.map(k => ({value: k.id, label: `${k.name} (${Currency.IDR} ${k.balance.toLocaleString()})`}));
    const recipientTypeOptions: {value: ScheduledTransfer['recipientType'], label: string}[] = [
        {value: 'internal_kantong', label: 'Ke Kantong Internal Lain'},
        {value: 'external_account', label: 'Ke Rekening Eksternal'},
    ];
    const frequencyOptions: {value: ScheduledTransfer['frequency'], label: string}[] = [
        {value: 'once', label: 'Sekali Jalan'}, {value: 'monthly', label: 'Bulanan'},
        {value: 'weekly', label: 'Mingguan'}, {value: 'daily', label: 'Harian'},
    ];
    const dayOfWeekOptions = [
        {value: 1, label:'Senin'}, {value: 2,label:'Selasa'}, {value: 3,label:'Rabu'},
        {value: 4,label:'Kamis'}, {value: 5,label:'Jumat'}, {value: 6,label:'Sabtu'}, {value: 0,label:'Minggu'}
    ];


    return (
        <Modal isOpen={isOpen} onClose={onClose} title={existingTransfer ? "Edit Transfer Terjadwal" : "Tambah Transfer Terjadwal"} size="xl" footer={<><Button variant="outline" onClick={onClose}>Batal</Button><Button onClick={handleSubmit}>Simpan Jadwal</Button></>}>
            <div className="space-y-4 p-1">
                <Input label="Deskripsi Transfer*" value={description} onChange={e => setDescription(e.target.value)} placeholder="Cth: Bayar Cicilan Kamera, Transfer Gaji Staf"/>
                <UiSelect label="Sumber Dana (Kantong)*" options={kantongOptions} value={sourceKantongId} onChange={e => setSourceKantongId(e.target.value)} placeholder="-- Pilih Kantong Sumber --"/>

                <fieldset className="p-3 border rounded-md">
                    <legend className="text-sm font-medium text-gray-700 px-1">Detail Penerima</legend>
                    <UiSelect label="Jenis Penerima*" options={recipientTypeOptions} value={recipientType} onChange={e => setRecipientType(e.target.value as ScheduledTransfer['recipientType'])} wrapperClassName="mb-3"/>
                    {recipientType === 'internal_kantong' && (
                        <UiSelect label="Kantong Tujuan Internal*" options={kantongOptions.filter(k => k.value !== sourceKantongId)} value={destinationKantongId} onChange={e => setDestinationKantongId(e.target.value)} placeholder="-- Pilih Kantong Tujuan --"/>
                    )}
                    {recipientType === 'external_account' && (
                        <div className="space-y-3">
                            <Input label="Nama Penerima Eksternal*" value={externalRecipientName} onChange={e => setExternalRecipientName(e.target.value)}/>
                            <Input label="Nama Bank Eksternal*" value={externalBankName} onChange={e => setExternalBankName(e.target.value)}/>
                            <Input label="Nomor Rekening Eksternal*" value={externalAccountNumber} onChange={e => setExternalAccountNumber(e.target.value)}/>
                        </div>
                    )}
                </fieldset>

                <Input label="Jumlah Transfer*" type="number" value={amount.toString()} onChange={e => setAmount(parseFloat(e.target.value) || 0)} />

                <fieldset className="p-3 border rounded-md">
                    <legend className="text-sm font-medium text-gray-700 px-1">Penjadwalan</legend>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <UiSelect label="Frekuensi*" options={frequencyOptions} value={frequency} onChange={e => setFrequency(e.target.value as ScheduledTransfer['frequency'])} />
                        <Input label="Tanggal Mulai*" type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
                    </div>
                    {frequency !== 'once' && <Input label="Tanggal Berakhir (Opsional)" type="date" value={endDate} onChange={e => setEndDate(e.target.value)} wrapperClassName="mt-3"/>}
                    {frequency === 'monthly' && <Input label="Tanggal Tiap Bulan (1-28)" type="number" min="1" max="28" value={(dayOfMonth||1).toString()} onChange={e => setDayOfMonth(parseInt(e.target.value))} wrapperClassName="mt-3"/>}
                    {frequency === 'weekly' && <UiSelect label="Hari Tiap Minggu" options={dayOfWeekOptions} value={(dayOfWeek||1).toString()} onChange={e => setDayOfWeek(parseInt(e.target.value))} wrapperClassName="mt-3"/>}
                </fieldset>

                <label className="flex items-center space-x-2 pt-2">
                    <input type="checkbox" checked={isActive} onChange={e => setIsActive(e.target.checked)} className="form-checkbox rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4" />
                    <span className="text-sm text-gray-700">Aktifkan Jadwal Ini</span>
                </label>
            </div>
        </Modal>
    );
};
// --- AddScheduledTransferModal END ---


interface KeuanganPageProps {
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id'> & {id?: string}) => void;
  systemOptions: SystemOptions;
  allClients: Client[];
  allProjects: Project[];
  allFreelancers: Freelancer[];
  kantongs: Kantong[];
  addKantong: (kantong: Omit<Kantong, 'id'>) => void;
  updateKantong: (kantong: Kantong) => void;
  deleteKantong: (kantongId: string) => void;
  onTransferAntarKantong: (sourceKantongId: string, destinationKantongId: string, amount: number, date: string, notes?: string) => void;
  autoBudgetRules: AutoBudgetRule[];
  onAddAutoBudgetRule: (rule: Omit<AutoBudgetRule, 'id' | 'lastRunDate' | 'nextRunDate'>) => void;
  onUpdateAutoBudgetRule: (rule: AutoBudgetRule) => void;
  onDeleteAutoBudgetRule: (ruleId: string) => void;
  scheduledTransfers: ScheduledTransfer[];
  onAddScheduledTransfer: (transfer: Omit<ScheduledTransfer, 'id'| 'lastRunDate' | 'nextRunDate'>) => void;
  onUpdateScheduledTransfer: (transfer: ScheduledTransfer) => void;
  onDeleteScheduledTransfer: (transferId: string) => void;
  generalReceipts: Invoice[];
  expenseVouchers: ExpenseVoucher[];
  openViewInvoiceModalById: (invoiceId: string, clientId?: string) => void;
  openViewExpenseVoucherModal: (expenseVoucherId: string) => void;
  addToast: (message: string, type: ToastMessage['type']) => void;
}

const downloadCSV = (csvContent: string, fileName: string) => {
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", fileName);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

const escapeCsvCell = (value: any): string => {
  if (value === null || value === undefined) {
    return '""';
  }
  if (typeof value === 'number') {
    return String(value);
  }
  if (typeof value === 'boolean') {
    return `"${String(value)}"`;
  }
  let stringValue = String(value);
  if (stringValue.trim() === "") {
    return '""';
  }
  stringValue = stringValue.replace(/"/g, '""');
  return `"${stringValue}"`;
};


const KeuanganPage: React.FC<KeuanganPageProps> = ({
  transactions, addTransaction, systemOptions, allClients, allProjects, allFreelancers,
  kantongs, addKantong, updateKantong, deleteKantong, onTransferAntarKantong,
  autoBudgetRules, onAddAutoBudgetRule, onUpdateAutoBudgetRule, onDeleteAutoBudgetRule,
  scheduledTransfers, onAddScheduledTransfer, onUpdateScheduledTransfer, onDeleteScheduledTransfer,
  generalReceipts, expenseVouchers, openViewInvoiceModalById, openViewExpenseVoucherModal, addToast
}) => {
  const [isAddTransactionModalOpen, setIsAddTransactionModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [isAddKantongModalOpen, setIsAddKantongModalOpen] = useState(false);
  const [editingKantong, setEditingKantong] = useState<Kantong | null>(null);
  const [isTransferKantongModalOpen, setIsTransferKantongModalOpen] = useState(false);
  const [defaultSourceKantongIdForTransfer, setDefaultSourceKantongIdForTransfer] = useState<string | undefined>(undefined);
  const [isKantongDetailModalOpen, setIsKantongDetailModalOpen] = useState(false);
  const [selectedKantongForDetail, setSelectedKantongForDetail] = useState<Kantong | null>(null);

  const [isAddAutoBudgetModalOpen, setIsAddAutoBudgetModalOpen] = useState(false);
  const [editingAutoBudgetRule, setEditingAutoBudgetRule] = useState<AutoBudgetRule | null>(null);
  const [isAddScheduledTransferModalOpen, setIsAddScheduledTransferModalOpen] = useState(false);
  const [editingScheduledTransfer, setEditingScheduledTransfer] = useState<ScheduledTransfer | null>(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState<'Pemasukan' | 'Pengeluaran' | ''>('');
  const [activeTransactionTableFilter, setActiveTransactionTableFilter] = useState<string | null>(null); // Renamed to avoid confusion
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>(transactions);

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const [reportType, setReportType] = useState<'monthly' | 'yearly' | 'all_transactions'>('monthly');
  const [reportYear, setReportYear] = useState<number>(new Date().getFullYear());
  const [reportMonth, setReportMonth] = useState<number>(new Date().getMonth() + 1);

  const MOCK_TODAY_BASE = new Date(2025, 4, 28); // Consistent base date for mock data context
  
  const [summaryFilterMonth, setSummaryFilterMonth] = useState<number>(MOCK_TODAY_BASE.getMonth() + 1);
  const [summaryFilterYear, setSummaryFilterYear] = useState<number>(MOCK_TODAY_BASE.getFullYear());

  const summaryMonthOptions = Array.from({ length: 12 }, (_, i) => ({ value: (i + 1).toString(), label: new Date(0, i).toLocaleString('id-ID', { month: 'long' }) }));
  const summaryYearOptions = Array.from({ length: 5 }, (_, i) => ({ value: (MOCK_TODAY_BASE.getFullYear() - i).toString(), label: (MOCK_TODAY_BASE.getFullYear() - i).toString() }));


  const handleFinancialCardClick = useCallback((filterType: string) => {
    setActiveTransactionTableFilter(prev => prev === filterType ? null : filterType);
  }, []);

  const clearFinancialFilter = useCallback(() => {
    setActiveTransactionTableFilter(null);
  }, []);

  const processFilter = useCallback(() => {
    let tempFiltered = [...transactions];
    if (activeTransactionTableFilter) {
      if (activeTransactionTableFilter === 'Pemasukan') tempFiltered = tempFiltered.filter(t => t.type === 'Pemasukan');
      else if (activeTransactionTableFilter === 'Pengeluaran') tempFiltered = tempFiltered.filter(t => t.type === 'Pengeluaran');
      else if (activeTransactionTableFilter === 'Transfer') tempFiltered = tempFiltered.filter(t => t.category === 'Transfer Antar Kantong');
    }
    if (searchTerm) {
      tempFiltered = tempFiltered.filter(t => t.description.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    if (dateFilter) {
      tempFiltered = tempFiltered.filter(t => t.date.startsWith(dateFilter));
    }
    if (categoryFilter) {
      tempFiltered = tempFiltered.filter(t => t.category === categoryFilter);
    }
    if (typeFilter) {
      tempFiltered = tempFiltered.filter(t => t.type === typeFilter);
    }
    setFilteredTransactions(tempFiltered.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setCurrentPage(1);
  }, [transactions, searchTerm, dateFilter, categoryFilter, activeTransactionTableFilter, typeFilter]);

  useEffect(() => {
    processFilter();
  }, [processFilter]);

  const paginatedTransactions = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredTransactions.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredTransactions, currentPage, itemsPerPage]);

  const totalPages = useMemo(() => Math.ceil(filteredTransactions.length / itemsPerPage), [filteredTransactions, itemsPerPage]);

  const filteredTransactionsSummary = useMemo(() => {
    const totalIncome = filteredTransactions.filter(t => t.type === 'Pemasukan').reduce((sum, t) => sum + t.amount, 0);
    const totalExpense = filteredTransactions.filter(t => t.type === 'Pengeluaran').reduce((sum, t) => sum + t.amount, 0);
    return {
        totalIncome,
        totalExpense,
        netDifference: totalIncome - totalExpense,
    };
  }, [filteredTransactions]);


  const getSelectedPeriodTransactions = useCallback((month: number, year: number, periodType: 'month' | 'year') => {
    return transactions.filter(t => {
        const transactionDate = new Date(t.date);
        if (periodType === 'month') {
            return transactionDate.getMonth() + 1 === month && transactionDate.getFullYear() === year;
        }
        return transactionDate.getFullYear() === year; // For 'year'
    });
  }, [transactions]);


  const monthlyFinancialSummaries = useMemo((): FinancialSummaryCardProps[] => {
    const selectedMonthTransactions = getSelectedPeriodTransactions(summaryFilterMonth, summaryFilterYear, 'month');
    const incomeThisMonth = selectedMonthTransactions.filter(t => t.type === 'Pemasukan').reduce((sum, t) => sum + t.amount, 0);
    const expenseThisMonth = selectedMonthTransactions.filter(t => t.type === 'Pengeluaran').reduce((sum, t) => sum + t.amount, 0);
    const transferThisMonth = selectedMonthTransactions.filter(t => t.category === 'Transfer Antar Kantong' && t.type === 'Pemasukan').reduce((sum, t) => sum + t.amount, 0);
    
    const monthLabel = summaryMonthOptions.find(m => m.value === summaryFilterMonth.toString())?.label || '';

    return [
      { title: `Pemasukan (${monthLabel} ${summaryFilterYear})`, value: `${Currency.IDR} ${incomeThisMonth.toLocaleString('id-ID')}`, icon: <ArrowTrendingUpIcon />, onClick: () => handleFinancialCardClick('Pemasukan'), isActive: activeTransactionTableFilter === 'Pemasukan' },
      { title: `Pengeluaran (${monthLabel} ${summaryFilterYear})`, value: `${Currency.IDR} ${expenseThisMonth.toLocaleString('id-ID')}`, icon: <ArrowTrendingDownIcon />, onClick: () => handleFinancialCardClick('Pengeluaran'), isActive: activeTransactionTableFilter === 'Pengeluaran' },
      { title: `Transfer Masuk (${monthLabel} ${summaryFilterYear})`, value: `${Currency.IDR} ${transferThisMonth.toLocaleString('id-ID')}`, icon: <ArrowsRightLeftIcon />, onClick: () => handleFinancialCardClick('Transfer'), isActive: activeTransactionTableFilter === 'Transfer' },
    ];
  }, [getSelectedPeriodTransactions, summaryFilterMonth, summaryFilterYear, handleFinancialCardClick, activeTransactionTableFilter, summaryMonthOptions]);
  
  const yearlyFinancialSummaries = useMemo((): FinancialSummaryCardProps[] => {
    const selectedYearTransactions = getSelectedPeriodTransactions(summaryFilterMonth, summaryFilterYear, 'year'); // month is ignored for year
    const incomeThisYear = selectedYearTransactions.filter(t => t.type === 'Pemasukan').reduce((sum, t) => sum + t.amount, 0);
    const expenseThisYear = selectedYearTransactions.filter(t => t.type === 'Pengeluaran').reduce((sum, t) => sum + t.amount, 0);
    const transferInThisYear = selectedYearTransactions.filter(t => t.category === 'Transfer Antar Kantong' && t.type === 'Pemasukan').reduce((sum,t) => sum + t.amount, 0);
    const netProfitThisYear = incomeThisYear - expenseThisYear;
    return [
      { title: `Pemasukan (Thn ${summaryFilterYear})`, value: `${Currency.IDR} ${incomeThisYear.toLocaleString('id-ID')}`, icon: <ArrowTrendingUpIcon />, isPositive: true },
      { title: `Pengeluaran (Thn ${summaryFilterYear})`, value: `${Currency.IDR} ${expenseThisYear.toLocaleString('id-ID')}`, icon: <ArrowTrendingDownIcon /> },
      { title: `Transfer Masuk (Thn ${summaryFilterYear})`, value: `${Currency.IDR} ${transferInThisYear.toLocaleString('id-ID')}`, icon: <ArrowsRightLeftIcon /> },
      { title: `Profit Bersih (Thn ${summaryFilterYear})`, value: `${Currency.IDR} ${netProfitThisYear.toLocaleString('id-ID')}`, icon: <ChartPieIcon />, isPositive: netProfitThisYear >= 0 },
    ];
  }, [getSelectedPeriodTransactions, summaryFilterMonth, summaryFilterYear]);


  const totalKantongBalance = useMemo(() => kantongs.reduce((sum, k) => sum + k.balance, 0), [kantongs]);

  const handleOpenKantongDetail = (kantong: Kantong) => {
    setSelectedKantongForDetail(kantong);
    setIsKantongDetailModalOpen(true);
  };

  const getKantongIcon = (type: KantongType, className?: string) => {
    const kls = className || "w-6 h-6";
    switch(type) {
        case 'Bayar': return <BuildingStorefrontIcon className={`${kls} text-blue-500`}/>;
        case 'Nabung': return <SparklesIcon className={`${kls} text-yellow-500`}/>;
        case 'Terkunci': return <LockClosedIcon className={`${kls} text-red-500`}/>;
        case 'Bersama': return <GenericUsersIcon className={`${kls} text-purple-500`}/>;
        case 'Umum': default: return <WalletIcon className={`${kls} text-gray-500`}/>;
    }
  };

  const KantongCardDisplay: React.FC<{kantong: Kantong}> = ({kantong}) => {
    const progress = kantong.type === 'Nabung' && kantong.targetAmount && kantong.targetAmount > 0
                     ? Math.min((kantong.balance / kantong.targetAmount) * 100, 100)
                     : null;
    return (
        <Card
            className="flex flex-col justify-between hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => handleOpenKantongDetail(kantong)}
        >
            <div>
                <div className="flex items-center justify-between mb-2">
                    <span className="p-2 bg-indigo-100 rounded-full">
                        {getKantongIcon(kantong.type, "w-5 h-5")}
                    </span>
                    <Badge text={kantong.type} color={
                        kantong.type === 'Bayar' ? 'blue' :
                        kantong.type === 'Nabung' ? 'yellow' :
                        kantong.type === 'Terkunci' ? 'red' :
                        kantong.type === 'Bersama' ? 'purple' : 'gray'
                    }/>
                </div>
                <h4 className="text-md font-semibold text-gray-800 truncate" title={kantong.name}>{kantong.name}</h4>
                <p className="text-xl font-bold text-indigo-600 my-1">{Currency.IDR} {kantong.balance.toLocaleString('id-ID')}</p>
                {kantong.description && <p className="text-xs text-gray-500 truncate" title={kantong.description}>{kantong.description}</p>}
            </div>
            {progress !== null && kantong.targetAmount && (
                <div className="mt-3">
                    <div className="flex justify-between text-xs text-gray-500 mb-0.5">
                        <span>Progress</span>
                        <span>{Currency.IDR} {kantong.targetAmount.toLocaleString('id-ID')}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                        <div
                            className="bg-yellow-500 h-1.5 rounded-full"
                            style={{ width: `${progress}%` }}
                            role="progressbar"
                            aria-valuenow={progress}
                            aria-label={`Progress tabungan ${kantong.name}`}
                        ></div>
                    </div>
                </div>
            )}
             <div className="mt-3 pt-2 border-t border-gray-100 flex justify-end items-center space-x-1">
                 <Button variant="ghost" size="xs" onClick={(e) => { e.stopPropagation(); setDefaultSourceKantongIdForTransfer(kantong.id); setIsTransferKantongModalOpen(true); }} title="Transfer Cepat">
                    <ArrowsRightLeftIcon className="w-4 h-4 text-green-500"/>
                </Button>
                <Button variant="ghost" size="xs" onClick={(e) => { e.stopPropagation(); setEditingKantong(kantong); setIsAddKantongModalOpen(true); }} title="Edit Kantong">
                    <PencilSquareIcon className="w-4 h-4 text-blue-500"/>
                </Button>
            </div>
        </Card>
    );
  };


  const getTransactionTypeColor = (type: 'Pemasukan' | 'Pengeluaran') => type === 'Pemasukan' ? 'text-green-600 font-semibold' : 'text-red-600 font-semibold';
  const getTransactionBadgeColor = (type: 'Pemasukan' | 'Pengeluaran'): 'green' | 'red' => type === 'Pemasukan' ? 'green' : 'red';

  const transactionColumns: TableColumn<Transaction>[] = [
    { key: 'date', header: 'Tanggal', render: (t) => new Date(t.date).toLocaleDateString('id-ID')},
    { key: 'description', header: 'Deskripsi', width: "30%" },
    { key: 'category', header: 'Kategori', render: (t) => <Badge text={t.category} color="gray" /> },
    { key: 'type', header: 'Jenis', render: (t) => <Badge text={t.type} color={getTransactionBadgeColor(t.type)} /> },
    { key: 'amount', header: 'Jumlah', render: (t) => <span className={getTransactionTypeColor(t.type)}>{Currency.IDR} {t.amount.toLocaleString('id-ID')}</span>},
    { key: 'kantongId', header: 'Kantong', render: (t) => kantongs.find(k => k.id === t.kantongId)?.name || '-' },
    {
        key: 'document',
        header: 'Dokumen',
        render: (t: Transaction) => {
            if (!t.invoiceId) return <span className="text-gray-400">-</span>;
            let docNumber: string | undefined;
            let onClickAction: (() => void) | undefined;

            if (t.type === 'Pemasukan') {
                const clientInvoice = allClients.flatMap(c => c.invoices || []).find(inv => inv.id === t.invoiceId);
                const generalReceipt = generalReceipts.find(r => r.id === t.invoiceId);
                const foundDoc = clientInvoice || generalReceipt;
                if (foundDoc) {
                    docNumber = foundDoc.invoiceNumber;
                    onClickAction = () => openViewInvoiceModalById(t.invoiceId!, foundDoc.clientId);
                }
            } else {
                const expenseVoucher = expenseVouchers.find(v => v.id === t.invoiceId);
                if (expenseVoucher) {
                    docNumber = expenseVoucher.voucherNumber;
                    onClickAction = () => openViewExpenseVoucherModal(t.invoiceId!);
                }
            }

            if (docNumber && onClickAction) {
                return (
                    <Button
                        variant="link"
                        size="xs"
                        title={docNumber}
                        onClick={onClickAction}
                        className="p-0 text-indigo-600 hover:text-indigo-700 text-xs"
                    >
                       {docNumber}
                    </Button>
                );
            }
            return <span className="text-gray-400">-</span>;
        }
    },
    { key: 'actions', header: 'Aksi', render: (t) => (
      <Button variant="ghost" size="sm" onClick={() => { setEditingTransaction(t); setIsAddTransactionModalOpen(true); }}><PencilSquareIcon className="w-4 h-4 text-blue-600" /></Button>
    )},
  ];

  const autoBudgetRuleColumns: TableColumn<AutoBudgetRule>[] = [
    { key: 'description', header: 'Deskripsi' },
    { key: 'sourceKantongId', header: 'Sumber', render: (r) => r.sourceKantongId ? kantongs.find(k => k.id === r.sourceKantongId)?.name || 'N/A' : 'Saldo Utama' },
    { key: 'destinationKantongId', header: 'Tujuan', render: (r) => kantongs.find(k => k.id === r.destinationKantongId)?.name || 'N/A' },
    { key: 'amount', header: 'Jumlah', render: (r) => `${Currency.IDR} ${r.amount.toLocaleString('id-ID')}`},
    { key: 'frequency', header: 'Frekuensi', render: (r) => `${r.frequency}${r.dayOfMonth ? ` (Tgl ${r.dayOfMonth})` : ''}`},
    { key: 'isActive', header: 'Status', render: (r) => <Badge text={r.isActive ? 'Aktif' : 'Nonaktif'} color={r.isActive ? 'green' : 'gray'} /> },
    { key: 'actions', header: 'Aksi', render: (r) => (
        <div className="flex space-x-1">
            <Button variant="ghost" size="sm" onClick={() => { setEditingAutoBudgetRule(r); setIsAddAutoBudgetModalOpen(true);}}><PencilSquareIcon className="w-4 h-4 text-blue-600" /></Button>
            <Button variant="ghost" size="sm" onClick={() => onDeleteAutoBudgetRule(r.id)}><TrashIcon className="w-4 h-4 text-red-500" /></Button>
        </div>
    )},
  ];

  const scheduledTransferColumns: TableColumn<ScheduledTransfer>[] = [
    { key: 'description', header: 'Deskripsi' },
    { key: 'sourceKantongId', header: 'Sumber', render: (st) => kantongs.find(k => k.id === st.sourceKantongId)?.name || 'N/A' },
    { key: 'recipientType', header: 'Penerima', render: (st) => st.recipientType === 'internal_kantong' ? (kantongs.find(k => k.id === st.destinationKantongId)?.name || 'Internal') : st.externalRecipientName || 'Eksternal' },
    { key: 'amount', header: 'Jumlah', render: (st) => `${Currency.IDR} ${st.amount.toLocaleString('id-ID')}`},
    { key: 'frequency', header: 'Frekuensi', render: (st) => `${st.frequency} (mulai ${new Date(st.startDate).toLocaleDateString('id-ID')})`},
    { key: 'isActive', header: 'Status', render: (st) => <Badge text={st.isActive ? 'Aktif' : 'Nonaktif'} color={st.isActive ? 'green' : 'gray'} /> },
    { key: 'actions', header: 'Aksi', render: (st) => (
        <div className="flex space-x-1">
            <Button variant="ghost" size="sm" onClick={() => { setEditingScheduledTransfer(st); setIsAddScheduledTransferModalOpen(true);}}><PencilSquareIcon className="w-4 h-4 text-blue-600" /></Button>
            <Button variant="ghost" size="sm" onClick={() => onDeleteScheduledTransfer(st.id)}><TrashIcon className="w-4 h-4 text-red-500" /></Button>
        </div>
    )},
  ];

  const dateFilterOptions = useMemo(() => {
    const uniqueMonths = Array.from(new Set(transactions.map(t => t.date.substring(0, 7)))).sort().reverse();
    return [{value:'', label:'Semua Waktu'}, ...uniqueMonths.map(month => ({value: month, label: new Date(month + '-02').toLocaleString('id-ID', {month:'long', year:'numeric'})}))];
  }, [transactions]);

  const categoryFilterOptions = useMemo(() => {
    const uniqueCategories = Array.from(new Set(transactions.map(t => t.category))).sort();
    return [{value:'', label:'Semua Kategori'}, ...uniqueCategories.map(cat => ({value: cat, label: cat}))];
  }, [transactions]);

  const typeFilterOptions = [
    { value: '', label: 'Semua Jenis' },
    { value: 'Pemasukan', label: 'Pemasukan' },
    { value: 'Pengeluaran', label: 'Pengeluaran' },
  ];

  const transactionTableEmptyState = (
    <div className="text-center py-10">
        <DocumentTextIcon className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">Belum ada transaksi</h3>
        <p className="mt-1 text-sm text-gray-500">Mulai dengan menambahkan transaksi pertama Anda.</p>
        <div className="mt-6">
            <Button onClick={() => { setEditingTransaction(null); setIsAddTransactionModalOpen(true); }} leftIcon={<PlusCircleIcon className="w-5 h-5" />} variant="primary">
                Tambah Transaksi Baru
            </Button>
        </div>
    </div>
  );

  const monthlyCategorySummary = useMemo(() => {
    const selectedPeriodTransactions = transactions.filter(t => {
        const transactionDate = new Date(t.date);
        return transactionDate.getFullYear() === reportYear && transactionDate.getMonth() + 1 === reportMonth;
    });

    const summary: Record<string, { income: number, expense: number }> = {};

    selectedPeriodTransactions.forEach(t => {
        if (!summary[t.category]) {
            summary[t.category] = { income: 0, expense: 0 };
        }
        if (t.type === 'Pemasukan') {
            summary[t.category].income += t.amount;
        } else {
            summary[t.category].expense += t.amount;
        }
    });
    return Object.entries(summary).map(([category, totals]) => ({ category, ...totals }));
  }, [transactions, reportYear, reportMonth]);


  const DaftarTransaksiTab: React.FC = () => (
    <>
      <div className="mb-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 items-end">
        <Input type="text" placeholder="Cari deskripsi..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} wrapperClassName="col-span-1 sm:col-span-2 md:col-span-1"/>
        <UiSelect options={dateFilterOptions} value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} wrapperClassName="col-span-1"/>
        <UiSelect options={categoryFilterOptions} value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} wrapperClassName="col-span-1"/>
        <UiSelect options={typeFilterOptions} value={typeFilter} onChange={(e) => setTypeFilter(e.target.value as any)} wrapperClassName="col-span-1"/>
        {activeTransactionTableFilter && (
          <Button variant="outline" onClick={clearFinancialFilter} className="h-10 col-span-1">
            Hapus Filter ({activeTransactionTableFilter}) <XCircleIcon className="w-4 h-4 ml-1.5 text-gray-500"/>
          </Button>
        )}
      </div>
      <Table columns={transactionColumns} data={paginatedTransactions} rowKey="id" emptyStateNode={transactionTableEmptyState} />
      {totalPages > 1 && (
        <div className="mt-4 flex justify-center items-center space-x-2">
          <Button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>Sebelumnya</Button>
          <span className="text-sm text-gray-600">Hal {currentPage} dari {totalPages}</span>
          <Button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>Berikutnya</Button>
        </div>
      )}
      {filteredTransactions.length > 0 && (
          <div className="mt-6 p-4 border-t border-gray-200 bg-slate-50 rounded-b-lg">
              <h4 className="text-md font-semibold text-gray-700 mb-2">Ringkasan Transaksi Terfilter:</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                  <div className="p-2 bg-green-50 border border-green-200 rounded">
                      <p className="text-xs text-green-700">Total Pemasukan:</p>
                      <p className="font-bold text-green-600 text-lg">{Currency.IDR} {filteredTransactionsSummary.totalIncome.toLocaleString('id-ID')}</p>
                  </div>
                  <div className="p-2 bg-red-50 border border-red-200 rounded">
                      <p className="text-xs text-red-700">Total Pengeluaran:</p>
                      <p className="font-bold text-red-600 text-lg">{Currency.IDR} {filteredTransactionsSummary.totalExpense.toLocaleString('id-ID')}</p>
                  </div>
                  <div className={`p-2 rounded ${filteredTransactionsSummary.netDifference >= 0 ? 'bg-blue-50 border-blue-200' : 'bg-orange-50 border-orange-200'}`}>
                      <p className={`text-xs ${filteredTransactionsSummary.netDifference >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>Selisih (Net):</p>
                      <p className={`font-bold text-lg ${filteredTransactionsSummary.netDifference >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>{Currency.IDR} {filteredTransactionsSummary.netDifference.toLocaleString('id-ID')}</p>
                  </div>
              </div>
          </div>
      )}
    </>
  );

  const KantongDanaTab: React.FC = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 p-1">
        {kantongs.length === 0 && (
             <div className="col-span-full text-center py-12 text-gray-500">
                <WalletIcon className="w-16 h-16 mx-auto mb-4 text-gray-400"/>
                <h3 className="text-lg font-medium text-gray-700">Belum Ada Kantong Dana</h3>
                <p className="mt-1">Buat kantong dana untuk mengelola keuangan Anda lebih terstruktur.</p>
                <Button
                    onClick={() => { setEditingKantong(null); setIsAddKantongModalOpen(true); }}
                    leftIcon={<PlusCircleIcon className="w-5 h-5" />}
                    variant="primary"
                    className="mt-6"
                >
                    Buat Kantong Baru
                </Button>
            </div>
        )}
        {kantongs.map(k => <KantongCardDisplay key={k.id} kantong={k} />)}
    </div>
  );

  const AutoBudgetTab: React.FC = () => (
    <>
      <Table columns={autoBudgetRuleColumns} data={autoBudgetRules} rowKey="id" emptyStateMessage="Belum ada aturan auto-budget."/>
       <p className="text-xs text-gray-500 mt-3 italic">
        * Eksekusi aturan auto-budget dan transfer terjadwal saat ini bersifat simulasi dan tidak berjalan otomatis di latar belakang.
      </p>
    </>
  );

  const TransferTerjadwalTab: React.FC = () => (
    <>
        <Table columns={scheduledTransferColumns} data={scheduledTransfers} rowKey="id" emptyStateMessage="Belum ada transfer terjadwal."/>
        <p className="text-xs text-gray-500 mt-3 italic">
          * Eksekusi aturan auto-budget dan transfer terjadwal saat ini bersifat simulasi dan tidak berjalan otomatis di latar belakang.
        </p>
    </>
  );

  const LaporanDownloadTab: React.FC = () => {
    const currentYearForReport = new Date().getFullYear();
    const yearOptionsForReport = Array.from({ length: 10 }, (_, i) => ({ value: (currentYearForReport - i).toString(), label: (currentYearForReport - i).toString() }));
    const monthOptionsForReport = Array.from({ length: 12 }, (_, i) => ({ value: (i + 1).toString(), label: new Date(0, i).toLocaleString('id-ID', { month: 'long' }) }));

    const handleDownload = () => {
        let transactionsToReport = [...transactions];
        let reportFileName = "Laporan_Transaksi";

        if (reportType === 'monthly') {
            transactionsToReport = transactions.filter(t => {
                const transactionDate = new Date(t.date);
                return transactionDate.getFullYear() === reportYear && transactionDate.getMonth() + 1 === reportMonth;
            });
            reportFileName += `_Bulanan_${reportMonth}-${reportYear}.csv`;
        } else if (reportType === 'yearly') {
            transactionsToReport = transactions.filter(t => new Date(t.date).getFullYear() === reportYear);
            reportFileName += `_Tahunan_${reportYear}.csv`;
        } else {
            reportFileName += `_Semua.csv`;
        }

        if (transactionsToReport.length === 0) {
            addToast("Tidak ada data transaksi untuk periode yang dipilih.", 'warning');
            return;
        }

        const headers = ["Tanggal", "Deskripsi", "Kategori", "Jenis", "Jumlah", "Metode", "Kantong", "No. Invoice/Voucher"].map(escapeCsvCell);
        const csvDataRows = transactionsToReport.map(t => {
            let docNumber = '';
            if (t.invoiceId) {
                if (t.type === 'Pemasukan') {
                    const inv = allClients.flatMap(c => c.invoices || []).find(i => i.id === t.invoiceId) || generalReceipts.find(r => r.id === t.invoiceId);
                    docNumber = inv?.invoiceNumber || t.invoiceId;
                } else {
                    const vouch = expenseVouchers.find(v => v.id === t.invoiceId);
                    docNumber = vouch?.voucherNumber || t.invoiceId;
                }
            }
            return [
                escapeCsvCell(t.date),
                escapeCsvCell(t.description),
                escapeCsvCell(t.category),
                escapeCsvCell(t.type),
                escapeCsvCell(t.amount),
                escapeCsvCell(t.method),
                escapeCsvCell(kantongs.find(k => k.id === t.kantongId)?.name),
                escapeCsvCell(docNumber)
            ].join(',');
        });

        const csvContent = [headers.join(','), ...csvDataRows].join('\n');
        downloadCSV(csvContent, reportFileName);
        addToast(`Laporan ${reportFileName} berhasil diunduh.`, 'success');
    };

    return (
        <div className="space-y-6 p-1">
            <div className="p-4 border rounded-lg bg-slate-50">
                <h4 className="text-lg font-semibold text-gray-700">Unduh Laporan Keuangan</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end my-3">
                    <UiSelect
                        label="Jenis Laporan"
                        options={[
                            { value: 'monthly', label: 'Laporan Transaksi Bulanan' },
                            { value: 'yearly', label: 'Laporan Transaksi Tahunan' },
                            { value: 'all_transactions', label: 'Semua Transaksi' },
                        ]}
                        value={reportType}
                        onChange={(e) => setReportType(e.target.value as 'monthly' | 'yearly' | 'all_transactions')}
                    />
                    {reportType !== 'all_transactions' && (
                        <UiSelect
                            label="Tahun"
                            options={yearOptionsForReport}
                            value={reportYear.toString()}
                            onChange={(e) => setReportYear(parseInt(e.target.value))}
                        />
                    )}
                    {reportType === 'monthly' && (
                        <UiSelect
                            label="Bulan"
                            options={monthOptionsForReport}
                            value={reportMonth.toString()}
                            onChange={(e) => setReportMonth(parseInt(e.target.value))}
                        />
                    )}
                </div>
                <Button onClick={handleDownload} leftIcon={<ArrowDownTrayIcon className="w-5 h-5"/>} variant="primary" className="mt-1">
                    Unduh Laporan CSV
                </Button>
                 <p className="text-xs text-gray-500 mt-2">
                    Laporan laba/rugi dan neraca lebih kompleks dan idealnya dihasilkan oleh sistem backend.
                </p>
            </div>

            {(reportType === 'monthly' || reportType === 'yearly') && (
                 <div className="p-4 border rounded-lg bg-white mt-4">
                    <h4 className="text-lg font-semibold text-gray-700 mb-3">
                        Ringkasan per Kategori ({reportType === 'monthly' ? `${monthOptionsForReport.find(m=>m.value === reportMonth.toString())?.label} ${reportYear}` : `Tahun ${reportYear}`})
                    </h4>
                    {monthlyCategorySummary.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                            {monthlyCategorySummary.map(item => (
                                <div key={item.category} className="p-2 border rounded bg-slate-50">
                                    <p className="font-medium text-gray-700">{item.category}</p>
                                    {item.income > 0 && <p className="text-green-600">Pemasukan: {Currency.IDR} {item.income.toLocaleString('id-ID')}</p>}
                                    {item.expense > 0 && <p className="text-red-600">Pengeluaran: {Currency.IDR} {item.expense.toLocaleString('id-ID')}</p>}
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="text-gray-500 text-center py-3">Tidak ada data untuk ringkasan kategori pada periode ini.</p>
                    )}
                </div>
            )}
        </div>
    );
  };


  const mainTabs: TabItem[] = [
    { id: 'transaksi', label: 'Daftar Transaksi', content: <DaftarTransaksiTab /> },
    { id: 'kantong', label: 'Kantong Dana', content: <KantongDanaTab /> },
    { id: 'auto-budget', label: 'Auto-Budgeting', content: <AutoBudgetTab /> },
    { id: 'transfer-terjadwal', label: 'Transfer Terjadwal', content: <TransferTerjadwalTab /> },
    { id: 'laporan', label: 'Laporan Keuangan', content: <LaporanDownloadTab /> },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-2xl font-semibold text-gray-800">Manajemen Keuangan</h2>
        <div className="flex space-x-2 flex-wrap gap-y-2">
          <Button onClick={() => { setEditingKantong(null); setIsAddKantongModalOpen(true); }} leftIcon={<WalletIcon className="w-4 h-4"/>} size="sm">Tambah Kantong</Button>
          <Button onClick={() => { setDefaultSourceKantongIdForTransfer(undefined); setIsTransferKantongModalOpen(true);}} leftIcon={<ArrowsRightLeftIcon className="w-4 h-4"/>} size="sm">Transfer Dana</Button>
          <Button onClick={() => { setEditingTransaction(null); setIsAddTransactionModalOpen(true); }} leftIcon={<PlusCircleIcon className="w-5 h-5" />} variant="primary" size="sm">Tambah Transaksi</Button>
        </div>
      </div>

      <div className="mb-6 p-4 bg-white shadow rounded-lg border border-gray-200/75">
          <h3 className="text-md font-semibold text-gray-700 mb-3">Filter Ringkasan Cepat:</h3>
          <div className="flex items-end gap-3">
              <UiSelect
                  label="Pilih Bulan"
                  options={summaryMonthOptions}
                  value={summaryFilterMonth.toString()}
                  onChange={(e) => setSummaryFilterMonth(parseInt(e.target.value))}
                  wrapperClassName="flex-grow"
              />
              <UiSelect
                  label="Pilih Tahun"
                  options={summaryYearOptions}
                  value={summaryFilterYear.toString()}
                  onChange={(e) => setSummaryFilterYear(parseInt(e.target.value))}
                  wrapperClassName="flex-grow"
              />
          </div>
      </div>


      <Card className="p-0">
        <div className="px-5 py-4 border-b flex flex-col sm:flex-row items-start sm:items-center justify-between bg-gray-50 rounded-t-xl">
            <h3 className="text-lg font-semibold text-gray-700 flex items-center mb-2 sm:mb-0">
                <ChartPieIcon className="w-6 h-6 mr-2 text-indigo-500"/> Ringkasan Finansial ({summaryMonthOptions.find(m=>m.value === summaryFilterMonth.toString())?.label} {summaryFilterYear})
            </h3>
            <div className="text-lg sm:text-xl font-bold text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-md">
                Total Saldo Semua Kantong: {Currency.IDR} {totalKantongBalance.toLocaleString('id-ID')}
            </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-5">
            {monthlyFinancialSummaries.map(summary => (
                <Card
                    key={summary.title}
                    className={`flex-1 min-w-[180px] shadow-md hover:shadow-indigo-200 transition-shadow duration-150 ${summary.onClick ? 'cursor-pointer' : ''} ${summary.isActive ? 'ring-2 ring-indigo-500 shadow-indigo-200' : 'border-gray-200'}`}
                    onClick={summary.onClick}
                    contentClassName="p-4"
                >
                    <div className="flex items-center justify-between">
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide truncate">{summary.title}</p>
                        <div className={`text-gray-400 ${summary.isActive ? 'text-indigo-600': ''}`}>{React.cloneElement(summary.icon, { className: "w-5 h-5" })}</div>
                    </div>
                    <p className={`text-xl font-bold ${summary.isActive ? 'text-indigo-700': 'text-gray-800'} mt-1`}>{summary.value}</p>
                </Card>
            ))}
        </div>
      </Card>

      <Card className="p-0">
        <div className="px-5 py-4 border-b flex flex-col sm:flex-row items-start sm:items-center justify-between bg-gray-50 rounded-t-xl">
            <h3 className="text-lg font-semibold text-gray-700 flex items-center mb-2 sm:mb-0">
                <DocumentChartBarIcon className="w-6 h-6 mr-2 text-teal-500"/> Ringkasan Finansial (Tahun {summaryFilterYear})
            </h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-5">
            {yearlyFinancialSummaries.map(summary => (
                <Card
                    key={summary.title}
                    className={`flex-1 min-w-[180px] shadow-md hover:shadow-teal-200 transition-shadow duration-150 border-gray-200`}
                    contentClassName="p-4"
                >
                    <div className="flex items-center justify-between">
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide truncate">{summary.title}</p>
                        <div className={`text-gray-400`}>{React.cloneElement(summary.icon, { className: `w-5 h-5 ${summary.isPositive === true ? 'text-green-500' : summary.isPositive === false ? 'text-red-500' : 'text-gray-400' }` })}</div>
                    </div>
                    <p className={`text-xl font-bold ${summary.isPositive === true ? 'text-green-700' : summary.isPositive === false ? 'text-red-700' : 'text-gray-800'} mt-1`}>{summary.value}</p>
                </Card>
            ))}
        </div>
      </Card>


      <Card>
          <div className="flex justify-end gap-2 mb-4 -mt-1">
             <Button variant="outline" size="sm" onClick={() => { setEditingAutoBudgetRule(null); setIsAddAutoBudgetModalOpen(true); }} leftIcon={<Cog6ToothIcon className="w-4 h-4"/>}>Aturan Auto-Budget</Button>
             <Button variant="outline" size="sm" onClick={() => { setEditingScheduledTransfer(null); setIsAddScheduledTransferModalOpen(true); }} leftIcon={<CalendarDaysIcon className="w-4 h-4"/>}>Transfer Terjadwal</Button>
          </div>
          <Tabs tabs={mainTabs} initialTabId="transaksi" />
      </Card>

      {isAddTransactionModalOpen && (
        <AddTransactionModal
          isOpen={isAddTransactionModalOpen}
          onClose={() => { setIsAddTransactionModalOpen(false); setEditingTransaction(null); }}
          onSave={(trans) => { addTransaction(trans); setIsAddTransactionModalOpen(false); }}
          existingTransaction={editingTransaction}
          systemOptions={systemOptions}
          allClients={allClients}
          allProjects={allProjects}
          allFreelancers={allFreelancers}
          addToast={addToast}
        />
      )}
      {isAddKantongModalOpen && (
        <AddKantongModal
          isOpen={isAddKantongModalOpen}
          onClose={() => { setIsAddKantongModalOpen(false); setEditingKantong(null);}}
          onSave={(kantong) => {
            if (editingKantong) updateKantong(kantong); else addKantong(kantong);
            setIsAddKantongModalOpen(false);
          }}
          existingKantong={editingKantong}
          systemOptions={systemOptions}
          addToast={addToast}
        />
      )}
      {isTransferKantongModalOpen && (
        <TransferKantongModal
            isOpen={isTransferKantongModalOpen}
            onClose={() => setIsTransferKantongModalOpen(false)}
            onTransfer={onTransferAntarKantong}
            kantongs={kantongs}
            defaultSourceKantongId={defaultSourceKantongIdForTransfer}
            addToast={addToast}
        />
      )}
      {selectedKantongForDetail && isKantongDetailModalOpen && (
        <KantongDetailModal
            isOpen={isKantongDetailModalOpen}
            onClose={() => setIsKantongDetailModalOpen(false)}
            kantong={selectedKantongForDetail}
            transactions={transactions}
            onEditKantong={(k) => { setEditingKantong(k); setIsAddKantongModalOpen(true); setIsKantongDetailModalOpen(false); }}
            onDeleteKantong={(id) => { deleteKantong(id); setIsKantongDetailModalOpen(false); }}
            onTransferAntarKantong={onTransferAntarKantong}
            allKantongs={kantongs}
            addToast={addToast}
        />
      )}
       {isAddAutoBudgetModalOpen && (
        <AddAutoBudgetRuleModal
            isOpen={isAddAutoBudgetModalOpen}
            onClose={() => { setIsAddAutoBudgetModalOpen(false); setEditingAutoBudgetRule(null); }}
            onSave={(rule) => {
                if(editingAutoBudgetRule) onUpdateAutoBudgetRule({...editingAutoBudgetRule, ...rule});
                else onAddAutoBudgetRule(rule);
                setIsAddAutoBudgetModalOpen(false);
            }}
            kantongs={kantongs}
            systemOptions={systemOptions}
            existingRule={editingAutoBudgetRule}
            addToast={addToast}
        />
      )}
      {isAddScheduledTransferModalOpen && (
        <AddScheduledTransferModal
            isOpen={isAddScheduledTransferModalOpen}
            onClose={() => { setIsAddScheduledTransferModalOpen(false); setEditingScheduledTransfer(null);}}
            onSave={(transfer) => {
                if(editingScheduledTransfer) onUpdateScheduledTransfer({...editingScheduledTransfer, ...transfer});
                else onAddScheduledTransfer(transfer);
                setIsAddScheduledTransferModalOpen(false);
            }}
            kantongs={kantongs}
            systemOptions={systemOptions}
            existingTransfer={editingScheduledTransfer}
            addToast={addToast}
        />
      )}
    </div>
  );
};

export default KeuanganPage;
