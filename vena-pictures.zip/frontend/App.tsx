// frontend/App.tsx
import React, { useState, useEffect, useCallback } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from '../components/Sidebar'; // Adjusted path
import DashboardPage from '../components/pages/DashboardPage'; // Adjusted path
import KlienPage from '../components/pages/KlienPage'; // Adjusted path
import ProyekPage from '../components/pages/ProyekPage'; // Adjusted path
import FreelancerPage from '../components/pages/FreelancerPage'; // Adjusted path
import ProyekFreelancerPage from '../components/pages/ProyekFreelancerPage'; // Adjusted path
import KeuanganPage from '../components/pages/KeuanganPage'; // Adjusted path
import KpiKlienPage from '../components/pages/KpiKlienPage'; // Adjusted path
import KpiAdminPage from '../components/pages/KpiAdminPage'; // Adjusted path
import KalenderPage from '../components/pages/KalenderPage'; // Adjusted path
import NotifikasiPage from '../components/pages/NotifikasiPage'; // Adjusted path
import PengaturanPage from '../components/pages/PengaturanPage'; // Adjusted path
import LoginPage from '../components/auth/LoginPage'; // Adjusted path
import {
  Transaction, Project, Client, FreelancerProject, Package, AddOn, 
  Freelancer, CalendarEvent, PaymentRecord, Task, CommunicationEntry, 
  UserProfile, Invoice, InvoiceItem, InvoiceStatus, ExpenseVoucher, ProjectStatus,
  NavigationItemKey, BankDetail, SystemOptions, AppModalState, Kantong, ActivityItem, ProjectDocument, AutoBudgetRule, ScheduledTransfer, ChatEvaluationEntry, PaymentStatus as FreelancerPaymentStatus, NotificationItem, NotificationSettings, ToastMessage, KANTONG_TYPES
} from './types'; // types.ts is in the same 'frontend' directory
import * as API from './src/services/api'; // api.ts is in 'frontend/src/services/'
import ProyekDetailModal from '../components/proyek/ProyekDetailModal'; // Adjusted path
import FreelancerDetailModal from '../components/freelancer/FreelancerDetailModal'; // Adjusted path
import FreelancerEarningsModal from '../components/freelancer/FreelancerEarningsModal'; // Adjusted path
import PayFreelancerModal from '../components/freelancer/PayFreelancerModal'; // Adjusted path
import SavingsWithdrawalModal from '../components/freelancer/SavingsWithdrawalModal'; // Adjusted path
import RecordSavingsDepositModal from '../components/freelancer/RecordSavingsDepositModal'; // Adjusted path 
import ViewInvoiceModal from '../components/klien/ViewInvoiceModal'; // Adjusted path
import FreelancerPaymentVoucherModal from '../components/freelancer/FreelancerPaymentVoucherModal'; // Adjusted path
import ViewExpenseVoucherModal from '../components/keuangan/ViewExpenseVoucherModal'; // Adjusted path
import ToastContainer from '../components/ui/Toast'; // Adjusted path
import { Bars3Icon, DEFAULT_AVATAR_URL } from './constants'; // Corrected path for constants
import firebase from 'firebase/compat/app'; // For FieldValue

const initialNotificationSettings: NotificationSettings = {
  deadlineProject: true,
  deadlineTask: true,
  contractEnd: true,
  lowBalance: true,
  paymentReceived: true,
  generalReminder: true,
};

const initialUserProfile: UserProfile = {
  id: '', 
  avatarUrl: '', 
  fullName: 'Pengguna Baru', 
  email: '',
  username: '',
  phone: '',
  companyName: 'Vena Pictures', 
  companyAddress: '',
  companyPhone: '',
  companyEmail: '',
  companyWebsite: '',
  bio: '',
  address: '',
  website: '',
  invoiceLogoUrl: '',
  invoiceTerms: 'Pembayaran jatuh tempo dalam 14 hari.',
  invoiceFooter: 'Terima kasih telah menggunakan layanan kami!',
  notificationSettings: initialNotificationSettings,
};

const initialSystemOptions: SystemOptions = {
  projectTypes: ["Wedding Photography", "Prewedding Photo", "Event Documentation", "Corporate Video", "Product Shoot", "Engagement Photo", "Dokumentasi Korporat", "Other"],
  transactionCategories: ["Pemasukan Proyek", "Fee Proyek", "Biaya Operasional", "Sewa Alat", "Transportasi", "Gaji Tim", "Pemasukan Lain", "Pengeluaran Lain", "Transfer Antar Kantong", "Setoran Tabungan Tim", "Penarikan Tabungan Tim"],
  transactionMethods: ["Transfer Bank BCA", "Transfer Bank Mandiri", "Tunai", "QRIS", "Lainnya", "Internal", "Transfer Bank BSI"],
  freelancerRoles: ["Fotografer", "Videografer", "Editor", "Editor Foto", "Editor Video", "Asisten", "Asisten Fotografer", "MUA", "Tim Internal", "Pilot Drone", "Desainer Grafis", "Admin Media Sosial"],
  packageTypes: ["Pernikahan", "Prewedding", "Lainnya", "Lamaran", "Korporat", "Acara Korporat", "Acara Pribadi", "Produk"],
  calendarEventTypes: [{value: "projectClient", label:"Acara Klien"}, {value:"projectDeadline", label:"Deadline Proyek Klien"}, {value:"projectFreelancerMilestone", label:"Milestone Proyek Freelancer"}, {value:"projectTaskDeadline", label:"Deadline Tugas Proyek"}, {value:"contractReminder", label:"Pengingat Kontrak"}, {value:"reminder", label:"Pengingat Umum"}, {value:"meeting", label:"Rapat"}, {value:"personal", label:"Pribadi"}, {value:"projectFreelancer", label:"Proyek Freelancer (Umum)"} ],
  clientSources: ["Instagram", "Facebook", "Rekomendasi Teman", "Website", "Pameran Wedding", "Vendor Lain"],
  clientTags: ["VIP", "Budget Terbatas", "Luar Kota", "Bridestory"],
  communicationTypes: [{value: 'Telepon', label: 'Telepon'}, {value: 'Rapat', label: 'Rapat'}, {value:'Email', label:'Email'}, {value:'WhatsApp', label:'WhatsApp'}, {value:'Zoom Meeting', label:'Zoom Meeting'}, {value:'Lainnya', label:'Lainnya'}],
  taskPriorities: [ {value: 'Rendah', label: 'Rendah'}, {value: 'Sedang', label: 'Sedang'}, {value: 'Tinggi', label: 'Tinggi'}],
  detailedDeliverableStatusOptions: [ {value: 'Pending', label: 'Pending'}, {value: 'Submitted', label: 'Submitted'}, {value: 'Approved', label: 'Approved'}, {value: 'Revision Needed', label: 'Revision Needed'} ], 
  kantongTypes: KANTONG_TYPES.map(kt => ({value: kt, label: kt})),
  clientRegions: ["Jakarta", "Bandung", "Surabaya", "Bali", "Luar Jawa", "Internasional"],
  chatChannels: ["WhatsApp Admin 1", "WhatsApp Admin 2", "Instagram DM", "Email Utama", "Telepon Kantor"],
  chatStatuses: ["Baru Masuk", "Sedang Ditangani", "Menunggu Respon Klien", "Selesai (Deal)", "Selesai (Tidak Deal)", "Follow Up Berkala"],
};


function App(): React.ReactElement {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
  const [freelancerProjects, setFreelancerProjects] = useState<FreelancerProject[]>([]);
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);
  const [packages, setPackages] = useState<Package[]>([]);
  const [addOns, setAddOns] = useState<AddOn[]>([]);
  const [bankDetails, setBankDetails] = useState<BankDetail[]>([]);
  const [systemOptions, setSystemOptions] = useState<SystemOptions>(initialSystemOptions);
  const [userProfile, setUserProfile] = useState<UserProfile>(initialUserProfile);
  const [kantongs, setKantongs] = useState<Kantong[]>([]);
  const [activityLog, setActivityLog] = useState<ActivityItem[]>([]);
  const [autoBudgetRules, setAutoBudgetRules] = useState<AutoBudgetRule[]>([]);
  const [scheduledTransfers, setScheduledTransfers] = useState<ScheduledTransfer[]>([]);
  const [chatEvaluationEntries, setChatEvaluationEntries] = useState<ChatEvaluationEntry[]>([]);
  const [generalReceipts, setGeneralReceipts] = useState<Invoice[]>([]);
  const [expenseVouchers, setExpenseVouchers] = useState<ExpenseVoucher[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [firebaseUser, setFirebaseUser] = useState<firebase.User | null>(null);


  const addToast = useCallback((message: string, type: ToastMessage['type'] = 'info') => {
    const id = `toast-${Date.now()}`;
    setToasts(prevToasts => [...prevToasts, { id, message, type }]);
    setTimeout(() => {
      setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
    }, 3000);
  }, []);

  const removeToast = (id: string) => {
    setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
  };
  
  useEffect(() => {
    const unsubscribe = API.auth.onAuthStateChanged(async (user) => {
      if (user) {
        setFirebaseUser(user);
        setIsAuthenticated(true);
        setIsLoadingData(true); 
        
        try {
          let fetchedProfile = await API.getUserProfileFromFirestore(user.uid);
          if (!fetchedProfile) {
            const defaultProfile: UserProfile = {
              ...initialUserProfile,
              id: user.uid,
              email: user.email || '',
              fullName: user.displayName || user.email?.split('@')[0] || 'Pengguna Baru', 
              username: user.email?.split('@')[0] || `user${Date.now().toString().slice(-4)}`,
              notificationSettings: initialNotificationSettings, 
            };
            await API.updateUserProfileInFirestore(user.uid, defaultProfile);
            fetchedProfile = defaultProfile;
          }
          setUserProfile(fetchedProfile);

          const fetchedSystemOptions = await API.getSystemOptionsFS(user.uid);
          if (fetchedSystemOptions) {
            setSystemOptions(fetchedSystemOptions);
          } else {
            await API.updateSystemOptionsFS(user.uid, initialSystemOptions);
            setSystemOptions(initialSystemOptions);
          }

        } catch (error: any) {
          addToast(`Gagal memuat profil/opsi: ${error.message}`, 'error');
          setUserProfile({...initialUserProfile, id: user.uid, email: user.email || ''});
          setSystemOptions(initialSystemOptions);
        }
      } else {
        setFirebaseUser(null);
        setIsAuthenticated(false);
        setClients([]); setProjects([]); setTransactions([]); setFreelancers([]);
        setFreelancerProjects([]); setCalendarEvents([]); setPackages([]); setAddOns([]);
        setBankDetails([]); setKantongs([]); setActivityLog([]); setAutoBudgetRules([]);
        setScheduledTransfers([]); setChatEvaluationEntries([]); setGeneralReceipts([]);
        setExpenseVouchers([]); setNotifications([]); setUserProfile(initialUserProfile);
        setSystemOptions(initialSystemOptions);
        setIsLoadingData(false);
      }
    });
    return () => unsubscribe();
  }, [addToast]);


  useEffect(() => {
    if (!firebaseUser || !firebaseUser.uid) {
        if (isAuthenticated) setIsLoadingData(false); 
        return;
    }
    const userId = firebaseUser.uid;
    const unsubscribers: (() => void)[] = [];
    const loadData = async () => {
      setIsLoadingData(true);
      try {
        unsubscribers.push(API.onClientsSnapshot(setClients));
        unsubscribers.push(API.onProjectsSnapshot(setProjects));
        unsubscribers.push(API.onTransactionsSnapshot(setTransactions));
        unsubscribers.push(API.onFreelancersSnapshot(setFreelancers));
        unsubscribers.push(API.onFreelancerProjectsSnapshot(setFreelancerProjects));
        
        unsubscribers.push(API.onKantongsSnapshot(userId, setKantongs));
        unsubscribers.push(API.onPackagesSnapshot(userId, setPackages));
        unsubscribers.push(API.onAddOnsSnapshot(userId, setAddOns));
        unsubscribers.push(API.onBankDetailsSnapshot(userId, setBankDetails));
        unsubscribers.push(API.onCalendarEventsSnapshot(userId, setCalendarEvents));
        unsubscribers.push(API.onActivityLogSnapshot(userId, setActivityLog));
        unsubscribers.push(API.onAutoBudgetRulesSnapshot(userId, setAutoBudgetRules));
        unsubscribers.push(API.onScheduledTransfersSnapshot(userId, setScheduledTransfers));
        unsubscribers.push(API.onChatEvaluationEntriesSnapshot(userId, setChatEvaluationEntries));
        unsubscribers.push(API.onGeneralReceiptsSnapshot(userId, setGeneralReceipts));
        unsubscribers.push(API.onExpenseVouchersSnapshot(userId, setExpenseVouchers));
        unsubscribers.push(API.onNotificationsSnapshot(userId, setNotifications));
      } catch (error: any) {
        addToast(`Gagal sinkronisasi data: ${error.message}`, 'error');
      } finally {
        // Add a small delay to ensure all listeners have a chance to fire once
        setTimeout(() => setIsLoadingData(false), 1000); 
      }
    };
    loadData();
    return () => { unsubscribers.forEach(unsub => unsub()); };
  }, [firebaseUser, addToast]);

  const handleLoginSuccess = () => {
    // No specific action needed here as onAuthStateChanged handles profile loading.
    // addToast('Login berhasil! Selamat datang.', 'success'); // Toast is better handled after profile is loaded
  };

  const handleLogout = async () => {
    try {
      await API.auth.signOut();
      addToast('Anda telah berhasil logout.', 'info');
      setIsMobileSidebarOpen(false); 
    } catch (error: any) {
      addToast(`Gagal logout: ${error.message}`, 'error');
    }
  };

  const addNotification = useCallback(async (notificationData: Omit<NotificationItem, 'id' | 'date' | 'isRead'>) => {
    if (!firebaseUser?.uid) return;
    try {
      const newNotification: Omit<NotificationItem, 'id'> = {
        ...notificationData,
        date: new Date().toISOString(),
        isRead: false,
      };
      await API.addNotificationFS(firebaseUser.uid, newNotification);
    } catch (error: any) {
      addToast(`Gagal menambah notifikasi: ${error.message}`, 'error');
    }
  }, [firebaseUser, addToast]);

  const markNotificationAsRead = useCallback(async (notificationId: string) => {
    if (!firebaseUser?.uid) return;
    try {
      await API.updateNotificationFS(firebaseUser.uid, notificationId, { isRead: true });
    } catch (error: any) {
      addToast(`Gagal update notifikasi: ${error.message}`, 'error');
    }
  }, [firebaseUser, addToast]);

  const clearAllNotifications = useCallback(async () => {
    if (!firebaseUser?.uid) return;
    try {
      await API.clearAllNotificationsFS(firebaseUser.uid);
      addToast('Semua notifikasi dihapus.', 'info');
    } catch (error: any) {
      addToast(`Gagal menghapus notifikasi: ${error.message}`, 'error');
    }
  }, [firebaseUser, addToast]);

  const addActivityLogItem = useCallback(async (itemData: Omit<ActivityItem, 'id' | 'timestamp' | 'user'>) => {
    if (!firebaseUser?.uid) return;
    try {
      const newLogEntry: Omit<ActivityItem, 'id'> = {
        timestamp: new Date().toISOString(),
        user: userProfile.fullName || firebaseUser.email || 'Admin',
        ...itemData,
      };
      await API.addActivityLogItemFS(firebaseUser.uid, newLogEntry);
    } catch (error: any) {
      addToast(`Gagal mencatat aktivitas: ${error.message}`, 'error');
    }
  }, [firebaseUser, userProfile.fullName, addToast]);

  const [appModals, setAppModals] = useState<AppModalState>({
    projectDetail: { isOpen: false, projectId: null },
    freelancerDetail: { isOpen: false, freelancerId: null },
    freelancerEarnings: { isOpen: false, freelancerId: null },
    payFreelancer: { isOpen: false, freelancerId: null, context: 'fee' },
    savingsWithdrawal: { isOpen: false, freelancerId: null },
    recordSavingsDeposit: { isOpen: false, freelancerId: null },
    viewInvoice: { isOpen: false, invoice: null, invoiceId: null, clientId: null },
    freelancerPaymentVoucher: { isOpen: false, transactionId: null },
    viewExpenseVoucher: { isOpen: false, expenseVoucherId: null },
  });

  const handleViewProjectDetailFromApp = (projectId: string) => setAppModals(prev => ({ ...prev, projectDetail: { isOpen: true, projectId }}));
  const handleViewFreelancerDetailFromApp = (freelancerId: string) => setAppModals(prev => ({ ...prev, freelancerDetail: { isOpen: true, freelancerId }}));
  const closeAppProjectDetailModal = () => setAppModals(prev => ({ ...prev, projectDetail: { isOpen: false, projectId: null }}));
  const closeAppFreelancerDetailModal = () => setAppModals(prev => ({ ...prev, freelancerDetail: { isOpen: false, freelancerId: null }}));
  const closeAppFreelancerEarningsModal = () => setAppModals(prev => ({ ...prev, freelancerEarnings: { isOpen: false, freelancerId: null }}));
  const closePayFreelancerModal = () => setAppModals(prev => ({ ...prev, payFreelancer: { isOpen: false, freelancerId: null, context: 'fee' }}));
  const closeSavingsWithdrawalModal = () => setAppModals(prev => ({ ...prev, savingsWithdrawal: { isOpen: false, freelancerId: null }}));
  const closeRecordSavingsDepositModal = () => setAppModals(prev => ({ ...prev, recordSavingsDeposit: { isOpen: false, freelancerId: null }}));
  const closeViewInvoiceModal = () => setAppModals(prev => ({ ...prev, viewInvoice: { isOpen: false, invoice: null, invoiceId: null, clientId: null }}));
  const openFreelancerPaymentVoucherModal = (transactionId: string) => setAppModals(prev => ({ ...prev, freelancerPaymentVoucher: { isOpen: true, transactionId }}));
  const closeFreelancerPaymentVoucherModal = () => setAppModals(prev => ({ ...prev, freelancerPaymentVoucher: { isOpen: false, transactionId: null }}));
  const openViewExpenseVoucherModal = (expenseVoucherId: string) => setAppModals(prev => ({ ...prev, viewExpenseVoucher: { isOpen: true, expenseVoucherId }}));
  const closeViewExpenseVoucherModal = () => setAppModals(prev => ({ ...prev, viewExpenseVoucher: { isOpen: false, expenseVoucherId: null }}));

  const openViewInvoiceModalById = async (invoiceId: string, clientId?: string) => {
    let foundInvoice: Invoice | null = null;
    let finalClientId = clientId;
  
    if (finalClientId && firebaseUser?.uid) {
      const clientDocRef = API.db.collection('clients').doc(finalClientId);
      const invoiceDocRef = clientDocRef.collection('invoices').doc(invoiceId);
      const invoiceSnap = await invoiceDocRef.get();
      if (invoiceSnap.exists) {
          foundInvoice = { id: invoiceSnap.id, ...invoiceSnap.data() } as Invoice;
      }
    }
  
    if (!foundInvoice && firebaseUser?.uid) {
      const generalReceiptDocRef = API.db.collection('users').doc(firebaseUser.uid).collection('generalReceipts').doc(invoiceId);
      const generalReceiptSnap = await generalReceiptDocRef.get();
      if (generalReceiptSnap.exists) {
        foundInvoice = { id: generalReceiptSnap.id, ...generalReceiptSnap.data() } as Invoice;
        finalClientId = foundInvoice.clientId; 
      }
    }
    
    if (!foundInvoice && firebaseUser?.uid) { 
      for (const project of projects) {
        if (!project.id) continue; 
        const projectInvoicesCollectionRef = API.db.collection('projects').doc(project.id).collection('invoices');
        const invoiceDocRef = projectInvoicesCollectionRef.doc(invoiceId);
        const projectInvoiceSnap = await invoiceDocRef.get();
        if (projectInvoiceSnap.exists) {
          foundInvoice = {id: projectInvoiceSnap.id, ...projectInvoiceSnap.data()} as Invoice;
          finalClientId = project.clientId;
          break;
        }
      }
    }
  
    if (foundInvoice) {
      setAppModals(prev => ({ ...prev, viewInvoice: { isOpen: true, invoice: foundInvoice, invoiceId, clientId: finalClientId }}));
    } else {
      addToast(`Invoice ID ${invoiceId} tidak ditemukan.`, 'error');
      addActivityLogItem({action: 'Error', targetType: 'Invoice', details: `Gagal menemukan invoice ID ${invoiceId}`});
    }
  };

  const generateInvoiceNumber = useCallback((clientId: string, date: Date): string => {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const clientSegment = clientId ? clientId.slice(0, Math.min(4, clientId.length)).toUpperCase() : 'GEN';
    const randomSuffix = Math.random().toString(36).substr(2, 3).toUpperCase();
    return `INV-${year}${month}${day}-${clientSegment}-${randomSuffix}`;
  }, []);

  const userId = firebaseUser?.uid;

  const crudOperation = async <TData extends { id?: string }, UData extends Omit<TData, 'id'>>(
    action: 'add' | 'update' | 'delete',
    collectionName: string,
    data?: UData | Partial<UData>,
    id?: string,
    forUserSpecificCollection: boolean = false, 
    successMessage?: string,
    activityLogEntry?: Omit<ActivityItem, 'id' | 'timestamp' | 'user'>
  ): Promise<TData | string | void | null> => { 
    if (!userId && forUserSpecificCollection) { 
      addToast('Pengguna tidak terautentikasi untuk operasi ini.', 'error');
      return null;
    }
    if (action !== 'delete' && !data) {
      addToast('Data tidak valid untuk operasi.', 'error'); return null;
    }

    try {
      let resultId: string | undefined;
      const currentUserId = userId; 
      if (forUserSpecificCollection && currentUserId) { 
        if (action === 'add') resultId = (await API.addUserSubCollectionData<TData>(currentUserId, collectionName, data as UData)).id;
        else if (action === 'update' && id) await API.updateUserSubCollectionData<TData>(currentUserId, collectionName, id, data as Partial<Omit<TData, 'id'>>);
        else if (action === 'delete' && id) await API.deleteUserSubCollectionData(currentUserId, collectionName, id);
      } else if (!forUserSpecificCollection) { 
        if (action === 'add') resultId = (await API.addData<TData>(collectionName, data as UData)).id;
        else if (action === 'update' && id) await API.updateData<TData & {id:string}>(collectionName, id, data as Partial<Omit<TData & {id:string}, 'id'>>);
        else if (action === 'delete' && id) await API.deleteData(collectionName, id);
      } else {
         addToast('Operasi tidak dapat dilakukan karena ID pengguna tidak valid.', 'error'); return null;
      }
      if (successMessage) addToast(successMessage, 'success');
      if (activityLogEntry) addActivityLogItem(activityLogEntry);
      return action === 'add' && resultId ? resultId : null; // Return ID for add operations
    } catch (e: any) { addToast(`Operasi ${collectionName} gagal: ${e.message}`, 'error'); return null; }
  };
  
  const addClientFS = async (clientData: Omit<Client, 'id'>, projectData?: Omit<Project, 'id'>): Promise<Client | null> => {
    const newClientId = await crudOperation<Client, Omit<Client, 'id'>>(
      'add', 'clients', clientData, undefined, false,
      `Klien "${clientData.name}" berhasil ditambahkan.`,
      { action: 'Tambah Klien', targetName: clientData.name, targetType: 'Client' }
    ) as string | null;

    if (!newClientId) return null;
    const newClient = { ...clientData, id: newClientId } as Client;


    if (projectData && firebaseUser?.uid) {
      const projectWithClientId: Omit<Project, 'id'> = { ...projectData, clientId: newClient.id, clientName: newClient.name };
      const newProject = await addProjectFS(projectWithClientId) as Project | null;
      
      if (newProject && newClient.downPayment && newClient.downPayment > 0 && newProject.budget && newProject.budget > 0) {
        const invoiceItems: InvoiceItem[] = [{ id: `item-${Date.now()}`, description: `Layanan Proyek: ${newProject.name}`, quantity: 1, unitPrice: newProject.budget, amount: newProject.budget }];
        
        const clientInvoicesCollectionRef = API.db.collection('clients').doc(newClient.id).collection('invoices');
        const invoiceDocRef = clientInvoicesCollectionRef.doc(); 
        
        const newInvoiceData: Omit<Invoice, 'id'> = {
          invoiceNumber: generateInvoiceNumber(newClient.id, new Date()),
          clientId: newClient.id, projectId: newProject.id, issueDate: new Date().toISOString().split('T')[0],
          items: invoiceItems, subtotal: newProject.budget, totalAmount: newProject.budget,
          amountPaid: newClient.downPayment, balanceDue: newProject.budget - newClient.downPayment,
          status: newClient.downPayment >= newProject.budget ? InvoiceStatus.Paid : InvoiceStatus.Partial,
          paymentHistory: [{ id: `pay-${Date.now()}`, date: new Date().toISOString().split('T')[0], amount: newClient.downPayment, method: 'Initial DP', invoiceId: invoiceDocRef.id }],
          paymentInstructions: userProfile.invoiceTerms,
        };
        await invoiceDocRef.set(newInvoiceData);

        const projectDocRef = API.db.collection('projects').doc(newProject.id);
        await projectDocRef.update({
            invoices: firebase.firestore.FieldValue.arrayUnion({...newInvoiceData, id: invoiceDocRef.id}) 
        });

        await addTransactionFS({
          date: new Date().toISOString().split('T')[0],
          description: `DP Awal: ${newClient.name} - ${newInvoiceData.invoiceNumber}`,
          category: 'Pemasukan Proyek', type: 'Pemasukan', amount: newClient.downPayment,
          method: 'Initial DP', linkedClientId: newClient.id, linkedProjectId: newProject.id, invoiceId: invoiceDocRef.id,
          kantongId: kantongs.find(k => k.name.toLowerCase().includes("utama") || k.type === "Bayar")?.id || kantongs[0]?.id
        });
      }
    }
    return newClient;
  };
  
  const updateClientFS = (updatedClientData: Client) => crudOperation<Client, Partial<Client>>(
    'update', 'clients', updatedClientData, updatedClientData.id, false,
    `Klien "${updatedClientData.name}" berhasil diperbarui.`,
    { action: 'Update Klien', targetName: updatedClientData.name, targetType: 'Client', targetId: updatedClientData.id }
  );
  
  const deleteClientFS = (clientId: string) => {
    const clientToDelete = clients.find(c => c.id === clientId);
    return crudOperation<Client, Partial<Client>>(
      'delete', 'clients', undefined, clientId, false,
      clientToDelete ? `Klien "${clientToDelete.name}" berhasil dihapus.` : 'Klien berhasil dihapus.',
      clientToDelete ? { action: 'Hapus Klien', targetName: clientToDelete.name, targetType: 'Client', targetId: clientId } : undefined
    );
  };

  const addProjectFS = (projectData: Omit<Project, 'id'>) => crudOperation<Project, Omit<Project, 'id'>>(
    'add', 'projects', projectData, undefined, false,
    `Proyek "${projectData.name}" berhasil ditambahkan.`,
    { action: 'Tambah Proyek', targetName: projectData.name, targetType: 'Project' }
  );
  
  const updateProjectFS = (updatedProjectData: Project) => crudOperation<Project, Partial<Project>>(
    'update', 'projects', updatedProjectData, updatedProjectData.id, false,
    `Proyek "${updatedProjectData.name}" berhasil diperbarui.`,
    { action: 'Update Proyek', targetName: updatedProjectData.name, targetType: 'Project', targetId: updatedProjectData.id }
  );
  
  const deleteProjectFS = (projectId: string) => {
    const projectToDelete = projects.find(p => p.id === projectId);
    return crudOperation<Project, Partial<Project>>(
      'delete', 'projects', undefined, projectId, false,
      projectToDelete ? `Proyek "${projectToDelete.name}" berhasil dihapus.` : 'Proyek berhasil dihapus.',
      projectToDelete ? { action: 'Hapus Proyek', targetName: projectToDelete.name, targetType: 'Project', targetId: projectId } : undefined
    );
  };

 const addFreelancerFS = (freelancerData: Omit<Freelancer, 'id'>) => {
      const dataToSave: Omit<Freelancer, 'id'> = {
        ...freelancerData,
        projectCount: freelancerData.projectCount || 0,
        totalEarnings: freelancerData.totalEarnings || 0,
        savings: freelancerData.type === 'Tim Internal' ? (freelancerData.savings || 0) : undefined,
        standardFee: freelancerData.standardFee || 0, 
      };
      return crudOperation<Freelancer, Omit<Freelancer, 'id'>>(
          'add', 'freelancers', dataToSave, undefined, false,
          `${freelancerData.type} "${freelancerData.name}" berhasil ditambahkan.`,
          { action: 'Tambah Freelancer/Tim', targetName: freelancerData.name, targetType: 'Freelancer' }
      );
  };
  const updateFreelancerFS = (updatedFreelancerData: Freelancer) => crudOperation<Freelancer, Partial<Freelancer>>(
    'update', 'freelancers', updatedFreelancerData, updatedFreelancerData.id, false,
    `Data ${updatedFreelancerData.type} "${updatedFreelancerData.name}" berhasil diperbarui.`,
    { action: 'Update Freelancer/Tim', targetName: updatedFreelancerData.name, targetType: 'Freelancer', targetId: updatedFreelancerData.id }
  );
  const deleteFreelancerFS = (freelancerId: string) => {
    const freelancerToDelete = freelancers.find(f => f.id === freelancerId);
    return crudOperation<Freelancer, Partial<Freelancer>>(
      'delete', 'freelancers', undefined, freelancerId, false,
      freelancerToDelete ? `${freelancerToDelete.type} "${freelancerToDelete.name}" berhasil dihapus.` : 'Freelancer/Tim berhasil dihapus.',
      freelancerToDelete ? { action: 'Hapus Freelancer/Tim', targetName: freelancerToDelete.name, targetType: 'Freelancer', targetId: freelancerId } : undefined
    );
  };

  const addFreelancerProjectFS = (fpData: Omit<FreelancerProject, 'id'>) => crudOperation<FreelancerProject, Omit<FreelancerProject, 'id'>>(
    'add', 'freelancerProjects', fpData, undefined, false,
    `Proyek "${fpData.projectName}" berhasil ditugaskan ke ${fpData.freelancerName}.`,
    { action: 'Assign Proyek ke Freelancer', targetName: `${fpData.freelancerName} ke ${fpData.projectName}`, targetType: 'FreelancerProject' }
  );
  const updateFreelancerProjectFS = (updatedFpData: FreelancerProject) => crudOperation<FreelancerProject, Partial<FreelancerProject>>(
    'update', 'freelancerProjects', updatedFpData, updatedFpData.id, false,
    `Penugasan ${updatedFpData.freelancerName} di proyek "${updatedFpData.projectName}" diperbarui.`,
    { action: 'Update Proyek Freelancer', targetName: `${updatedFpData.freelancerName} - ${updatedFpData.projectName}`, targetType: 'FreelancerProject', targetId: updatedFpData.id }
  );
  const deleteFreelancerProjectFS = (fpId: string) => {
    const fpToDelete = freelancerProjects.find(fp => fp.id === fpId);
    return crudOperation<FreelancerProject, Partial<FreelancerProject>>(
      'delete', 'freelancerProjects', undefined, fpId, false,
      fpToDelete ? `Penugasan ${fpToDelete.freelancerName} di proyek "${fpToDelete.projectName}" dihapus.` : 'Penugasan berhasil dihapus.',
      fpToDelete ? { action: 'Hapus Penugasan Proyek Freelancer', targetName: `${fpToDelete.freelancerName} - ${fpToDelete.projectName}`, targetType: 'FreelancerProject', targetId: fpId } : undefined
    );
  };

 const addTransactionFS = async (transactionData: Omit<Transaction, 'id'>): Promise<Transaction | null> => {
    if (!firebaseUser?.uid) {
        addToast('Tidak dapat menambah transaksi, pengguna tidak terautentikasi.', 'error');
        return null;
    }
    let newTransactionData = { ...transactionData };
    let newDocumentId: string | undefined;
    
    if (newTransactionData.type === 'Pemasukan' && !newTransactionData.invoiceId &&
        (newTransactionData.category === 'Pemasukan Lain' || !newTransactionData.linkedClientId) ) {
        const receiptData: Omit<Invoice, 'id'> = {
            invoiceNumber: generateInvoiceNumber('RCPT', new Date()),
            clientId: newTransactionData.linkedClientId || 'GENERAL_INCOME',
            issueDate: newTransactionData.date,
            items: [{ id: `item-gr-${Date.now()}`, description: newTransactionData.description, quantity: 1, unitPrice: newTransactionData.amount, amount: newTransactionData.amount }],
            subtotal: newTransactionData.amount, totalAmount: newTransactionData.amount, amountPaid: newTransactionData.amount, balanceDue: 0,
            status: InvoiceStatus.Paid,
            paymentHistory: [{ id: `pay-gr-${Date.now()}`, date: newTransactionData.date, amount: newTransactionData.amount, method: newTransactionData.method }],
            paymentInstructions: userProfile.invoiceTerms,
        };
        newDocumentId = await API.addUserSubCollectionData<Invoice>(firebaseUser.uid, 'generalReceipts', receiptData)
            .then(doc => doc.id)
            .catch(() => undefined);
        if(newDocumentId) {
            newTransactionData.invoiceId = newDocumentId;
            addActivityLogItem({ action: 'Buat Penerimaan Umum Otomatis', targetType: 'Invoice', targetName: receiptData.invoiceNumber, targetId: newDocumentId, amount: receiptData.totalAmount });
        }
    } else if (newTransactionData.type === 'Pengeluaran' && !newTransactionData.invoiceId) {
        const freelancerPaid = newTransactionData.linkedFreelancerId ? freelancers.find(f => f.id === newTransactionData.linkedFreelancerId) : null;
        const voucherData: Omit<ExpenseVoucher, 'id'> = { 
            voucherNumber: `VCHR-${newTransactionData.date.replace(/-/g, '')}-${Date.now().toString().slice(-4)}`,
            transactionId: '', 
            date: newTransactionData.date,
            payeeName: freelancerPaid ? freelancerPaid.name : (newTransactionData.category === 'Biaya Operasional' ? 'Vendor Operasional' : 'Penerima Umum'),
            payeeType: freelancerPaid ? (freelancerPaid.type === 'Tim Internal' ? 'Karyawan' : 'Freelancer') : 'Vendor',
            description: newTransactionData.description, category: newTransactionData.category, amount: newTransactionData.amount,
            method: newTransactionData.method, paidBy: userProfile.companyName || 'Perusahaan',
        };
        newDocumentId = await API.addUserSubCollectionData<ExpenseVoucher>(firebaseUser.uid, 'expenseVouchers', voucherData)
            .then(doc => doc.id)
            .catch(() => undefined);
        if(newDocumentId){
            newTransactionData.invoiceId = newDocumentId; 
            addActivityLogItem({ action: 'Buat Voucher Pengeluaran Otomatis', targetType: 'ExpenseVoucher', targetName: voucherData.voucherNumber, targetId: newDocumentId, amount: voucherData.amount });
        }
    }

    const addedTransactionId = await crudOperation<Transaction, Omit<Transaction, 'id'>>(
      'add', 'transactions', newTransactionData, undefined, false,
      `Transaksi "${newTransactionData.description}" berhasil ditambahkan.`,
      { action: 'Tambah Transaksi', targetName: newTransactionData.description, targetType: 'Transaction', amount: newTransactionData.amount }
    ) as string | null;

    if (addedTransactionId && newTransactionData.type === 'Pengeluaran' && newTransactionData.invoiceId && firebaseUser?.uid) {
        const voucher = expenseVouchers.find(v => v.id === newTransactionData.invoiceId);
        if(voucher && !voucher.transactionId) {
            await API.updateUserSubCollectionData<ExpenseVoucher>(firebaseUser.uid, 'expenseVouchers', newTransactionData.invoiceId, { transactionId: addedTransactionId });
        }
    }
    
    if (addedTransactionId && newTransactionData.type === 'Pengeluaran' && newTransactionData.category === 'Fee Proyek' && newTransactionData.linkedFreelancerId) {
        const freelancerRef = API.db.collection('freelancers').doc(newTransactionData.linkedFreelancerId);
        await API.db.runTransaction(async (transaction) => {
            const freelancerDoc = await transaction.get(freelancerRef);
            if (!freelancerDoc.exists) throw new Error("Freelancer tidak ditemukan!");
            const currentEarnings = (freelancerDoc.data()?.totalEarnings || 0) as number;
            transaction.update(freelancerRef, { totalEarnings: currentEarnings + newTransactionData.amount });
        });

        if (newTransactionData.linkedFreelancerProjectId) {
            const fpRef = API.db.collection('freelancerProjects').doc(newTransactionData.linkedFreelancerProjectId);
            await API.db.runTransaction(async (transaction) => {
                const fpDoc = await transaction.get(fpRef);
                if (!fpDoc.exists) throw new Error("Proyek freelancer tidak ditemukan!");
                const fpData = fpDoc.data() as FreelancerProject;
                const newPaidAmount = (fpData.paidAmount || 0) + newTransactionData.amount;
                const totalAgreedPayment = fpData.totalPayment || fpData.payment || 0;
                let newPaymentStatus = fpData.paymentStatus;
                if (totalAgreedPayment <= 0) newPaymentStatus = FreelancerPaymentStatus.Paid;
                else if (newPaidAmount >= totalAgreedPayment) newPaymentStatus = FreelancerPaymentStatus.Paid;
                else if (newPaidAmount > 0) newPaymentStatus = FreelancerPaymentStatus.Partial;
                else newPaymentStatus = FreelancerPaymentStatus.Unpaid;
                transaction.update(fpRef, {
                    paidAmount: newPaidAmount,
                    remainingAmount: Math.max(0, totalAgreedPayment - newPaidAmount),
                    paymentStatus: newPaymentStatus,
                });
            });
        }
    }

    if (addedTransactionId && newTransactionData.type === 'Pemasukan' && newTransactionData.linkedClientId && newTransactionData.invoiceId) {
        const clientDocRef = API.db.collection('clients').doc(newTransactionData.linkedClientId);
        const invoiceDocRef = clientDocRef.collection('invoices').doc(newTransactionData.invoiceId);
        
        try {
          await API.db.runTransaction(async (tx) => {
              const invoiceSnap = await tx.get(invoiceDocRef);
              if (!invoiceSnap.exists) throw new Error("Invoice tidak ditemukan untuk diperbarui!");
              const invoiceData = invoiceSnap.data() as Invoice;
              const updatedAmountPaid = (invoiceData.amountPaid || 0) + newTransactionData.amount;
              const updatedBalanceDue = invoiceData.totalAmount - updatedAmountPaid;
              tx.update(invoiceDocRef, {
                  amountPaid: updatedAmountPaid,
                  balanceDue: updatedBalanceDue,
                  status: updatedBalanceDue <= 0 ? InvoiceStatus.Paid : InvoiceStatus.Partial,
                  paymentHistory: firebase.firestore.FieldValue.arrayUnion({
                      id: `pay-inv-${invoiceData.id}-${Date.now()}`, date: newTransactionData.date,
                      amount: newTransactionData.amount, method: newTransactionData.method,
                      notes: `Pembayaran via transaksi ${newTransactionData.description}`, invoiceId: invoiceData.id
                  })
              });
          });
        } catch (error: any) {
            addToast(`Gagal update invoice terkait: ${error.message}`, 'warning');
        }
        
        if (userProfile.notificationSettings?.paymentReceived) {
            const clientName = clients.find(c => c.id === newTransactionData.linkedClientId)?.name || 'Klien';
            addNotification({ type: 'payment_received', title: 'Pembayaran Diterima', message: `Pembayaran sebesar ${newTransactionData.amount.toLocaleString('id-ID')} diterima dari ${clientName} untuk ${newTransactionData.description}.`, relatedId: newTransactionData.linkedClientId, linkTo: `/${NavigationItemKey.Klien}` });
        }
    }
    
    if (addedTransactionId && newTransactionData.kantongId && userId) {
        const kantongRef = API.db.collection('users').doc(userId).collection('kantongs').doc(newTransactionData.kantongId);
        try {
            await API.db.runTransaction(async (transaction) => {
                const kantongDoc = await transaction.get(kantongRef);
                if (!kantongDoc.exists) throw new Error("Kantong tidak ditemukan!");
                const currentBalance = (kantongDoc.data()?.balance || 0) as number;
                const newBalance = newTransactionData.type === 'Pemasukan' ? currentBalance + newTransactionData.amount : currentBalance - newTransactionData.amount;
                transaction.update(kantongRef, { balance: newBalance });
            });
        } catch (error: any) {
            addToast(`Gagal update saldo kantong: ${error.message}`, 'warning');
        }
    }
    return addedTransactionId ? { id: addedTransactionId, ...newTransactionData } : null;
  };

  const addPackageFS = (pkgData: Omit<Package, 'id'>) => crudOperation<Package, Omit<Package, 'id'>>(
    'add', 'packages', pkgData, undefined, true,
    `Paket "${pkgData.name}" berhasil ditambahkan.`, { action: 'Tambah Paket', targetName: pkgData.name, targetType: 'Package' }
  );
  const updatePackageFS = (updatedPkgData: Package) => crudOperation<Package, Partial<Package>>(
    'update', 'packages', updatedPkgData, updatedPkgData.id, true,
    `Paket "${updatedPkgData.name}" berhasil diperbarui.`, { action: 'Update Paket', targetName: updatedPkgData.name, targetType: 'Package', targetId: updatedPkgData.id }
  );
  const deletePackageFS = (packageId: string) => {
    const pkgToDelete = packages.find(p => p.id === packageId);
    return crudOperation<Package, Partial<Package>>(
      'delete', 'packages', undefined, packageId, true,
      pkgToDelete ? `Paket "${pkgToDelete.name}" berhasil dihapus.` : 'Paket berhasil dihapus.',
      pkgToDelete ? { action: 'Hapus Paket', targetName: pkgToDelete.name, targetType: 'Package', targetId: packageId } : undefined
    );
  };

  const addAddOnFS = (addOnData: Omit<AddOn, 'id'>) => crudOperation<AddOn, Omit<AddOn, 'id'>>(
    'add', 'addOns', addOnData, undefined, true,
    `Add-On "${addOnData.name}" berhasil ditambahkan.`, { action: 'Tambah Add-On', targetName: addOnData.name, targetType: 'AddOn' }
  );
  const updateAddOnFS = (updatedAddOnData: AddOn) => crudOperation<AddOn, Partial<AddOn>>(
    'update', 'addOns', updatedAddOnData, updatedAddOnData.id, true,
    `Add-On "${updatedAddOnData.name}" berhasil diperbarui.`, { action: 'Update Add-On', targetName: updatedAddOnData.name, targetType: 'AddOn', targetId: updatedAddOnData.id }
  );
  const deleteAddOnFS = (addOnId: string) => {
    const addOnToDelete = addOns.find(a => a.id === addOnId);
    return crudOperation<AddOn, Partial<AddOn>>(
      'delete', 'addOns', undefined, addOnId, true,
      addOnToDelete ? `Add-On "${addOnToDelete.name}" berhasil dihapus.` : 'Add-On berhasil dihapus.',
      addOnToDelete ? { action: 'Hapus Add-On', targetName: addOnToDelete.name, targetType: 'AddOn', targetId: addOnId } : undefined
    );
  };

  const updateBankDetailsFS = (newDetails: BankDetail[]) => API.updateBankDetailsFS(firebaseUser!.uid, newDetails)
    .then(() => {
      addToast('Detail bank berhasil diperbarui.', 'success');
      addActivityLogItem({ action: 'Update Detail Bank', targetType: 'BankDetails'});
    })
    .catch(e => addToast(`Gagal update detail bank: ${e.message}`, 'error'));

  const updateSystemOptionsApp = (newOptions: SystemOptions) => API.updateSystemOptionsFS(firebaseUser!.uid, newOptions)
    .then(() => {
      setSystemOptions(newOptions); 
      addToast('Opsi sistem berhasil diperbarui.', 'success');
      addActivityLogItem({ action: 'Update Opsi Sistem', targetType: 'SystemOptions'});
    })
    .catch(e => addToast(`Gagal update opsi sistem: ${e.message}`, 'error'));

  const handleUpdateUserProfileApp = (profile: UserProfile) => API.updateUserProfileInFirestore(firebaseUser!.uid, profile)
    .then(() => {
      setUserProfile(prev => ({...prev, ...profile})); 
      addToast('Profil pengguna berhasil diperbarui.', 'success');
      addActivityLogItem({ action: 'Update Profil Pengguna', targetName: profile.fullName, targetType: 'UserProfile' });
    })
    .catch(e => addToast(`Gagal update profil: ${e.message}`, 'error'));

  const updateNotificationSettingsApp = useCallback((settings: NotificationSettings) => {
    if (!firebaseUser?.uid) return;
    API.updateUserProfileInFirestore(firebaseUser.uid, { notificationSettings: settings })
        .then(() => {
            setUserProfile(prev => ({...prev, notificationSettings: settings}));
            addToast('Preferensi notifikasi disimpan.', 'success');
        })
        .catch(e => addToast(`Gagal simpan preferensi notifikasi: ${e.message}`, 'error'));
  }, [firebaseUser, addToast]);

  const addKantongFS = (kantongData: Omit<Kantong, 'id'>) => crudOperation<Kantong, Omit<Kantong, 'id'>>(
    'add', 'kantongs', kantongData, undefined, true,
    `Kantong "${kantongData.name}" berhasil ditambahkan.`, { action: 'Tambah Kantong', targetName: kantongData.name, targetType: 'Kantong' }
  );
  const updateKantongFS = (updatedKantongData: Kantong) => crudOperation<Kantong, Partial<Kantong>>(
    'update', 'kantongs', updatedKantongData, updatedKantongData.id, true,
    `Kantong "${updatedKantongData.name}" berhasil diperbarui.`, { action: 'Update Kantong', targetName: updatedKantongData.name, targetType: 'Kantong', targetId: updatedKantongData.id }
  );
  const deleteKantongFS = async (kantongId: string) => {
    const isUsed = transactions.some(t => t.kantongId === kantongId) ||
                   autoBudgetRules.some(r => r.sourceKantongId === kantongId || r.destinationKantongId === kantongId) ||
                   scheduledTransfers.some(st => st.sourceKantongId === kantongId || st.destinationKantongId === kantongId);
    if (isUsed) {
      addToast("Kantong tidak bisa dihapus karena masih terkait dengan data lain.", 'error');
      return;
    }
    const kantongToDelete = kantongs.find(k => k.id === kantongId);
    await crudOperation<Kantong, Partial<Kantong>>(
      'delete', 'kantongs', undefined, kantongId, true,
      kantongToDelete ? `Kantong "${kantongToDelete.name}" berhasil dihapus.` : 'Kantong berhasil dihapus.',
      kantongToDelete ? { action: 'Hapus Kantong', targetName: kantongToDelete.name, targetType: 'Kantong', targetId: kantongId } : undefined
    );
  };

  const handleTransferAntarKantongFS = async (sourceKantongId: string, destinationKantongId: string, amount: number, date: string, notes?: string) => {
    if (!firebaseUser?.uid) return;
    const sourceKantong = kantongs.find(k => k.id === sourceKantongId);
    const destinationKantong = kantongs.find(k => k.id === destinationKantongId);
    if (!sourceKantong || !destinationKantong) { addToast("Kantong sumber atau tujuan tidak ditemukan.", 'error'); return; }
    if (sourceKantong.balance < amount) { addToast("Saldo kantong sumber tidak mencukupi.", 'error'); return; }

    const sourceKantongRef = API.db.collection('users').doc(firebaseUser.uid).collection('kantongs').doc(sourceKantongId);
    const destKantongRef = API.db.collection('users').doc(firebaseUser.uid).collection('kantongs').doc(destinationKantongId);
    
    try {
      await API.db.runTransaction(async (transaction) => {
        const sourceDoc = await transaction.get(sourceKantongRef);
        const destDoc = await transaction.get(destKantongRef);
        if (!sourceDoc.exists || !destDoc.exists) throw "Kantong tidak ditemukan!";
        
        const newSourceBalance = (sourceDoc.data()?.balance || 0) - amount;
        const newDestBalance = (destDoc.data()?.balance || 0) + amount;
        
        transaction.update(sourceKantongRef, { balance: newSourceBalance });
        transaction.update(destKantongRef, { balance: newDestBalance });
      });
      
      const description = `Transfer dari ${sourceKantong.name} ke ${destinationKantong.name}${notes ? ` (${notes})` : ''}`;
      await addTransactionFS({ date, description: `Keluar: ${description}`, category: 'Transfer Antar Kantong', type: 'Pengeluaran', amount, method: 'Internal', kantongId: sourceKantongId });
      await addTransactionFS({ date, description: `Masuk: ${description}`, category: 'Transfer Antar Kantong', type: 'Pemasukan', amount, method: 'Internal', kantongId: destinationKantongId });
      
      addActivityLogItem({ action: 'Transfer Dana', targetName: description, targetType: 'Kantong', amount });
      addToast(`Transfer ${amount.toLocaleString('id-ID')} dari ${sourceKantong.name} ke ${destinationKantong.name} berhasil.`, 'success');
    } catch (e: any) {
      addToast(`Transfer gagal: ${e.message}`, 'error');
    }
  };

  const recordSavingsWithdrawalFS = async (freelancerId: string, amount: number, date: string, notes?: string) => {
    const freelancer = freelancers.find(f => f.id === freelancerId);
    if (!freelancer || freelancer.type !== 'Tim Internal' || (freelancer.savings || 0) < amount) {
      addToast("Gagal mencatat penarikan. Freelancer tidak ditemukan, bukan tim internal, atau saldo tabungan tidak cukup.", 'error');
      return;
    }
    const updatedSavings = (freelancer.savings || 0) - amount;
    await updateFreelancerFS({ ...freelancer, savings: updatedSavings });
    await addTransactionFS({
      date, description: `Penarikan Tabungan: ${freelancer.name}${notes ? ` (${notes})` : ''}`,
      category: 'Penarikan Tabungan Tim', type: 'Pengeluaran', amount, method: 'Internal', linkedFreelancerId: freelancerId,
    });
    addActivityLogItem({action: 'Penarikan Tabungan', targetName: freelancer.name, targetType: 'TeamSavings', amount});
    addToast(`Penarikan tabungan ${freelancer.name} sebesar ${amount.toLocaleString('id-ID')} berhasil.`, 'success');
    closeSavingsWithdrawalModal();
  };

  const recordTeamSavingsDepositFS = async (freelancerId: string, amount: number, date: string, notes?: string) => {
    const freelancer = freelancers.find(f => f.id === freelancerId);
    if (!freelancer || freelancer.type !== 'Tim Internal') { addToast("Gagal mencatat setoran. Freelancer tidak ditemukan atau bukan tim internal.", 'error'); return; }
    if (amount <= 0) { addToast("Jumlah setoran tabungan harus positif.", 'error'); return; }
    
    const updatedSavings = (freelancer.savings || 0) + amount;
    await updateFreelancerFS({ ...freelancer, savings: updatedSavings });
    await addTransactionFS({
      date, description: `Setoran Tabungan Tim: ${freelancer.name}${notes ? ` (${notes})` : ''}`,
      category: 'Setoran Tabungan Tim', type: 'Pengeluaran', amount, method: 'Internal', linkedFreelancerId: freelancerId,
    });
    addActivityLogItem({action: 'Setoran Tabungan Tim', targetName: freelancer.name, targetType: 'TeamSavings', amount});
    addToast(`Setoran tabungan ${freelancer.name} sebesar ${amount.toLocaleString('id-ID')} berhasil dicatat.`, 'success');
    closeRecordSavingsDepositModal();
  };

  const addCalendarEventFS = (eventData: Omit<CalendarEvent, 'id'>) => crudOperation<CalendarEvent, Omit<CalendarEvent, 'id'>>(
    'add', 'calendarEvents', eventData, undefined, true,
    `Acara "${eventData.title}" berhasil ditambahkan.`, { action: 'Tambah Acara Kalender', targetName: eventData.title, targetType: 'CalendarEvent' }
  );
  const updateCalendarEventFS = (updatedEventData: CalendarEvent) => crudOperation<CalendarEvent, Partial<CalendarEvent>>(
    'update', 'calendarEvents', updatedEventData, updatedEventData.id, true,
    `Acara "${updatedEventData.title}" berhasil diperbarui.`, { action: 'Update Acara Kalender', targetName: updatedEventData.title, targetType: 'CalendarEvent', targetId: updatedEventData.id }
  );
  const deleteCalendarEventFS = (eventId: string) => {
    const eventToDelete = calendarEvents.find(e => e.id === eventId);
    return crudOperation<CalendarEvent, Partial<CalendarEvent>>(
      'delete', 'calendarEvents', undefined, eventId, true,
      eventToDelete ? `Acara "${eventToDelete.title}" berhasil dihapus.` : 'Acara berhasil dihapus.',
      eventToDelete ? { action: 'Hapus Acara Kalender', targetName: eventToDelete.title, targetType: 'CalendarEvent', targetId: eventId } : undefined
    );
  };

  useEffect(() => {
    if (!firebaseUser?.uid || !userProfile.notificationSettings) return;
    const newNotificationsBuffer: Omit<NotificationItem, 'id'|'date'|'isRead'>[] = [];
    const today = new Date();
    const sevenDaysFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
    const fourteenDaysFromNow = new Date(today.getTime() + 14 * 24 * 60 * 60 * 1000);
    
    projects.forEach(p => {
      if (p.deadline && userProfile.notificationSettings?.deadlineProject) {
        const deadlineDate = new Date(p.deadline);
        if (deadlineDate >= today && deadlineDate <= sevenDaysFromNow) {
          newNotificationsBuffer.push({type: 'deadline_project', title: `Deadline Proyek: ${p.name}`, message: `Proyek "${p.name}" jatuh tempo pada ${deadlineDate.toLocaleDateString('id-ID')}.`, relatedId: p.id, linkTo: `/${NavigationItemKey.Proyek}`});
        }
      }
      (p.tasks || []).forEach(task => {
        if (task.dueDate && !task.isCompleted && userProfile.notificationSettings?.deadlineTask) {
            const taskDueDate = new Date(task.dueDate);
            if (taskDueDate >= today && taskDueDate <= sevenDaysFromNow) {
                newNotificationsBuffer.push({type: 'deadline_task', title: `Deadline Tugas: ${task.description}`, message: `Tugas "${task.description}" (Proyek: ${p.name}) jatuh tempo pada ${taskDueDate.toLocaleDateString('id-ID')}.`, relatedId: task.id, linkTo: `/${NavigationItemKey.Proyek}`});
            }
        }
      });
    });

    freelancers.forEach(f => {
        if (f.contractEndDate && userProfile.notificationSettings?.contractEnd) {
            const contractEndDate = new Date(f.contractEndDate);
            if (contractEndDate >= today && contractEndDate <= fourteenDaysFromNow) {
                newNotificationsBuffer.push({type: 'contract_end', title: `Kontrak Berakhir: ${f.name}`, message: `Kontrak ${f.name} akan berakhir pada ${contractEndDate.toLocaleDateString('id-ID')}.`, relatedId: f.id, linkTo: `/${NavigationItemKey.Freelancer}`});
            }
        }
    });
    kantongs.forEach(k => {
        if (userProfile.notificationSettings?.lowBalance && k.targetAmount && k.balance < (k.targetAmount * 0.2)) { 
            newNotificationsBuffer.push({type: 'low_balance', title: `Saldo Kantong Rendah: ${k.name}`, message: `Saldo kantong "${k.name}" (${k.balance.toLocaleString()}) di bawah target aman.`, relatedId: k.id, linkTo: `/${NavigationItemKey.Keuangan}`});
        }
    });
    
    newNotificationsBuffer.forEach(n => {
      const existingNotif = notifications.find(exN => exN.type === n.type && exN.relatedId === n.relatedId && exN.title === n.title && !exN.isRead); 
      if(!existingNotif) {
        addNotification(n);
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projects, freelancers, kantongs, userProfile.notificationSettings, firebaseUser, notifications]); 

  const addAutoBudgetRuleFS = (ruleData: Omit<AutoBudgetRule, 'id' | 'lastRunDate' | 'nextRunDate'>) => crudOperation<AutoBudgetRule, Omit<AutoBudgetRule, 'id' | 'lastRunDate' | 'nextRunDate'>>(
    'add', 'autoBudgetRules', ruleData, undefined, true,
    `Aturan auto-budget "${ruleData.description}" berhasil ditambahkan.`, { action: 'Tambah Aturan Auto-Budget', targetName: ruleData.description, targetType: 'AutoBudgetRule'}
  );
  const updateAutoBudgetRuleFS = (updatedRuleData: AutoBudgetRule) => crudOperation<AutoBudgetRule, Partial<AutoBudgetRule>>(
    'update', 'autoBudgetRules', updatedRuleData, updatedRuleData.id, true,
    `Aturan auto-budget "${updatedRuleData.description}" berhasil diperbarui.`, { action: 'Update Aturan Auto-Budget', targetName: updatedRuleData.description, targetType: 'AutoBudgetRule', targetId: updatedRuleData.id}
  );
  const deleteAutoBudgetRuleFS = (ruleId: string) => {
    const ruleToDelete = autoBudgetRules.find(r => r.id === ruleId);
    return crudOperation<AutoBudgetRule, Partial<AutoBudgetRule>>(
      'delete', 'autoBudgetRules', undefined, ruleId, true,
      ruleToDelete ? `Aturan auto-budget "${ruleToDelete.description}" berhasil dihapus.` : 'Aturan auto-budget berhasil dihapus.',
      ruleToDelete ? { action: 'Hapus Aturan Auto-Budget', targetName: ruleToDelete.description, targetType: 'AutoBudgetRule', targetId: ruleId} : undefined
    );
  };

  const addScheduledTransferFS = (transferData: Omit<ScheduledTransfer, 'id' | 'lastRunDate' | 'nextRunDate'>) => crudOperation<ScheduledTransfer, Omit<ScheduledTransfer, 'id' | 'lastRunDate' | 'nextRunDate'>>(
    'add', 'scheduledTransfers', transferData, undefined, true,
    `Transfer terjadwal "${transferData.description}" berhasil ditambahkan.`, { action: 'Tambah Transfer Terjadwal', targetName: transferData.description, targetType: 'ScheduledTransfer'}
  );
  const updateScheduledTransferFS = (updatedTransferData: ScheduledTransfer) => crudOperation<ScheduledTransfer, Partial<ScheduledTransfer>>(
    'update', 'scheduledTransfers', updatedTransferData, updatedTransferData.id, true,
    `Transfer terjadwal "${updatedTransferData.description}" berhasil diperbarui.`, { action: 'Update Transfer Terjadwal', targetName: updatedTransferData.description, targetType: 'ScheduledTransfer', targetId: updatedTransferData.id}
  );
  const deleteScheduledTransferFS = (transferId: string) => {
    const transferToDelete = scheduledTransfers.find(st => st.id === transferId);
    return crudOperation<ScheduledTransfer, Partial<ScheduledTransfer>>(
      'delete', 'scheduledTransfers', undefined, transferId, true,
      transferToDelete ? `Transfer terjadwal "${transferToDelete.description}" berhasil dihapus.` : 'Transfer terjadwal berhasil dihapus.',
      transferToDelete ? { action: 'Hapus Transfer Terjadwal', targetName: transferToDelete.description, targetType: 'ScheduledTransfer', targetId: transferId} : undefined
    );
  };

  const addChatEvaluationEntryFS = (entryData: Omit<ChatEvaluationEntry, 'id'>) => crudOperation<ChatEvaluationEntry, Omit<ChatEvaluationEntry, 'id'>>(
    'add', 'chatEvaluationEntries', entryData, undefined, true,
    `Data KPI Chat untuk "${entryData.clientName || 'Klien Baru'}" berhasil ditambahkan.`, { action: 'Tambah Data KPI Chat', targetName: `Klien: ${entryData.clientName || '-'} via ${entryData.channel}`, targetType: 'ChatEvaluation'}
  );
  const updateChatEvaluationEntryFS = (updatedEntryData: ChatEvaluationEntry) => crudOperation<ChatEvaluationEntry, Partial<ChatEvaluationEntry>>(
    'update', 'chatEvaluationEntries', updatedEntryData, updatedEntryData.id, true,
    `Data KPI Chat untuk "${updatedEntryData.clientName || 'Klien Baru'}" berhasil diperbarui.`, { action: 'Update Data KPI Chat', targetName: `Klien: ${updatedEntryData.clientName || '-'} via ${updatedEntryData.channel}`, targetType: 'ChatEvaluation', targetId: updatedEntryData.id}
  );

  const addBillingInvoiceFS = async (invoiceData: Omit<Invoice, 'id'>, clientId: string, projectId?: string): Promise<string> => {
    if (!firebaseUser?.uid) {
      addToast('Tidak dapat membuat invoice, pengguna tidak terautentikasi.', 'error');
      return '';
    }
    const clientDocRef = API.db.collection('clients').doc(clientId);
    const invoiceCollectionRef = clientDocRef.collection('invoices');
    const newInvoiceRef = invoiceCollectionRef.doc(); 
    const newInvoiceWithId = { ...invoiceData, id: newInvoiceRef.id };
    
    await newInvoiceRef.set(newInvoiceWithId);
    
    if (projectId) {
      const projectDocRef = API.db.collection('projects').doc(projectId);
       await projectDocRef.update({
         invoices: firebase.firestore.FieldValue.arrayUnion(newInvoiceWithId)
       });
    }

    addToast(`Invoice penagihan ${newInvoiceWithId.invoiceNumber} berhasil dibuat.`, 'success');
    return newInvoiceWithId.id;
  };


  if (isLoadingData && isAuthenticated) {
    return (
      <div className="loading-spinner-overlay">
        <div className="loading-spinner"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} addToast={addToast} />;
  }

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden"> 
      {isMobileSidebarOpen && (
        <div 
          className="fixed inset-0 z-30 bg-black/50 md:hidden"
          onClick={() => setIsMobileSidebarOpen(false)}
          aria-hidden="true"
        ></div>
      )}

      <Sidebar 
        userProfile={userProfile} 
        notifications={notifications} 
        onLogout={handleLogout} 
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobileSidebar={() => setIsMobileSidebarOpen(false)}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="md:hidden bg-white shadow-sm sticky top-0 z-20 border-b border-gray-200"> 
            <div className="px-4 sm:px-6 h-14 flex items-center justify-between">
                <button
                type="button"
                className="-ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-gray-500"
                onClick={() => setIsMobileSidebarOpen(true)}
                >
                <span className="sr-only">Open sidebar</span>
                <Bars3Icon className="h-6 w-6" aria-hidden="true" />
                </button>
                <div className="font-semibold text-gray-800">{userProfile.companyName || 'Vena Pictures'}</div>
                 <div></div> 
            </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-gray-50"> 
          <Routes>
            <Route path="/" element={<Navigate to={`/${NavigationItemKey.Dashboard}`} replace />} />
            <Route path={`/${NavigationItemKey.Dashboard}`} element={
              <DashboardPage 
                transactions={transactions} 
                projects={projects} 
                clients={clients} 
                activityLog={activityLog} 
              />} 
            />
            <Route path={`/${NavigationItemKey.Klien}`} element={
              <KlienPage 
                clients={clients} addClient={addClientFS} updateClient={updateClientFS} deleteClient={deleteClientFS} 
                addTransaction={addTransactionFS} addProject={addProjectFS} allPackages={packages} allAddOns={addOns}
                allProjects={projects} bankDetails={bankDetails} systemOptions={systemOptions} updateProject={updateProjectFS}
                userProfile={userProfile} openViewInvoiceModalById={openViewInvoiceModalById} addActivityLogItem={addActivityLogItem}
                addToast={addToast} generateInvoiceNumber={generateInvoiceNumber} addBillingInvoice={addBillingInvoiceFS}
              />} 
            />
            <Route path={`/${NavigationItemKey.Proyek}`} element={
              <ProyekPage 
                projects={projects} addProject={addProjectFS} updateProject={updateProjectFS} deleteProject={deleteProjectFS}
                allClients={clients} allFreelancers={freelancers} addTransaction={addTransactionFS}
                systemOptions={systemOptions} onViewFreelancerDetail={handleViewFreelancerDetailFromApp} addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.Freelancer}`} element={
              <FreelancerPage 
                freelancers={freelancers} addFreelancer={addFreelancerFS} updateFreelancer={updateFreelancerFS} deleteFreelancer={deleteFreelancerFS}
                allClientProjects={projects} allFreelancerProjects={freelancerProjects}
                addFreelancerProject={addFreelancerProjectFS} updateFreelancerProject={updateFreelancerProjectFS}
                systemOptions={systemOptions} onViewFreelancerDetail={handleViewFreelancerDetailFromApp}
                appModals={appModals} setAppModals={setAppModals} addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.ProyekFreelancer}`} element={
              <ProyekFreelancerPage
                freelancerProjects={freelancerProjects} addFreelancerProject={addFreelancerProjectFS}
                updateFreelancerProject={updateFreelancerProjectFS} deleteFreelancerProject={deleteFreelancerProjectFS}
                allClientProjects={projects} allFreelancers={freelancers} systemOptions={systemOptions}
                onViewClientProject={handleViewProjectDetailFromApp} onViewFreelancer={handleViewFreelancerDetailFromApp}
                addToast={addToast}
              />} 
            />
            <Route path={`/${NavigationItemKey.Keuangan}`} element={
              <KeuanganPage 
                transactions={transactions} addTransaction={addTransactionFS} systemOptions={systemOptions}
                allClients={clients} allProjects={projects} allFreelancers={freelancers}
                kantongs={kantongs} addKantong={addKantongFS} updateKantong={updateKantongFS} deleteKantong={deleteKantongFS}
                onTransferAntarKantong={handleTransferAntarKantongFS}
                autoBudgetRules={autoBudgetRules} onAddAutoBudgetRule={addAutoBudgetRuleFS}
                onUpdateAutoBudgetRule={updateAutoBudgetRuleFS} onDeleteAutoBudgetRule={deleteAutoBudgetRuleFS}
                scheduledTransfers={scheduledTransfers} onAddScheduledTransfer={addScheduledTransferFS}
                onUpdateScheduledTransfer={updateScheduledTransferFS} onDeleteScheduledTransfer={deleteScheduledTransferFS}
                generalReceipts={generalReceipts} expenseVouchers={expenseVouchers}
                openViewInvoiceModalById={openViewInvoiceModalById} openViewExpenseVoucherModal={openViewExpenseVoucherModal}
                addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.KpiKlien}`} element={
              <KpiKlienPage
                  chatEvaluationEntries={chatEvaluationEntries} addChatEvaluationEntry={addChatEvaluationEntryFS}
                  updateChatEvaluationEntry={updateChatEvaluationEntryFS} systemOptions={systemOptions} addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.KpiAdmin}`} element={
              <KpiAdminPage
                  clients={clients} projects={projects} transactions={transactions}
                  freelancers={freelancers} freelancerProjects={freelancerProjects} kantongs={kantongs}
              />}
            />
            <Route path={`/${NavigationItemKey.Kalender}`} element={
              <KalenderPage 
                events={calendarEvents} addEvent={addCalendarEventFS} updateEvent={updateCalendarEventFS} deleteEvent={deleteCalendarEventFS}
                systemOptions={systemOptions} addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.Notifikasi}`} element={
              <NotifikasiPage notifications={notifications} onMarkAsRead={markNotificationAsRead} onClearAll={clearAllNotifications} />}
            />
            <Route path={`/${NavigationItemKey.Pengaturan}/*`} element={
              <PengaturanPage
                packages={packages} addOns={addOns} bankDetails={bankDetails} systemOptions={systemOptions}
                userProfile={userProfile} notificationSettings={userProfile.notificationSettings || initialNotificationSettings}
                onAddPackage={addPackageFS} onUpdatePackage={updatePackageFS} onDeletePackage={deletePackageFS}
                onAddAddOn={addAddOnFS} onUpdateAddOn={updateAddOnFS} onDeleteAddOn={deleteAddOnFS}
                onUpdateBankDetails={updateBankDetailsFS} onUpdateSystemOptions={updateSystemOptionsApp}
                onUpdateUserProfile={handleUpdateUserProfileApp} onUpdateNotificationSettings={updateNotificationSettingsApp}
                addToast={addToast}
              />}
            />
          </Routes>

          {appModals.projectDetail.isOpen && appModals.projectDetail.projectId && (
            <ProyekDetailModal
              isOpen={appModals.projectDetail.isOpen} onClose={closeAppProjectDetailModal}
              project={projects.find(p => p.id === appModals.projectDetail.projectId) || null}
              client={clients.find(c => c.id === (projects.find(p => p.id === appModals.projectDetail.projectId)?.clientId)) || null}
              onUpdateProject={updateProjectFS} addTransaction={addTransactionFS} allFreelancers={freelancers} allFreelancerProjects={freelancerProjects}
              systemOptions={systemOptions} onViewFreelancerDetail={handleViewFreelancerDetailFromApp} addToast={addToast}
            />
          )}
          {appModals.freelancerDetail.isOpen && appModals.freelancerDetail.freelancerId && (
              <FreelancerDetailModal
                  isOpen={appModals.freelancerDetail.isOpen} onClose={closeAppFreelancerDetailModal}
                  freelancer={freelancers.find(f => f.id === appModals.freelancerDetail.freelancerId) || null}
                  allFreelancerProjects={freelancerProjects} allClientProjects={projects}
                  onUpdateFreelancerProject={updateFreelancerProjectFS} transactions={transactions} addToast={addToast}
                  onDeleteFreelancer={deleteFreelancerFS}
              />
          )}
          {appModals.freelancerEarnings.isOpen && appModals.freelancerEarnings.freelancerId && (
              <FreelancerEarningsModal
                  isOpen={appModals.freelancerEarnings.isOpen} onClose={closeAppFreelancerEarningsModal}
                  freelancer={freelancers.find(f => f.id === appModals.freelancerEarnings.freelancerId) || null}
                  freelancerProjects={freelancerProjects.filter(fp => fp.freelancerId === appModals.freelancerEarnings.freelancerId)}
                  transactions={transactions} setAppModals={setAppModals} openFreelancerPaymentVoucherModal={openFreelancerPaymentVoucherModal}
              />
          )}
          {appModals.payFreelancer.isOpen && appModals.payFreelancer.freelancerId && (
              <PayFreelancerModal
                  isOpen={appModals.payFreelancer.isOpen} onClose={closePayFreelancerModal}
                  freelancer={freelancers.find(f => f.id === appModals.payFreelancer.freelancerId) || null}
                  freelancerProjects={freelancerProjects.filter(fp => fp.freelancerId === appModals.payFreelancer.freelancerId)}
                  onSave={async (freelancerId, paymentAmount, paymentDate, paymentMethod, notes, linkedFpId) => {
                      const freelancer = freelancers.find(f=>f.id===freelancerId);
                      if (freelancer) {
                          await addTransactionFS({
                              date: paymentDate, description: notes || `Pembayaran fee untuk ${freelancer.name}`,
                              category: 'Fee Proyek', type: 'Pengeluaran', amount: paymentAmount, method: paymentMethod,
                              linkedFreelancerId: freelancerId, linkedFreelancerProjectId: linkedFpId,
                              kantongId: kantongs.find(k => k.name.toLowerCase().includes("operasional") || k.type === "Bayar")?.id || kantongs[0]?.id,
                          });
                          closePayFreelancerModal();
                      }
                  }}
                  context={appModals.payFreelancer.context} addToast={addToast}
              />
          )}
          {appModals.savingsWithdrawal.isOpen && appModals.savingsWithdrawal.freelancerId && (
              <SavingsWithdrawalModal
                  isOpen={appModals.savingsWithdrawal.isOpen} onClose={closeSavingsWithdrawalModal}
                  freelancer={freelancers.find(f => f.id === appModals.savingsWithdrawal.freelancerId) || null}
                  maxWithdrawable={freelancers.find(f => f.id === appModals.savingsWithdrawal.freelancerId)?.savings || 0}
                  onSave={recordSavingsWithdrawalFS} addToast={addToast}
              />
          )}
          {appModals.recordSavingsDeposit?.isOpen && appModals.recordSavingsDeposit.freelancerId && (
              <RecordSavingsDepositModal
                  isOpen={appModals.recordSavingsDeposit.isOpen} onClose={closeRecordSavingsDepositModal}
                  freelancer={freelancers.find(f => f.id === appModals.recordSavingsDeposit?.freelancerId) || null}
                  onSave={recordTeamSavingsDepositFS} addToast={addToast}
              />
          )}
          {appModals.viewInvoice?.isOpen && appModals.viewInvoice.invoice && (
              <ViewInvoiceModal
                  isOpen={appModals.viewInvoice.isOpen} onClose={closeViewInvoiceModal}
                  invoice={appModals.viewInvoice.invoice}
                  client={clients.find(c => c.id === appModals.viewInvoice.clientId) || null}
                  userProfile={userProfile} bankDetails={bankDetails} allProjects={projects} allPackages={packages}
              />
          )}
          {appModals.freelancerPaymentVoucher?.isOpen && appModals.freelancerPaymentVoucher.transactionId && (
              <FreelancerPaymentVoucherModal
                  isOpen={appModals.freelancerPaymentVoucher.isOpen} onClose={closeFreelancerPaymentVoucherModal}
                  transaction={transactions.find(t => t.id === appModals.freelancerPaymentVoucher?.transactionId) || null}
                  freelancer={freelancers.find(f => f.id === (transactions.find(t => t.id === appModals.freelancerPaymentVoucher?.transactionId)?.linkedFreelancerId)) || null}
                  userProfile={userProfile}
              />
          )}
          {appModals.viewExpenseVoucher?.isOpen && appModals.viewExpenseVoucher.expenseVoucherId && (
              <ViewExpenseVoucherModal
                  isOpen={appModals.viewExpenseVoucher.isOpen} onClose={closeViewExpenseVoucherModal}
                  voucher={expenseVouchers.find(v => v.id === appModals.viewExpenseVoucher?.expenseVoucherId) || null}
                  userProfile={userProfile}
              />
          )}
          <ToastContainer toasts={toasts} removeToast={removeToast} />
        </main>
      </div>
    </div>
  );
}

export default App;
