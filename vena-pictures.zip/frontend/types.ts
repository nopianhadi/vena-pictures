// frontend/types.ts
import React from 'react';

export enum Currency {
  IDR = 'Rp',
}

export enum PaymentStatus {
  Paid = 'Lunas',
  Unpaid = 'Belum Bayar',
  Partial = 'DP Terbayar',
  Overdue = 'Jatuh Tempo',
}

export enum ProjectStatus {
  Pending = 'Tertunda', 
  InProgress = 'Sedang Berjalan', 
  Completed = 'Selesai', 
  OnHold = 'Ditahan', 
  Cancelled = 'Dibatalkan', 
}

export type PackageType = 'Pernikahan' | 'Prewedding' | 'Lainnya' | 'Lamaran' | 'Korporat' | 'Acara Korporat' | 'Acara Pribadi' | 'Produk';
export type FreelancerRole = "Fotografer" | "Videografer" | "Editor" | "Editor Foto" | "Editor Video" | "Asisten" | "Asisten Fotografer" | "MUA" | "Tim Internal" | "Pilot Drone" | "Desainer Grafis" | "Admin Media Sosial";
export type FreelancerType = 'Tim Internal' | 'Freelancer Eksternal'; 

export interface PaymentRecord {
  id: string;
  date: string; // YYYY-MM-DD
  amount: number;
  method?: string;
  notes?: string;
  projectId?: string;
  invoiceId?: string;
}

export interface CommunicationEntry {
  id: string;
  date: string; // YYYY-MM-DD
  type: 'Telepon' | 'Rapat' | 'Email' | 'Lainnya' | 'WhatsApp' | 'Zoom Meeting'; 
  notes: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
}

export enum InvoiceStatus {
  Draft = 'Konsep',
  Sent = 'Terkirim',
  Paid = 'Lunas',
  Partial = 'Dibayar Sebagian',
  Overdue = 'Jatuh Tempo',
  Cancelled = 'Dibatalkan',
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  projectId?: string;
  issueDate: string;
  dueDate?: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate?: number;
  taxAmount?: number;
  totalAmount: number;
  amountPaid: number;
  balanceDue: number;
  status: InvoiceStatus;
  notes?: string;
  paymentInstructions?: string;
  paymentHistory: PaymentRecord[];
}

export interface ExpenseVoucher {
  id: string;
  voucherNumber: string;
  transactionId: string; 
  date: string;
  payeeName?: string;
  payeeType?: 'Freelancer' | 'Vendor' | 'Karyawan' | 'Lainnya';
  description: string;
  category: string;
  amount: number;
  method: string;
  paidBy?: string;
  notes?: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  instagram?: string;
  dateAdded: string;
  totalProjects: number;
  paymentStatus: PaymentStatus;
  address?: string;
  eventDate?: string;
  packageName?: string;
  packagePrice?: number;
  addOns?: AddOn[];
  totalProjectValue?: number;
  downPayment?: number;
  remainingPayment?: number;
  additionalNotes?: string;
  accommodation?: string;
  googleDriveLink?: string;
  paymentHistory?: PaymentRecord[];
  source?: string;
  tags?: string[];
  communicationLog?: CommunicationEntry[];
  paymentsPerProject?: Record<string, number>;
  invoices?: Invoice[];
}

export interface Task {
  id: string;
  description: string;
  dueDate?: string;
  isCompleted: boolean;
  assigneeId?: string;
  priority?: 'Rendah' | 'Sedang' | 'Tinggi'; 
  freelancerProjectId?: string; 
  freelancerProjectName?: string; 
}

export interface ProjectDocument {
    id: string;
    description: string;
    url: string;
}

export interface Project {
  id: string;
  name: string;
  clientName: string;
  clientId: string;
  date: string;
  status: ProjectStatus;
  progress: number;
  projectType?: string;
  package?: string;
  preparationStatus?: string;
  location?: string;
  eventDate?: string;
  budget?: number;
  deadline?: string;
  assignedTeam?: string[];
  additionalNotes?: string;
  documents?: ProjectDocument[];
  expenditure?: number;
  tasks?: Task[];
  totalClientPayments?: number;
  totalFreelancerPayments?: number;
  totalBudgetedFreelancerCost?: number; 
  invoices?: Invoice[];
}

export interface Freelancer {
  id: string;
  name: string;
  role: FreelancerRole;
  projectCount?: number;
  standardFee?: number; 
  totalEarnings?: number;
  savings?: number; 
  status: 'Aktif' | 'Nonaktif'; 
  phone?: string;
  email?: string;
  type: FreelancerType;
  skills?: string[];
  portfolioLink?: string;
  availabilityNotes?: string;
  contractLink?: string;
  contractStartDate?: string;
  contractEndDate?: string;
  address?: string;
  joinDate?: string;
  equipment?: string[];
  equipmentNotes?: string;
  bankName?: string;
  accountNumber?: string;
  accountHolderName?: string;
}

export interface DetailedDeliverable {
    id: string;
    description: string;
    dueDate?: string;
    status: 'Pending' | 'Submitted' | 'Approved' | 'Revision Needed';
    fileLink?: string;
}

export interface FreelancerProject {
  id: string;
  projectName: string;
  projectId?: string;
  freelancerName: string;
  freelancerId: string;
  role: FreelancerRole;
  dateAssigned: string;
  status: ProjectStatus;
  progress: number;
  payment: number;
  paymentStatus: PaymentStatus;
  startDate?: string;
  endDate?: string;
  totalPayment?: number;
  paidAmount?: number;
  remainingAmount?: number;
  detailedDeliverables?: DetailedDeliverable[];
  notes?: string;
  performanceRating?: number;
  performanceNotes?: string;
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  category: string;
  type: 'Pemasukan' | 'Pengeluaran';
  amount: number;
  method: string;
  linkedClientId?: string;
  linkedProjectId?: string;
  linkedFreelancerId?: string;
  linkedFreelancerProjectId?: string;
  kantongId?: string;
  invoiceId?: string;
  isPlaceholder?: boolean; 
}

export interface FinancialSummaryCardProps {
  title: string;
  value: string;
  percentageChange?: string;
  isPositive?: boolean;
  icon: React.ReactElement<React.SVGProps<SVGSVGElement>>;
  onClick?: () => void;
  isActive?: boolean;
}

export interface ActivityItem {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  targetType?: 'Project' | 'Client' | 'Transaction' | 'Freelancer' | 'FreelancerProject' | 'Kantong' | 'Package' | 'AddOn' | 'BankDetails' | 'SystemOptions' | 'UserProfile' | 'AutoBudgetRule' | 'ScheduledTransfer' | 'CalendarEvent' | 'ChatEvaluation' | 'Invoice' | 'ExpenseVoucher' | 'Notification' | 'TeamSavings' | 'Other';
  targetName?: string;
  targetId?: string;
  details?: string;
  amount?: number;
}

export interface Package {
  id: string;
  name: string;
  price: number;
  duration?: string;
  services: string[];
  type: PackageType;
}

export interface AddOn {
  id:string;
  name: string;
  price: number;
  unit?: string;
  description?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  startTime?: string;
  endTime?: string;
  type: 'projectClient' | 'projectDeadline' | 'projectFreelancer' | 'reminder' | 'meeting' | 'personal' | 'projectTaskDeadline' | 'contractReminder' | 'projectFreelancerMilestone';
  description?: string;
  color?: 'blue' | 'green' | 'red' | 'yellow' | 'purple' | 'orange' | 'teal';
  relatedId?: string;
}

export interface NotificationSettings {
    deadlineProject: boolean;
    deadlineTask: boolean;
    contractEnd: boolean;
    lowBalance: boolean;
    paymentReceived: boolean;
    generalReminder: boolean;
}

export interface UserProfile {
  id: string; 
  avatarUrl?: string;
  fullName: string;
  email: string;
  username: string;
  phone: string;
  companyName?: string;
  companyAddress?: string;
  companyPhone?: string;
  companyEmail?: string;
  companyWebsite?: string;
  bio?: string;
  address?: string;
  website?: string;
  invoiceLogoUrl?: string;
  invoiceTerms?: string;
  invoiceFooter?: string;
  notificationSettings?: NotificationSettings;
}

export interface BankDetail {
  id: string;
  bankName: string;
  accountNumber: string;
  accountHolder: string;
}

export interface SystemOptionValueLabel {
  value: string;
  label: string;
}

export type KantongType = 'Bayar' | 'Nabung' | 'Terkunci' | 'Bersama' | 'Umum';
export const KANTONG_TYPES: KantongType[] = ['Bayar', 'Nabung', 'Terkunci', 'Bersama', 'Umum'];

export type ClientRegion = string;
export type ChatChannel = string;
export type ChatStatus = string;

export interface SystemOptions {
  projectTypes: string[];
  transactionCategories: string[];
  transactionMethods: string[];
  freelancerRoles: FreelancerRole[];
  packageTypes: PackageType[];
  calendarEventTypes: Array<SystemOptionValueLabel & {value: CalendarEvent['type']}>;
  clientSources: string[];
  clientTags: string[];
  communicationTypes: Array<SystemOptionValueLabel & {value: CommunicationEntry['type']}>;
  taskPriorities?: Array<SystemOptionValueLabel & {value: Task['priority']}>;
  detailedDeliverableStatusOptions?: Array<SystemOptionValueLabel & {value: DetailedDeliverable['status']}>;
  kantongTypes: Array<SystemOptionValueLabel & {value: KantongType}>;
  clientRegions: ClientRegion[];
  chatChannels: ChatChannel[];
  chatStatuses: ChatStatus[];
}


export enum NavigationItemKey {
  Dashboard = 'dashboard',
  Klien = 'klien',
  Proyek = 'proyek',
  Freelancer = 'freelancer',
  ProyekFreelancer = 'proyek-freelancer',
  Keuangan = 'keuangan',
  KpiKlien = 'kpi-klien',
  KpiAdmin = 'kpi-admin',
  Kalender = 'kalender',
  Notifikasi = 'notifikasi',
  Pengaturan = 'pengaturan',
}

export interface NavItem {
  key: NavigationItemKey;
  label: string;
  icon: (props: React.SVGProps<SVGSVGElement> & {children?: React.ReactNode}) => JSX.Element;
  path: string;
}

export interface TabItem {
  id: string;
  label: string;
  content: React.ReactNode;
}

export interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

export interface GenericFormModalProps<T> {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: T, ...args: any[]) => void; 
  existingItem?: Partial<T> | T | null; 
  addToast?: (message: string, type?: ToastMessage['type']) => void;
  systemOptions?: SystemOptions; 
}

export interface AppModalState {
  projectDetail: { isOpen: boolean; projectId: string | null; };
  freelancerDetail: { isOpen: boolean; freelancerId: string | null; };
  freelancerEarnings: { isOpen: boolean; freelancerId: string | null; };
  payFreelancer: { isOpen: boolean; freelancerId: string | null; context?: 'fee'; };
  savingsWithdrawal: { isOpen: boolean; freelancerId: string | null; };
  recordSavingsDeposit: { isOpen: boolean; freelancerId: string | null; };
  viewInvoice?: { isOpen: boolean; invoice: Invoice | null; invoiceId?: string | null; clientId?: string | null; };
  freelancerPaymentVoucher?: { isOpen: boolean; transactionId: string | null; };
  viewExpenseVoucher?: { isOpen: boolean; expenseVoucherId: string | null; };
}

export interface Kantong {
  id: string;
  name: string;
  balance: number;
  type: KantongType;
  description?: string;
  targetAmount?: number;
  interestRate?: number;
  lockEndDate?: string;
}

export interface AutoBudgetRule {
  id: string;
  description: string;
  sourceType: 'main_balance' | 'kantong';
  sourceKantongId?: string;
  destinationKantongId: string;
  amount: number;
  frequency: 'daily' | 'weekly' | 'monthly' | 'specific_date' | 'on_income';
  dayOfWeek?: number;
  dayOfMonth?: number;
  lastRunDate?: string;
  nextRunDate?: string;
  isActive: boolean;
}

export interface ScheduledTransfer {
  id: string;
  description: string;
  sourceKantongId: string;
  recipientType: 'internal_kantong' | 'external_account';
  destinationKantongId?: string;
  externalRecipientName?: string;
  externalBankName?: string;
  externalAccountNumber?: string;
  amount: number;
  frequency: 'once' | 'daily' | 'weekly' | 'monthly';
  startDate: string;
  endDate?: string;
  dayOfWeek?: number;
  dayOfMonth?: number;
  lastRunDate?: string;
  nextRunDate?: string;
  isActive: boolean;
}

export interface ChatEvaluationEntry {
  id: string;
  date: string;
  clientName?: string;
  region: ClientRegion;
  channel: ChatChannel;
  clientQuery: string;
  status: ChatStatus;
  responseTimeMinutes: number;
}

export type NotificationType = 'deadline_project' | 'deadline_task' | 'contract_end' | 'low_balance' | 'payment_received' | 'general_reminder';

export interface NotificationItem {
    id: string;
    type: NotificationType;
    title: string;
    message: string;
    date: string;
    isRead: boolean;
    relatedId?: string;
    linkTo?: string;
}

export interface KlienPageProps {
  clients: Client[];
  addClient: (clientData: Omit<Client, 'id'>, projectData?: Omit<Project, 'id'>) => Promise<Client | null>;
  updateClient: (client: Client) => void;
  deleteClient: (clientId: string) => void;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => Promise<Transaction | null | void>;
  addProject: (projectData: Omit<Project, 'id'>) => Promise<Project | null | void>;
  allPackages: Package[];
  allAddOns: AddOn[];
  allProjects: Project[];
  bankDetails: BankDetail[];
  systemOptions: SystemOptions;
  updateProject: (project: Project) => void;
  userProfile: UserProfile;
  openViewInvoiceModalById: (invoiceId: string, clientId?: string) => void;
  addActivityLogItem: (item: Omit<ActivityItem, 'id' | 'timestamp' | 'user'>) => void;
  addToast: (message: string, type?: ToastMessage['type']) => void;
  generateInvoiceNumber: (clientId: string, date: Date) => string;
  addBillingInvoice: (invoice: Omit<Invoice, 'id'>, clientId: string, projectId?: string) => Promise<string>;
}

export interface ProyekPageProps {
  projects: Project[];
  addProject: (project: Omit<Project, 'id'>) => Promise<Project | null | void>;
  updateProject: (project: Project) => void;
  deleteProject: (projectId: string) => void;
  allClients: Client[];
  allFreelancers: Freelancer[];
  addTransaction: (transaction: Omit<Transaction, 'id'>) => Promise<Transaction | null | void>;
  systemOptions: SystemOptions;
  onViewFreelancerDetail?: (freelancerId: string) => void;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface FreelancerPageProps {
  freelancers: Freelancer[];
  addFreelancer: (freelancer: Omit<Freelancer, 'id'>) => void; 
  updateFreelancer: (freelancer: Freelancer) => void;
  deleteFreelancer: (freelancerId: string) => void;
  allClientProjects: Project[];
  allFreelancerProjects: FreelancerProject[];
  addFreelancerProject: (fp: Omit<FreelancerProject, 'id'>) => void;
  updateFreelancerProject: (fp: FreelancerProject) => void;
  systemOptions: SystemOptions;
  onViewFreelancerDetail: (freelancerId: string) => void;
  appModals: AppModalState;
  setAppModals: React.Dispatch<React.SetStateAction<AppModalState>>;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface ProyekFreelancerPageProps {
  freelancerProjects: FreelancerProject[];
  addFreelancerProject: (fp: Omit<FreelancerProject, 'id'>) => void;
  updateFreelancerProject: (fp: FreelancerProject) => void;
  deleteFreelancerProject: (fpId: string) => void;
  allClientProjects: Project[];
  allFreelancers: Freelancer[];
  systemOptions: SystemOptions;
  onViewClientProject?: (projectId: string) => void;
  onViewFreelancer?: (freelancerId: string) => void;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface KpiKlienPageProps {
  chatEvaluationEntries: ChatEvaluationEntry[];
  addChatEvaluationEntry: (entry: Omit<ChatEvaluationEntry, 'id'>) => void;
  updateChatEvaluationEntry: (entry: ChatEvaluationEntry) => void;
  systemOptions: SystemOptions;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface KpiAdminPageProps {
    clients: Client[];
    projects: Project[];
    transactions: Transaction[];
    freelancers: Freelancer[];
    freelancerProjects: FreelancerProject[];
    kantongs: Kantong[];
}

export interface KalenderPageProps {
  events: CalendarEvent[];
  addEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  updateEvent: (updatedEvent: CalendarEvent) => void;
  deleteEvent: (eventId: string) => void;
  systemOptions: SystemOptions;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface LoginPageProps {
  onLoginSuccess: () => void; 
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface ProyekDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project | null;
  client: Client | null;
  onUpdateProject: (project: Project) => void;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => Promise<Transaction | null | void>;
  allFreelancers: Freelancer[];
  allFreelancerProjects?: FreelancerProject[]; 
  systemOptions: SystemOptions;
  onViewFreelancerDetail?: (freelancerId: string) => void;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface AddKlienModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (client: Omit<Client, 'id'>, project?: Omit<Project, 'id'>) => void;
  existingItem?: Client | null;
  allPackages: Package[];
  allAddOns: AddOn[];
  systemOptions: SystemOptions;
  addTransaction?: (transaction: Omit<Transaction, 'id'> & {id?: string}) => void;
  updateProject?: (project: Project) => void;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface AddProyekModalProps extends GenericFormModalProps<Project> {
  clients: Client[];
  projectTypes: string[];
  allFreelancers: Freelancer[];
  onSave: (project: Omit<Project, 'id'>) => void; 
}

export interface AddFreelancerOrTeamModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (freelancer: Freelancer, action?: 'saveAndClose' | 'saveAndAddNew') => void;
    existingFreelancer?: Freelancer | null;
    defaultType: FreelancerType;
    systemOptions: SystemOptions;
    addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface AddFreelancerProjectModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (freelancerProject: FreelancerProject) => void;
    allProjects: Project[];
    allFreelancers: Freelancer[];
    roles: FreelancerRole[];
    existingFreelancerProject?: FreelancerProject | null;
    defaultFreelancerId?: string;
    systemOptions?: SystemOptions;
    addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface ProjectExpenditureModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (expenditureItem: Omit<Transaction, 'id' | 'type' | 'linkedClientId' | 'linkedFreelancerId' | 'linkedFreelancerProjectId' | 'linkedProjectId'>) => void;
    projectId: string;
    projectName: string;
    systemOptions: SystemOptions;
    addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface RecordPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (paymentDetails: Omit<PaymentRecord, 'id' | 'invoiceId'>, projectId?: string) => void;
  clientName: string;
  remainingAmount: number;
  clientProjects: Project[];
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface PayFreelancerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (freelancerId: string, paymentAmount: number, paymentDate: string, paymentMethod: string, notes: string, linkedFreelancerProjectId?: string) => void;
  freelancer: Freelancer | null;
  freelancerProjects: FreelancerProject[];
  context?: 'fee'; 
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface SavingsWithdrawalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (freelancerId: string, amount: number, date: string, notes?: string) => void;
  freelancer: Freelancer | null;
  maxWithdrawable: number;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface RecordSavingsDepositModalProps { 
  isOpen: boolean;
  onClose: () => void;
  onSave: (freelancerId: string, amount: number, date: string, notes?: string) => void;
  freelancer: Freelancer | null;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface TransferKantongModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTransfer: (sourceKantongId: string, destinationKantongId: string, amount: number, date: string, notes?: string) => void;
  kantongs: Kantong[];
  defaultSourceKantongId?: string;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface CreateBillingInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (invoice: Omit<Invoice, 'id'>, clientId: string, projectId?: string) => Promise<string>; 
  client: Client;
  allPackages: Package[];
  allAddOns: AddOn[];
  allClientProjects: Project[]; 
  userProfile: UserProfile;
  generateInvoiceNumber: (clientId: string, date: Date) => string;
  addToast: (message: string, type?: ToastMessage['type']) => void;
}

export interface GlobalSettingsTabProps<T> {
  items: T[];
  onAddItem: (item: Omit<T, 'id'>) => void;
  onUpdateItem: (item: T) => void;
  onDeleteItem: (itemId: string) => void;
  systemOptions?: SystemOptions;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface BankDetailsSettingsTabProps {
    bankDetails: BankDetail[];
    onUpdateBankDetails: (details: BankDetail[]) => void;
    addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface SystemOptionsSettingsTabProps {
    systemOptions: SystemOptions;
    onUpdateSystemOptions: (options: SystemOptions) => void;
    addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface ProfileSettingsTabProps {
    userProfile: UserProfile;
    onUpdateUserProfile: (profile: UserProfile) => void;
    addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface CompanySettingsTabProps {
    userProfile: UserProfile;
    onUpdateUserProfile: (profile: UserProfile) => void;
    addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface NotificationSettingsTabProps {
  notificationSettings: NotificationSettings;
  onUpdateNotificationSettings: (settings: NotificationSettings) => void;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface KlienDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: Client | null;
  allPackages: Package[];
  allAddOns: AddOn[];
  allProjects: Project[];
  bankDetails: BankDetail[];
  onUpdateClient: (client: Client) => void;
  systemOptions: SystemOptions;
  userProfile: UserProfile;
  openViewInvoiceModalById: (invoiceId: string, clientId?: string) => void;
  addToast?: (message: string, type?: ToastMessage['type']) => void; 
}

export interface FreelancerDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  freelancer: Freelancer | null;
  allFreelancerProjects: FreelancerProject[];
  allClientProjects: Project[];
  onUpdateFreelancerProject?: (fp: FreelancerProject) => void;
  transactions: Transaction[];
  onDeleteFreelancer?: (freelancerId: string) => void;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface FreelancerEarningsModalProps {
    isOpen: boolean;
    onClose: () => void;
    freelancer: Freelancer | null;
    freelancerProjects: FreelancerProject[];
    transactions: Transaction[];
    setAppModals: React.Dispatch<React.SetStateAction<AppModalState>>;
    openFreelancerPaymentVoucherModal?: (transactionId: string) => void;
}

export interface FreelancerPaymentVoucherModalProps {
    isOpen: boolean;
    onClose: () => void;
    transaction: Transaction | null;
    freelancer: Freelancer | null;
    userProfile: UserProfile;
}

export interface ViewExpenseVoucherModalProps {
    isOpen: boolean;
    onClose: () => void;
    voucher: ExpenseVoucher | null;
    userProfile: UserProfile;
}

export interface KantongDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  kantong: Kantong;
  transactions: Transaction[];
  onEditKantong: (kantong: Kantong) => void;
  onDeleteKantong: (kantongId: string) => void;
  onTransferAntarKantong: (sourceKantongId: string, destinationKantongId: string, amount: number, date: string, notes?: string) => void;
  allKantongs: Kantong[];
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

export interface ViewInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  client: Client | null;
  userProfile: UserProfile;
  bankDetails: BankDetail[];
  allProjects: Project[];
  allPackages: Package[];
}

export interface SidebarProps {
  userProfile: UserProfile; 
  notifications?: NotificationItem[];
  onLogout?: () => void;
  isMobileOpen: boolean;
  onCloseMobileSidebar: () => void;
}

export interface AddKantongModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (kantong: Omit<Kantong, 'id'>) => void; 
  existingKantong?: Kantong | null;
  systemOptions?: SystemOptions;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}
