// frontend/firebaseConfig.ts
// TODO: Replace with your actual Firebase project configuration
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY", // Get this from Firebase console
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com", // Get this from Firebase console
  projectId: "YOUR_PROJECT_ID", // Get this from Firebase console
  storageBucket: "YOUR_PROJECT_ID.appspot.com", // Get this from Firebase console
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID", // Get this from Firebase console
  appId: "YOUR_APP_ID", // Get this from Firebase console
  measurementId: "YOUR_MEASUREMENT_ID" // Optional: Get this from Firebase console
};
