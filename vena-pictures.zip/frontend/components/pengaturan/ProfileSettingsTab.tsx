// frontend/components/pengaturan/ProfileSettingsTab.tsx
import React, { useState, useEffect } from 'react';
import { UserProfile, ProfileSettingsTabProps, ToastMessage } from '../../types';
import Input, { TextArea } from '../ui/Input';
import Button from '../ui/Button';
import Card from '../ui/Card';
import { DEFAULT_AVATAR_URL } from '../../constants'; // Import default avatar

const ProfileSettingsTab: React.FC<ProfileSettingsTabProps> = ({ userProfile, onUpdateUserProfile, addToast }) => {
  const [profile, setProfile] = useState<UserProfile>(userProfile);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(userProfile.avatarUrl || null);

  useEffect(() => {
    setProfile(userProfile);
    setAvatarPreview(userProfile.avatarUrl || null);
  }, [userProfile]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 1024 * 1024) { // Check file size (1MB limit)
        addToast?.('Ukuran file foto terlalu besar. Maksimum 1MB.', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
        setProfile(prev => ({ ...prev, avatarUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    onUpdateUserProfile(profile);
    addToast?.('Profil pengguna berhasil disimpan.', 'success');
  };

  const getAvatarDisplayUrl = () => {
    if (avatarPreview) return avatarPreview;
    if (profile.avatarUrl) return profile.avatarUrl;
    if (profile.fullName && profile.fullName.trim() !== '') {
      return `https://ui-avatars.com/api/?name=${encodeURIComponent(profile.fullName)}&background=4F46E5&color=fff&size=128`;
    }
    return DEFAULT_AVATAR_URL;
  };


  return (
    <Card title="Profil Pengguna">
      <p className="text-sm text-gray-500 mb-6">Kelola informasi profil Anda dan preferensi pribadi.</p>
      <div className="space-y-6">
        <div className="flex items-center space-x-6">
          <img
            src={getAvatarDisplayUrl()}
            alt={profile.fullName}
            className="w-24 h-24 rounded-full object-cover ring-2 ring-offset-2 ring-indigo-200"
          />
          <div>
            <label htmlFor="avatarUpload" className="cursor-pointer inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
              Ubah Foto
            </label>
            <input id="avatarUpload" name="avatarUpload" type="file" className="sr-only" onChange={handleAvatarChange} accept="image/*" />
            <p className="text-xs text-gray-500 mt-1">JPG, GIF atau PNG. Maks 1MB.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Nama Lengkap" name="fullName" value={profile.fullName} onChange={handleChange} placeholder="Masukkan nama lengkap Anda"/>
            <Input label="Username" name="username" value={profile.username} onChange={handleChange} placeholder="Username unik Anda"/>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Email" name="email" type="email" value={profile.email} onChange={handleChange} placeholder="email@example.com" disabled/>
            <Input label="Nomor Telepon" name="phone" value={profile.phone} onChange={handleChange} placeholder="08123456xxxx"/>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Alamat Pribadi (Opsional)" name="address" value={profile.address || ''} onChange={handleChange} placeholder="Jl. Contoh No. 123"/>
            <Input label="Website Pribadi (Opsional)" name="website" value={profile.website || ''} onChange={handleChange} placeholder="www.websiteanda.com"/>
        </div>
        <TextArea label="Bio Singkat" name="bio" value={profile.bio || ''} onChange={handleChange} rows={4} placeholder="Ceritakan sedikit tentang diri Anda atau layanan Anda..."/>
      </div>
      <div className="mt-8 pt-6 border-t border-gray-200 text-right">
        <Button onClick={handleSave} variant="primary">Simpan Perubahan Profil</Button>
      </div>
    </Card>
  );
};
export default ProfileSettingsTab;
