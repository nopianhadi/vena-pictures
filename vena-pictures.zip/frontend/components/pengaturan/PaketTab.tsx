import React, { useState } from 'react';
import { Package, Currency, PackageType, GlobalSettingsTabProps, ToastMessage } from '../../types';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Table from '../ui/Table';
import { PlusCircleIcon, PencilSquareIcon, TrashIcon, Bars3Icon } from '../../constants';
import AddPackageModal from './AddPackageModal'; 

const FilterButton: React.FC<{label: string; isActive: boolean; onClick: () => void;}> = ({ label, isActive, onClick }) => (
    <button
        type="button"
        onClick={onClick}
        className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1
            ${isActive 
                ? 'bg-white text-indigo-600 shadow-sm' 
                : 'text-slate-600 hover:bg-slate-200 hover:text-slate-800'
            }`}
    >
        {label}
    </button>
);

interface PaketTabContentProps extends GlobalSettingsTabProps<Package> {}

const PaketTab: React.FC<PaketTabContentProps> = ({ items: packages, onAddItem, onUpdateItem, onDeleteItem, systemOptions, addToast }) => {
  const [filterType, setFilterType] = useState<PackageType | 'All'>('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingPackage, setEditingPackage] = useState<Package | null>(null);

  const handleSavePackage = (pkg: Package) => {
    if (editingPackage) {
      onUpdateItem(pkg);
    } else {
      const { id, ...pkgData } = pkg;
      onAddItem(pkgData as Omit<Package, 'id'>);
    }
    setEditingPackage(null);
  };

  const openEditModal = (pkg: Package) => {
    setEditingPackage(pkg);
    setIsAddModalOpen(true);
  };
  
  const handleDeletePackage = (packageId: string) => {
    if (window.confirm("Apakah Anda yakin ingin menghapus paket ini?")) {
        onDeleteItem(packageId);
    }
  };

  const filteredPackages = packages.filter(p => filterType === 'All' || p.type === filterType);

  const columns = [
    { key: 'name', header: 'Nama Paket', render: (pkg:Package) => <span className="font-medium">{pkg.name}</span> },
    { key: 'price', header: 'Harga', render: (pkg: Package) => `${Currency.IDR} ${pkg.price.toLocaleString('id-ID')}` },
    { key: 'duration', header: 'Durasi', render: (pkg: Package) => pkg.duration || '-' },
    { 
      key: 'services', 
      header: 'Layanan', 
      render: (pkg: Package) => (
        <ul className="list-disc list-inside text-xs space-y-0.5 max-w-xs truncate">
          {pkg.services.slice(0,3).map((s, i) => <li key={i} className="truncate" title={s}>{s}</li>)}
          {pkg.services.length > 3 && <li className="text-gray-500">...dan lainnya ({pkg.services.length - 3})</li>}
        </ul>
      )
    },
    {
      key: 'actions',
      header: 'Aksi',
      render: (pkg: Package) => (
        <div className="flex items-center space-x-1">
          <Button variant="ghost" size="sm" title="Urutkan (Drag & Drop - TODO)" onClick={() => console.log('Toggle active/drag', pkg.id)}><Bars3Icon className="w-5 h-5 text-gray-500" /></Button>
          <Button variant="ghost" size="sm" title="Edit Paket" onClick={() => openEditModal(pkg)}><PencilSquareIcon className="w-4 h-4 text-blue-600" /></Button>
          <Button variant="ghost" size="sm" title="Hapus Paket" onClick={() => handleDeletePackage(pkg.id)}><TrashIcon className="w-4 h-4 text-red-500" /></Button>
        </div>
      ),
    },
  ];

  const filterOptions: {label: string; type: PackageType | 'All'}[] = [
    { label: 'Semua Paket', type: 'All'},
    ...(systemOptions?.packageTypes.map(pt => ({label: pt as string, type: pt})) || 
      [{ label: 'Wedding', type: 'Wedding'}, { label: 'Prewedding', type: 'Prewedding'}, { label: 'Lainnya', type: 'Lainnya'}])
  ];
  const uniqueFilterOptions = [
    filterOptions[0],
    ...filterOptions.slice(1).filter((opt, index, self) => 
        index === self.findIndex((t) => t.type === opt.type)
    )
  ];


  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-3">
        <div className="flex items-center bg-slate-100 p-0.5 rounded-lg space-x-0.5 self-start sm:self-center">
          {uniqueFilterOptions.map(opt => (
            <FilterButton
              key={opt.type}
              label={opt.label}
              isActive={filterType === opt.type}
              onClick={() => setFilterType(opt.type)}
            />
          ))}
        </div>
        <Button onClick={() => { setEditingPackage(null); setIsAddModalOpen(true);}} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
          Tambah Paket
        </Button>
      </div>
      
      <Card title={`Daftar Paket ${filterType === 'All' ? '' : filterType}`}>
         <Table columns={columns} data={filteredPackages} rowKey="id"/>
      </Card>
      
      <AddPackageModal 
        isOpen={isAddModalOpen} 
        onClose={() => { setIsAddModalOpen(false); setEditingPackage(null); }}
        onSave={handleSavePackage}
        existingItem={editingPackage}
        systemOptions={systemOptions} 
        addToast={addToast} 
      /> 
    </div>
  );
};

export default PaketTab;