
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { Transaction, Currency, ProjectExpenditureModalProps, SystemOptions } from '../../types';

const ProjectExpenditureModal: React.FC<ProjectExpenditureModalProps> = ({ isOpen, onClose, onSave, projectId, projectName, systemOptions }) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];
  
  const categoryOptionsList = systemOptions?.transactionCategories.filter(cat => !cat.toLowerCase().includes('pemasukan')) || ['Biaya Operasional', 'Fee Freelancer', 'Transportasi', 'Lain-Lain'];

  const initialExpenditureState: Omit<Transaction, 'id' | 'type' | 'linkedClientId' | 'linkedFreelancerId' | 'linkedFreelancerProjectId' | 'linkedProjectId' | 'amount'> & { amount: string } = { 
    date: getTodayDateString(),
    description: '',
    category: categoryOptionsList[0] || '',
    amount: '0', 
    method: systemOptions?.transactionMethods[0] || '',
  };

  const [expenditure, setExpenditure] = useState(initialExpenditureState);

  useEffect(() => {
    if (isOpen) {
      setExpenditure(initialExpenditureState);
    }
  }, [isOpen, initialExpenditureState]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setExpenditure(prev => ({ 
        ...prev, 
        [name]: value 
    }));
  };

  const handleSubmit = () => {
    const amountValue = parseFloat(expenditure.amount);
    if (!expenditure.description || isNaN(amountValue) || amountValue <= 0) {
      alert('Deskripsi dan Jumlah Pengeluaran harus diisi dan valid (lebih besar dari 0).');
      return;
    }
    const expenditureItemToSave = {
        date: expenditure.date,
        description: expenditure.description,
        category: expenditure.category,
        amount: amountValue, 
        method: expenditure.method,
    };
    onSave(expenditureItemToSave as Omit<Transaction, 'id' | 'type' | 'linkedClientId' | 'linkedFreelancerId' | 'linkedFreelancerProjectId'>);
    onClose();
  };

  const categoryOpts = categoryOptionsList.map(c => ({ value: c, label: c }));
  const methodOpts = (systemOptions?.transactionMethods || []).map(m => ({ value: m, label: m }));

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Tambah Pengeluaran untuk Proyek: ${projectName}`}
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>Simpan Pengeluaran</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-6">
        Catat item pengeluaran yang terkait langsung dengan proyek ini.
      </p>
      <div className="space-y-4">
        <Input label="Tanggal Pengeluaran*" name="date" type="date" value={expenditure.date} onChange={handleChange} />
        <Input label="Deskripsi Pengeluaran*" name="description" value={expenditure.description} onChange={handleChange} placeholder="Contoh: Biaya Transportasi Tim" />
        <Input label="Jumlah Pengeluaran*" name="amount" type="number" 
               value={expenditure.amount} 
               onChange={handleChange} placeholder={`${Currency.IDR} 0`} />
        <Select label="Kategori Pengeluaran*" name="category" value={expenditure.category} onChange={handleChange} options={categoryOpts} placeholder="-- Pilih Kategori --"/>
        <Select label="Metode Pembayaran*" name="method" value={expenditure.method} onChange={handleChange} options={methodOpts} placeholder="-- Pilih Metode --"/>
      </div>
    </Modal>
  );
};

export default ProjectExpenditureModal;
