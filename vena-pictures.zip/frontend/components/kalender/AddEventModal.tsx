// frontend/components/kalender/AddEventModal.tsx
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { CalendarEvent, GenericFormModalProps, SystemOptions } from '../../types';
import { CALENDAR_EVENT_TYPE_OPTIONS as constantCalendarEventTypes, CALENDAR_EVENT_COLOR_OPTIONS } from '../../constants';

interface AddEventModalProps extends GenericFormModalProps<CalendarEvent> {
    systemOptions?: SystemOptions;
    // existingItem can be null or a partial CalendarEvent (e.g. just a date for new events)
    existingItem?: Partial<CalendarEvent> | CalendarEvent | null;
}

const AddEventModal: React.FC<AddEventModalProps> = ({ isOpen, onClose, onSave, existingItem, systemOptions, addToast }) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];

  const safeEventTypeOptionsProvider = (systemOptions?.calendarEventTypes || constantCalendarEventTypes) || [];
  const defaultEventType = safeEventTypeOptionsProvider[0]?.value || 'reminder';

  const initialEventState: Omit<CalendarEvent, 'id'> = {
    title: '',
    date: getTodayDateString(),
    startTime: '',
    endTime: '',
    type: defaultEventType,
    description: '',
    color: 'blue',
  };

  const [event, setEvent] = useState<Omit<CalendarEvent, 'id'>>(initialEventState);

  useEffect(() => {
    const currentDefaultEventType = ((systemOptions?.calendarEventTypes || constantCalendarEventTypes) || [])[0]?.value || 'reminder';

    if (isOpen) { 
        if (existingItem && 'id' in existingItem && existingItem.id) { // Check if it's a full existing event for editing
          setEvent({
            title: existingItem.title || '',
            date: existingItem.date ? new Date(existingItem.date).toISOString().split('T')[0] : getTodayDateString(),
            startTime: existingItem.startTime || '',
            endTime: existingItem.endTime || '',
            type: existingItem.type || currentDefaultEventType,
            description: existingItem.description || '',
            color: existingItem.color || 'blue',
            relatedId: existingItem.relatedId || undefined,
          });
        } else { // New event, possibly with a pre-filled date
          setEvent({
            title: '',
            date: existingItem?.date ? new Date(existingItem.date).toISOString().split('T')[0] : getTodayDateString(),
            startTime: '',
            endTime: '',
            type: (existingItem as Partial<CalendarEvent>)?.type || currentDefaultEventType,
            description: '',
            color: (existingItem as Partial<CalendarEvent>)?.color || 'blue',
            relatedId: (existingItem as Partial<CalendarEvent>)?.relatedId || undefined,
          });
        }
    }
  }, [existingItem, isOpen, systemOptions?.calendarEventTypes]); 


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setEvent(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    if (!event.title || !event.date) {
      if (addToast) {
        addToast('Judul Acara dan Tanggal harus diisi.', 'error');
      } else {
        alert('Judul Acara dan Tanggal harus diisi.');
      }
      return;
    }
    
    const eventToSaveWithId: CalendarEvent = {
        id: (existingItem && 'id' in existingItem ? existingItem.id : undefined) || `event-${Date.now().toString()}`,
        ...event,
    };
    
    onSave(eventToSaveWithId);
    onClose();
  };
  
  const typeOptions = safeEventTypeOptionsProvider.map(opt => ({ value: opt.value, label: opt.label}));
  const colorOptions = CALENDAR_EVENT_COLOR_OPTIONS.map(opt => ({ value: opt.value, label: opt.label}));


  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={(existingItem && 'id' in existingItem && existingItem.id) ? "Edit Acara Kalender" : "Tambah Acara Baru ke Kalender"}
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>{(existingItem && 'id' in existingItem && existingItem.id) ? "Simpan Perubahan" : "Simpan Acara"}</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-6">
        {(existingItem && 'id' in existingItem && existingItem.id) ? "Ubah detail acara di bawah ini." : "Masukkan detail acara baru di bawah ini."}
      </p>
      <div className="space-y-4">
        <Input label="Judul Acara*" name="title" value={event.title} onChange={handleChange} placeholder="Contoh: Meeting Klien A" />
        <Input label="Tanggal Acara*" name="date" type="date" value={event.date} onChange={handleChange} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Waktu Mulai (Opsional)" name="startTime" type="time" value={event.startTime || ''} onChange={handleChange} />
            <Input label="Waktu Selesai (Opsional)" name="endTime" type="time" value={event.endTime || ''} onChange={handleChange} />
        </div>
        <Select label="Jenis Acara" name="type" value={event.type} onChange={handleChange} options={typeOptions} />
        <Select label="Warna Label Acara" name="color" value={event.color || 'blue'} onChange={handleChange} options={colorOptions} />
        <TextArea label="Deskripsi (Opsional)" name="description" value={event.description || ''} onChange={handleChange} rows={3} placeholder="Detail tambahan mengenai acara..." />
      </div>
    </Modal>
  );
};

export default AddEventModal;
