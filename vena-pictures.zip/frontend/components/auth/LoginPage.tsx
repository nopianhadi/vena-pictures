
// frontend/components/auth/LoginPage.tsx
import React, { useState } from 'react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { BuildingOfficeIcon } from '../../constants'; 
import { LoginPageProps, UserProfile } from '../../types'; 
import * as API from '../../src/services/api'; 
import { DEFAULT_AVATAR_URL } from '../../constants'; 

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess, addToast }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [formMode, setFormMode] = useState<'login' | 'signup'>('login'); // 'login' or 'signup'

  const handleFormToggle = () => {
    setError('');
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setFullName('');
    setFormMode(prevMode => prevMode === 'login' ? 'signup' : 'login');
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    if (formMode === 'signup') {
      if (password !== confirmPassword) {
        setError('Password dan konfirmasi password tidak cocok.');
        addToast?.('Password dan konfirmasi password tidak cocok.', 'error');
        setIsSubmitting(false);
        return;
      }
      if (password.length < 6) {
        setError('Password minimal harus 6 karakter.');
        addToast?.('Password minimal harus 6 karakter.', 'error');
        setIsSubmitting(false);
        return;
      }
      if (!fullName.trim()) {
        setError('Nama lengkap harus diisi.');
        addToast?.('Nama lengkap harus diisi.', 'error');
        setIsSubmitting(false);
        return;
      }

      try {
        const userCredential = await API.auth.createUserWithEmailAndPassword(email, password);
        const user = userCredential.user;
        if (user) {
          await user.updateProfile({ displayName: fullName });
          const newProfile: UserProfile = {
            id: user.uid,
            email: user.email!,
            fullName: fullName,
            username: user.email!.split('@')[0],
            phone: '',
            avatarUrl: DEFAULT_AVATAR_URL,
            companyName: 'Vena Pictures',
            invoiceTerms: 'Pembayaran jatuh tempo dalam 14 hari.',
            invoiceFooter: 'Terima kasih telah menggunakan layanan kami!',
            // notificationSettings will be set to default by App.tsx after profile creation
          };
          await API.updateUserProfileInFirestore(user.uid, newProfile);
          addToast?.('Akun berhasil dibuat! Silakan login.', 'success');
          setFormMode('login'); // Switch to login form
          setEmail(email); // Keep email for convenience
          setPassword('');
          setConfirmPassword('');
          setFullName('');
        }
      } catch (err: any) {
        let friendlyMessage = 'Gagal membuat akun.';
        if (err.code === 'auth/email-already-in-use') friendlyMessage = 'Email ini sudah terdaftar.';
        else if (err.code === 'auth/weak-password') friendlyMessage = 'Password terlalu lemah.';
        else if (err.code === 'auth/invalid-email') friendlyMessage = 'Format email tidak valid.';
        setError(friendlyMessage);
        addToast?.(friendlyMessage, 'error');
      }
    } else { // Login mode
      try {
        const userCredential = await API.auth.signInWithEmailAndPassword(email, password);
        const user = userCredential.user;
        if (user) {
          // Profile fetching and setting is handled by onAuthStateChanged in App.tsx
          // onLoginSuccess is now just for UI feedback if needed, like a toast from App.tsx
          onLoginSuccess(); // Removed parameters as they are not used/needed from here
        }
      } catch (err: any) {
        let friendlyMessage = 'Login gagal. Periksa kembali email dan password Anda.';
        if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
          friendlyMessage = 'Email atau password salah.';
        } else if (err.code === 'auth/invalid-email') {
          friendlyMessage = 'Format email tidak valid.';
        }
        setError(friendlyMessage);
        addToast?.(friendlyMessage, 'error');
      }
    }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-lg">
        <div className="flex justify-center items-center mb-6">
          <div className="p-3 bg-gray-800 rounded-xl shadow-lg">
            <BuildingOfficeIcon className="h-10 w-10 text-white" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          {formMode === 'login' ? 'Selamat Datang Kembali!' : 'Buat Akun Baru'}
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          {formMode === 'login' 
            ? 'Silakan masuk untuk melanjutkan ke Vena Pictures.' 
            : 'Isi form di bawah untuk mendaftar.'}
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-lg">
        <div className="bg-white py-8 px-6 shadow-xl rounded-xl sm:px-10 border border-gray-200">
          <form className="space-y-6" onSubmit={handleSubmit}>
            {formMode === 'signup' && (
              <Input
                id="fullName"
                name="fullName"
                type="text"
                label="Nama Lengkap"
                autoComplete="name"
                required={formMode === 'signup'}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Masukkan nama lengkap Anda"
              />
            )}
            <Input
              id="email"
              name="email"
              type="email"
              label="Alamat Email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="anda@example.com"
            />
            <Input
              id="password"
              name="password"
              type="password"
              label="Password"
              autoComplete={formMode === 'login' ? "current-password" : "new-password"}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimal 6 karakter"
            />
            {formMode === 'signup' && (
              <Input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                label="Konfirmasi Password"
                autoComplete="new-password"
                required={formMode === 'signup'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Ulangi password Anda"
              />
            )}
            
            {error && (
                <div className="bg-red-100 p-3 rounded-md border border-red-300">
                    <p className="text-sm text-red-700">{error}</p>
                </div>
            )}

            <div>
              <Button type="submit" variant="primary" fullWidth isLoading={isSubmitting} disabled={isSubmitting}>
                {isSubmitting ? 'Memproses...' : (formMode === 'login' ? 'Login Sekarang' : 'Daftar Akun')}
              </Button>
            </div>
          </form>
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">
                  {formMode === 'login' ? "Belum punya akun?" : "Sudah punya akun?"}
                </span>
              </div>
            </div>
            <div className="mt-3">
              <Button variant="outline" fullWidth onClick={handleFormToggle} disabled={isSubmitting}>
                {formMode === 'login' ? 'Buat Akun Baru Sekarang' : 'Login ke Akun Anda'}
              </Button>
            </div>
          </div>
        </div>
      </div>
       <footer className="mt-12 text-center text-xs text-gray-500">
          &copy; {new Date().getFullYear()} Vena Pictures. Hak Cipta Dilindungi.
        </footer>
    </div>
  );
};

export default LoginPage;
