// frontend/components/Sidebar.tsx
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { NAVIGATION_ITEMS, DEFAULT_AVATAR_URL, ArrowLeftOnRectangleIcon, XMarkIcon, BuildingOfficeIcon } from '../frontend/constants'; 
import { NavigationItemKey, NotificationItem, UserProfile, SidebarProps } from '../frontend/types'; 


const Sidebar: React.FC<SidebarProps> = ({ userProfile, notifications = [], onLogout, isMobileOpen, onCloseMobileSidebar }) => {
  const location = useLocation();
  const currentPath = location.pathname;

  const unreadNotificationsCount = notifications.filter(n => !n.isRead).length;

  const sidebarBaseClasses = "w-64 bg-white text-gray-700 flex flex-col shadow-lg border-r border-gray-200 transition-transform duration-300 ease-in-out md:translate-x-0";
  const mobileSidebarOpenClasses = "translate-x-0";
  const mobileSidebarClosedClasses = "-translate-x-full";

  const getAvatarDisplayUrl = () => {
    if (userProfile.avatarUrl && userProfile.avatarUrl.startsWith('data:image')) return userProfile.avatarUrl;
    if (userProfile.avatarUrl && (userProfile.avatarUrl.startsWith('http://') || userProfile.avatarUrl.startsWith('https://'))) return userProfile.avatarUrl;
    if (userProfile.fullName && userProfile.fullName.trim() !== '' && userProfile.fullName !== 'Pengguna Baru') {
      return `https://ui-avatars.com/api/?name=${encodeURIComponent(userProfile.fullName)}&background=4F46E5&color=fff&size=100&bold=true`;
    }
    return DEFAULT_AVATAR_URL; 
  };


  return (
    <aside 
      className={`
        ${sidebarBaseClasses} 
        fixed inset-y-0 left-0 z-40 md:static md:flex-shrink-0 
        ${isMobileOpen ? mobileSidebarOpenClasses : mobileSidebarClosedClasses}
      `}
      aria-label="Sidebar"
    >
      {/* Mobile Close Button */}
      <button
        type="button"
        className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 md:hidden p-1 rounded-md hover:bg-gray-100"
        onClick={onCloseMobileSidebar}
        aria-label="Close sidebar"
      >
        <XMarkIcon className="h-6 w-6" />
      </button>

      <div className="p-5 border-b border-gray-200 flex items-center space-x-3">
        <div className="p-2 bg-gray-800 rounded-lg"> 
          <BuildingOfficeIcon className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-bold text-gray-800">{userProfile.companyName || 'Vena Pictures'}</h1> 
          <p className="text-xs text-gray-500">Wedding Photography</p>
        </div>
      </div>
      <nav className="flex-1 py-4 space-y-1.5 overflow-y-auto">
        {NAVIGATION_ITEMS.map((item) => {
          const isActive = item.key === NavigationItemKey.Pengaturan
            ? currentPath.startsWith(item.path)
            : currentPath === item.path || (currentPath === '/' && item.key === NavigationItemKey.Dashboard);

          return (
            <Link
              key={item.key}
              to={item.path}
              className={`flex items-center mx-3 rounded-lg py-3 px-3.5 transition-all duration-200 ease-in-out group relative ${
                isActive
                  ? 'bg-gray-100 text-gray-900 font-semibold shadow-sm' 
                  : 'text-gray-600 hover:bg-gray-100 hover:text-gray-800' 
              }`}
              onClick={isMobileOpen ? onCloseMobileSidebar : undefined}
            >
              {isActive && <span className="absolute left-0 top-0 bottom-0 w-1 bg-gray-700 rounded-r-md"></span>} 
              <item.icon className={`w-5 h-5 mr-3 transition-colors duration-200 ${isActive ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600'}`} /> 
              <span className="text-sm flex-1">{item.label}</span>
              {item.key === NavigationItemKey.Notifikasi && unreadNotificationsCount > 0 && (
                <span className="ml-auto bg-gray-700 text-white text-xs font-semibold px-1.5 py-0.5 rounded-full"> 
                  {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
                </span>
              )}
            </Link>
          );
        })}
      </nav>
      <div className="p-3 border-t border-gray-200">
        <div className="flex items-center p-2.5 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors cursor-pointer mb-2"> 
          <img 
            src={getAvatarDisplayUrl()} 
            alt={userProfile.fullName} 
            className="w-9 h-9 rounded-full mr-2.5 border-2 border-gray-300 object-cover" 
          /> 
          <div>
            <p className="text-sm font-medium text-gray-800 truncate" title={userProfile.fullName}>{userProfile.fullName}</p>
            <p className="text-xs text-gray-500 truncate" title={userProfile.email}>{userProfile.email}</p>
          </div>
        </div>
        {onLogout && (
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center px-3 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors duration-150 ease-in-out group" 
            aria-label="Logout"
          >
            <ArrowLeftOnRectangleIcon className="w-5 h-5 mr-2 text-gray-500 group-hover:text-gray-600" /> 
            Logout
          </button>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
