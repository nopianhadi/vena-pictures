// frontend/components/keuangan/AddKantongModal.tsx
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { Kantong, Currency, KantongType, SystemOptions, ToastMessage, AddKantongModalProps as ModalProps } from '../../types'; // Renamed import to avoid conflict

// Define a specific state type for the form where numeric-like fields are strings or undefined
type KantongFormState = Omit<Kantong, 'id' | 'balance' | 'targetAmount' | 'interestRate'> & {
  balance: string; // Keep as string for input
  targetAmount?: string; // Keep as string or undefined for input
  interestRate?: string; // Keep as string or undefined for input
  // lockEndDate remains string | undefined from Kantong type
};


const AddKantongModal: React.FC<ModalProps> = ({ isOpen, onClose, onSave, existingKantong, systemOptions, addToast }) => {

  const kantongTypeOptions = systemOptions?.kantongTypes || [
    { value: 'Umum', label: 'Umum' },
    { value: 'Bayar', label: 'Bayar' },
    { value: 'Nabung', label: 'Nabung' },
    { value: 'Terkunci', label: 'Terkunci' },
    { value: 'Bersama', label: 'Bersama' },
  ];

  const initialKantongFormState: KantongFormState = {
    name: '',
    balance: '0', // Initial balance as string
    description: '',
    type: kantongTypeOptions[0].value as KantongType,
    targetAmount: undefined,
    interestRate: undefined,
    lockEndDate: undefined,
  };

  const [kantongForm, setKantongForm] = useState<KantongFormState>(initialKantongFormState);

  useEffect(() => {
    if (isOpen) {
        if (existingKantong) {
          setKantongForm({
            name: existingKantong.name,
            balance: (existingKantong.balance || 0).toString(), // Ensure string
            description: existingKantong.description || '',
            type: existingKantong.type,
            targetAmount: existingKantong.targetAmount?.toString() ?? undefined, // Ensure string or undefined
            interestRate: existingKantong.interestRate?.toString() ?? undefined, // Ensure string or undefined
            lockEndDate: existingKantong.lockEndDate,
          });
        } else {
          setKantongForm(initialKantongFormState);
        }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [existingKantong, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    let valueToSet: string | undefined = value;

    if ((name === 'targetAmount' || name === 'interestRate' || name === 'lockEndDate') && value === '') {
        valueToSet = undefined;
    }
    
    setKantongForm(prev => ({
        ...prev,
        [name]: valueToSet 
    }));

    if (name === 'type') {
      const newType = value as KantongType;
      setKantongForm(prev => ({
        ...prev,
        type: newType,
        targetAmount: newType === 'Nabung' ? (prev.targetAmount ?? undefined) : undefined,
        interestRate: (newType === 'Nabung' || newType === 'Terkunci') ? (prev.interestRate ?? undefined) : undefined,
        lockEndDate: newType === 'Terkunci' ? (prev.lockEndDate ?? undefined) : undefined,
      }));
    }
  };

  const parseOptionalFloat = (value: string | undefined): number | undefined => {
    if (value === undefined || value === null || value.trim() === '') {
      return undefined;
    }
    const num = parseFloat(value);
    return isNaN(num) ? undefined : num;
  };

  const handleSubmit = () => {
    if (!kantongForm.name.trim()) { 
      addToast?.('Nama Kantong harus diisi.', 'error');
      return;
    }
    
    let balanceValue = 0;
    if (kantongForm.balance.trim() !== '') {
        balanceValue = parseFloat(kantongForm.balance);
        if (isNaN(balanceValue)) {
            addToast?.('Saldo awal harus berupa angka yang valid jika diisi.', 'error');
            return;
        }
    }

    const targetAmountValue = kantongForm.type === 'Nabung' ? parseOptionalFloat(kantongForm.targetAmount) : undefined;
    const interestRateValue = (kantongForm.type === 'Nabung' || kantongForm.type === 'Terkunci') ? parseOptionalFloat(kantongForm.interestRate) : undefined;

    if (kantongForm.type === 'Nabung' && kantongForm.targetAmount && kantongForm.targetAmount.trim() !== '' && targetAmountValue === undefined) {
      addToast?.('Target Tabungan harus berupa angka yang valid jika diisi.', 'error');
      return;
    }
    if ((kantongForm.type === 'Nabung' || kantongForm.type === 'Terkunci') && kantongForm.interestRate && kantongForm.interestRate.trim() !== '' && interestRateValue === undefined) {
      addToast?.('Estimasi Bunga harus berupa angka yang valid jika diisi.', 'error');
      return;
    }

    const finalKantongData: Omit<Kantong, 'id'> = { // Omit ID for adding
      name: kantongForm.name.trim(),
      balance: balanceValue,
      type: kantongForm.type,
      description: kantongForm.description?.trim() || undefined,
      targetAmount: targetAmountValue,
      interestRate: interestRateValue,
      lockEndDate: kantongForm.type === 'Terkunci' ? (kantongForm.lockEndDate || undefined) : undefined,
    };
    
    if (existingKantong) {
        onSave({ ...finalKantongData, id: existingKantong.id } as Kantong);
    } else {
        onSave(finalKantongData as Omit<Kantong, 'id'>); // Type for adding
    }
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={existingKantong ? "Edit Kantong Custom" : "Tambah Kantong Custom Baru"}
      size="lg" 
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>{existingKantong ? "Simpan Perubahan" : "Simpan Kantong"}</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-6">
        {existingKantong ? "Ubah detail kantong di bawah ini." : "Masukkan detail kantong baru di bawah ini."}
      </p>
      <div className="space-y-4">
        <Input label="Nama Kantong*" name="name" value={kantongForm.name} onChange={handleChange} placeholder="Contoh: Dana Darurat, Belanja Bulanan" />
        <Input
            label="Saldo Awal (Opsional)"
            name="balance"
            type="number"
            value={kantongForm.balance}
            onChange={handleChange}
            placeholder={`${Currency.IDR} 0`}
            disabled={!!existingKantong} 
            className={existingKantong ? "bg-gray-100" : ""}
        />
        <Select
            label="Jenis Kantong*"
            name="type"
            value={kantongForm.type}
            onChange={handleChange}
            options={kantongTypeOptions}
        />

        {kantongForm.type === 'Nabung' && (
          <>
            <Input
              label="Target Tabungan (Opsional)"
              name="targetAmount"
              type="number"
              value={kantongForm.targetAmount || ''}
              onChange={handleChange}
              placeholder={`${Currency.IDR} 0`}
            />
            <Input
              label="Estimasi Bunga (% p.a.) (Info)"
              name="interestRate"
              type="number"
              step="0.01"
              value={kantongForm.interestRate || ''}
              onChange={handleChange}
              placeholder="cth: 3.75"
            />
          </>
        )}

        {kantongForm.type === 'Terkunci' && (
          <>
            <Input
              label="Tanggal Selesai Kunci (Opsional)"
              name="lockEndDate"
              type="date"
              value={kantongForm.lockEndDate || ''}
              onChange={handleChange}
            />
            <Input
              label="Estimasi Bunga (% p.a.) (Info)"
              name="interestRate"
              type="number"
              step="0.01"
              value={kantongForm.interestRate || ''}
              onChange={handleChange}
              placeholder="cth: 5.00"
            />
          </>
        )}

        {kantongForm.type === 'Bersama' && (
            <TextArea
                label="Dibagikan Dengan (Info)"
                name="sharedWith"
                value={(kantongForm as any).sharedWith || ''} // Temporary cast if not in current state structure
                onChange={handleChange}
                rows={2}
                placeholder="Nama pengguna atau grup (fitur lanjutan)"
                disabled
                className="bg-gray-100"
            />
        )}

        <TextArea label="Deskripsi (Opsional)" name="description" value={kantongForm.description || ''} onChange={handleChange} rows={3} placeholder="Tujuan atau detail kantong..." />
      </div>
    </Modal>
  );
};

export default AddKantongModal;
