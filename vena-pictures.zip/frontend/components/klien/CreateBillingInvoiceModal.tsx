
import React, { useState, useEffect, useMemo } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { Client, Package, AddOn, Currency, Project, UserProfile, Invoice, InvoiceItem, InvoiceStatus, CreateBillingInvoiceModalProps } from '../../types';
import { PlusCircleIcon, TrashIcon } from '../../constants';

interface CustomItemState {
  id?: string;
  description: string;
  quantity: string; 
  unitPrice: string; 
}

const CreateBillingInvoiceModal: React.FC<CreateBillingInvoiceModalProps> = ({
  isOpen,
  onClose,
  onSave,
  client,
  allPackages,
  allAddOns,
  allClientProjects,
  userProfile,
  generateInvoiceNumber,
  addToast,
}) => {
  const getTodayDate = () => new Date().toISOString().split('T')[0];

  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [currentAddOns, setCurrentAddOns] = useState<AddOn[]>([]);
  const [customItems, setCustomItems] = useState<CustomItemState[]>([]);
  const [issueDate, setIssueDate] = useState<string>(getTodayDate());
  const [dueDate, setDueDate] = useState<string>(() => {
    const date = new Date();
    date.setDate(date.getDate() + 14); 
    return date.toISOString().split('T')[0];
  });
  const [notes, setNotes] = useState<string>(userProfile.invoiceTerms || '');
  const [paymentInstructions, setPaymentInstructions] = useState<string>(userProfile.invoiceFooter || '');

  useEffect(() => {
    if (isOpen) {
      setSelectedProjectId('');
      setSelectedPackageId('');
      setCurrentAddOns([]);
      setCustomItems([]);
      setIssueDate(getTodayDate());
      const defaultDueDate = new Date();
      defaultDueDate.setDate(defaultDueDate.getDate() + 14);
      setDueDate(defaultDueDate.toISOString().split('T')[0]);
      setNotes(userProfile.invoiceTerms || 'Mohon lakukan pembayaran sebelum tanggal jatuh tempo.');
      setPaymentInstructions(userProfile.invoiceFooter || 'Terima kasih atas kepercayaan Anda.');
    }
  }, [isOpen, userProfile]);

  const invoiceItems = useMemo((): InvoiceItem[] => {
    const items: InvoiceItem[] = [];
    let itemIdCounter = 0;

    if (selectedPackageId) {
      const pkg = allPackages.find(p => p.id === selectedPackageId);
      if (pkg) {
        items.push({
          id: `item-pkg-${itemIdCounter++}`,
          description: pkg.name, 
          quantity: 1,
          unitPrice: pkg.price,
          amount: pkg.price,
        });
      }
    }

    currentAddOns.forEach(addOn => {
      items.push({
        id: `item-addon-${itemIdCounter++}`,
        description: addOn.name,
        quantity: 1,
        unitPrice: addOn.price,
        amount: addOn.price,
      });
    });

    customItems.forEach(customItem => {
      const quantityVal = parseInt(customItem.quantity) || 0;
      const unitPriceVal = parseFloat(customItem.unitPrice) || 0;
      if (customItem.description && quantityVal > 0 && unitPriceVal >= 0) { 
        items.push({
          id: customItem.id || `item-custom-${itemIdCounter++}`,
          description: customItem.description,
          quantity: quantityVal,
          unitPrice: unitPriceVal,
          amount: quantityVal * unitPriceVal,
        });
      }
    });
    return items;
  }, [selectedPackageId, currentAddOns, customItems, allPackages]);

  const subtotal = useMemo(() => invoiceItems.reduce((sum, item) => sum + item.amount, 0), [invoiceItems]);
  const totalAmount = subtotal;

  const handleAddCustomItem = () => {
    setCustomItems([...customItems, { description: '', quantity: '1', unitPrice: '0' }]);
  };

  const handleCustomItemChange = (index: number, field: keyof CustomItemState, value: string) => {
    const updatedItems = [...customItems];
    updatedItems[index] = { ...updatedItems[index], [field]: value };
    setCustomItems(updatedItems);
  };

  const handleRemoveCustomItem = (index: number) => {
    setCustomItems(customItems.filter((_, i) => i !== index));
  };

  const handleAddOnChange = (addOnId: string) => {
    const addOnToAdd = allAddOns.find(a => a.id === addOnId);
    if (!addOnToAdd) return;
    setCurrentAddOns(prev => {
      if (prev.find(a => a.id === addOnId)) {
        return prev.filter(a => a.id !== addOnId);
      }
      return [...prev, addOnToAdd];
    });
  };

  const handleSubmit = () => {
    const finalInvoiceItems = invoiceItems.filter(item => item.quantity > 0 && item.unitPrice >= 0 && item.description.trim() !== '');
    
    if (finalInvoiceItems.length === 0) {
      addToast('Invoice harus memiliki minimal satu item tagihan yang valid (deskripsi, kuantitas > 0, harga satuan >= 0).', 'error');
      return;
    }

    const newInvoice: Invoice = {
      id: `inv-bill-${Date.now()}`,
      invoiceNumber: generateInvoiceNumber(client.id, new Date(issueDate)),
      clientId: client.id,
      projectId: selectedProjectId || undefined,
      issueDate,
      dueDate,
      items: finalInvoiceItems, 
      subtotal: finalInvoiceItems.reduce((sum, item) => sum + item.amount, 0),
      totalAmount: finalInvoiceItems.reduce((sum, item) => sum + item.amount, 0),
      amountPaid: 0, 
      balanceDue: finalInvoiceItems.reduce((sum, item) => sum + item.amount, 0),
      status: InvoiceStatus.Sent, 
      notes,
      paymentInstructions,
      paymentHistory: [],
    };

    onSave(newInvoice, client.id, selectedProjectId || undefined);
    onClose();
  };
  
  const projectOptions = [{ value: '', label: 'Tidak terkait proyek spesifik' }, ...allClientProjects.map(p => ({ value: p.id, label: p.name }))];
  const packageOptionsForSelect = [{ value: '', label: '-- Pilih Paket (Opsional) --' }, ...allPackages.map(p => ({ value: p.id, label: `${p.name} (${Currency.IDR} ${p.price.toLocaleString('id-ID')})`}))];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Buat Invoice Penagihan untuk ${client.name}`}
      size="3xl"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>Buat dan Kirim Invoice</Button>
        </>
      }
    >
      <div className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Input label="Tanggal Terbit Invoice" type="date" value={issueDate} onChange={e => setIssueDate(e.target.value)} />
          <Input label="Tanggal Jatuh Tempo" type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
          <Select label="Proyek Terkait (Opsional)" options={projectOptions} value={selectedProjectId} onChange={e => setSelectedProjectId(e.target.value)} />
        </div>

        <div className="pt-2">
          <h4 className="text-sm font-medium text-gray-700 mb-1">Item Tagihan:</h4>
          <Select label="Pilih Paket (Opsional)" options={packageOptionsForSelect} value={selectedPackageId} onChange={e => setSelectedPackageId(e.target.value)} wrapperClassName="mb-3" />

          <div className="mb-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Pilih Add-on (Opsional)</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-32 overflow-y-auto p-2 border rounded-md bg-white">
              {allAddOns.map(addOn => (
                <label key={addOn.id} className="flex items-center space-x-2 text-xs p-1.5 hover:bg-gray-100 rounded cursor-pointer">
                  <input type="checkbox" checked={currentAddOns.some(sa => sa.id === addOn.id)} onChange={() => handleAddOnChange(addOn.id)} className="form-checkbox h-3.5 w-3.5 text-indigo-600 transition duration-150 ease-in-out rounded focus:ring-indigo-500"/>
                  <span>{addOn.name} ({Currency.IDR} {addOn.price.toLocaleString('id-ID')})</span>
                </label>
              ))}
            </div>
          </div>
          
          <div className="space-y-2">
            <h5 className="text-xs font-semibold text-gray-600">Item Kustom (Opsional):</h5>
            {customItems.map((item, index) => (
              <div key={item.id || index} className="flex items-end gap-2 p-2 border rounded bg-gray-50 relative">
                <Input label={`Deskripsi Item ${index + 1}`} value={item.description} onChange={e => handleCustomItemChange(index, 'description', e.target.value)} wrapperClassName="flex-grow" />
                <Input label="Qty" type="number" value={item.quantity} onChange={e => handleCustomItemChange(index, 'quantity', e.target.value)} wrapperClassName="w-20" min="0"/>
                <Input label="Harga Satuan" type="number" value={item.unitPrice} onChange={e => handleCustomItemChange(index, 'unitPrice', e.target.value)} wrapperClassName="w-32" min="0"/>
                <Button variant="ghost" size="sm" onClick={() => handleRemoveCustomItem(index)} className="absolute top-1 right-1 p-0.5" title="Hapus Item Kustom">
                  <TrashIcon className="w-3.5 h-3.5 text-red-500"/>
                </Button>
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={handleAddCustomItem} leftIcon={<PlusCircleIcon className="w-4 h-4"/>}>Tambah Item Kustom</Button>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t">
            <div className="text-right mb-2 space-y-1">
                <p className="text-sm text-gray-600">Subtotal: <span className="font-semibold">{Currency.IDR} {subtotal.toLocaleString('id-ID')}</span></p>
                <p className="text-lg font-bold text-indigo-700">Total Tagihan: {Currency.IDR} {totalAmount.toLocaleString('id-ID')}</p>
            </div>
          <TextArea label="Catatan untuk Klien (pada Invoice)" value={notes} onChange={e => setNotes(e.target.value)} rows={3} placeholder="Misalnya: Mohon lakukan pembayaran tepat waktu."/>
          <TextArea label="Instruksi Pembayaran Tambahan (Opsional)" value={paymentInstructions} onChange={e => setPaymentInstructions(e.target.value)} rows={2} placeholder="Informasi rekening tambahan atau detail lain." wrapperClassName="mt-2"/>
        </div>
      </div>
    </Modal>
  );
};

export default CreateBillingInvoiceModal;
