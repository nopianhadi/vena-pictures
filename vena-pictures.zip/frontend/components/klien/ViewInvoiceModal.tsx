// frontend/components/klien/ViewInvoiceModal.tsx
import React, { useMemo } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import { Invoice, Client, Currency, UserProfile, BankDetail, InvoiceStatus, Project, Package, InvoiceItem } from '../../types'; // Added Package and InvoiceItem
import { ShareIcon, ArrowDownTrayIcon, CheckCircleIcon } from '../../constants';
import Badge from '../ui/Badge';


interface ViewInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  client: Client | null;
  userProfile: UserProfile;
  bankDetails: BankDetail[];
  allProjects: Project[];
  allPackages: Package[]; // Added allPackages
}

const ViewInvoiceModal: React.FC<ViewInvoiceModalProps> = ({
    isOpen, onClose, invoice, client, userProfile, bankDetails, allProjects, allPackages
}) => {
  if (!isOpen || !invoice || !client) return null;

  const getInvoiceStatusColor = (status: InvoiceStatus): 'green' | 'blue' | 'yellow' | 'red' | 'gray' | 'purple' => {
        switch(status) {
            case InvoiceStatus.Paid: return 'green';
            case InvoiceStatus.Partial: return 'blue';
            case InvoiceStatus.Sent: return 'blue'; 
            case InvoiceStatus.Overdue: return 'red';
            case InvoiceStatus.Draft: return 'gray';
            case InvoiceStatus.Cancelled: return 'purple';
            default: return 'gray';
        }
    };

  const handlePrint = () => {
    const printableArea = document.querySelector('.printable-invoice-content');
    if (printableArea) {
        const printWindow = window.open('', '_blank', 'height=800,width=800');
        if (printWindow) {
            printWindow.document.write('<html><head><title>Invoice Vena Pictures</title>'); // Updated title
            printWindow.document.write('<script src="https://cdn.tailwindcss.com"><\/script>');
            printWindow.document.write('<style> @page { size: A4; margin: 20mm; } body { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; -webkit-print-color-adjust: exact; } .non-printable-modal-action { display: none !important; } <\/style>');
            printWindow.document.write('</head><body onload="window.print(); setTimeout(window.close, 0);">');
            printWindow.document.write(printableArea.outerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
        } else {
            alert('Gagal membuka window print. Pastikan pop-up diizinkan.');
        }
    } else {
        alert('Area invoice tidak ditemukan untuk dicetak.');
    }
  };

  const modalTitle = (
    <div className="flex items-center justify-between w-full">
        <span className="truncate">Detail Invoice: {invoice.invoiceNumber}</span>
        <Badge text={invoice.status} color={getInvoiceStatusColor(invoice.status)} />
    </div>
  );

  const packagesInInvoice = useMemo(() => {
    if (!allPackages) return []; // Safety check
    return invoice.items
        .map(item => {
            const pkg = allPackages.find(p => p.name === item.description && item.quantity === 1); // Assume package is qty 1
            return pkg ? { ...pkg, originalItem: item } : null;
        })
        .filter((pkg): pkg is Package & { originalItem: InvoiceItem } => Boolean(pkg));
  }, [invoice.items, allPackages]);


  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={modalTitle}
      size="4xl"
      footer={
        <div className="flex justify-between w-full items-center non-printable-modal-action">
            <div className="flex space-x-2">
                <Button
                    variant="secondary"
                    size="sm"
                    leftIcon={<ShareIcon className="w-4 h-4"/>}
                    onClick={() => alert('Fitur Bagikan Invoice (simulasi).')}
                >Bagikan</Button>
                <Button
                    variant="secondary"
                    size="sm"
                    leftIcon={<ArrowDownTrayIcon className="w-4 h-4"/>}
                    onClick={handlePrint}
                >
                    Cetak/Unduh Invoice (PDF)
                </Button>
            </div>
            <Button variant="primary" onClick={onClose}>Tutup</Button>
        </div>
      }
    >
    <div className="p-3 sm:p-5 border border-gray-200 rounded-lg bg-white text-sm font-sans printable-invoice-content max-h-[70vh] overflow-y-auto">
        {/* Invoice Header */}
        <div className="flex justify-between items-start pb-4 mb-4 border-b border-gray-300">
            <div>
                {userProfile.invoiceLogoUrl && <img src={userProfile.invoiceLogoUrl} alt="Logo Perusahaan" className="h-12 mb-2 object-contain" />}
                <h2 className="text-3xl font-bold text-indigo-700 tracking-tight">INVOICE</h2>
                <p className="text-gray-600 font-semibold">#{invoice.invoiceNumber}</p>
                <p className="text-xs text-gray-500 mt-0.5">Tanggal Terbit: {new Date(invoice.issueDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
                {invoice.dueDate && <p className="text-xs text-gray-500">Jatuh Tempo: {new Date(invoice.dueDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}</p>}
            </div>
            <div className="text-right">
                <h3 className="text-lg font-semibold text-gray-800">{userProfile.companyName || 'Nama Perusahaan Anda'}</h3>
                <p className="text-xs text-gray-500">{userProfile.companyAddress || 'Alamat Perusahaan'}</p>
                <p className="text-xs text-gray-500">{userProfile.companyEmail || 'Email Perusahaan'} | {userProfile.companyPhone || 'Telepon Perusahaan'}</p>
            </div>
        </div>

        {/* Client Info */}
        <div className="mb-6">
            <h4 className="text-xs font-semibold uppercase text-gray-500 mb-1 tracking-wider">Ditagihkan Kepada:</h4>
            <p className="font-medium text-gray-800 text-base">{client.name}</p>
            <p className="text-gray-600">{client.email}</p>
            <p className="text-gray-600">{client.phone}</p>
            <p className="text-gray-600">{client.address || (invoice.projectId ? allProjects.find(p=>p.id===invoice.projectId)?.location : 'Alamat acara akan dikonfirmasi') || 'Alamat belum ditentukan'}</p>
        </div>

        {/* Invoice Items Table */}
        <div className="overflow-x-auto">
            <table className="w-full mb-6 border-collapse text-left">
                <thead className="bg-gray-100 text-gray-600">
                    <tr>
                        <th className="p-2 font-semibold text-xs uppercase tracking-wider w-2/5">Deskripsi</th>
                        <th className="p-2 font-semibold text-xs uppercase tracking-wider text-center w-1/5">Kuantitas</th>
                        <th className="p-2 font-semibold text-xs uppercase tracking-wider text-right w-1/5">Harga Satuan</th>
                        <th className="p-2 font-semibold text-xs uppercase tracking-wider text-right w-1/5">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    {invoice.items.map(item => {
                       const matchedPackageForSubList = allPackages?.find(pkg => pkg.name === item.description && item.quantity === 1);
                       return (
                        <tr key={item.id} className="border-b border-gray-200">
                            <td className="p-2 align-top text-gray-800">
                                {item.description}
                                {matchedPackageForSubList && matchedPackageForSubList.services && matchedPackageForSubList.services.length > 0 && (
                                    <ul className="list-disc list-inside text-xs text-gray-500 mt-1 pl-2">
                                        {matchedPackageForSubList.services.map((service, idx) => (
                                            <li key={`${item.id}-service-${idx}`}>{service}</li>
                                        ))}
                                    </ul>
                                )}
                            </td>
                            <td className="p-2 align-top text-center text-gray-700">{item.quantity}</td>
                            <td className="p-2 align-top text-right text-gray-700">{Currency.IDR} {item.unitPrice.toLocaleString('id-ID')}</td>
                            <td className="p-2 align-top text-right font-medium text-gray-800">{Currency.IDR} {item.amount.toLocaleString('id-ID')}</td>
                        </tr>
                       );
                    })}
                </tbody>
            </table>
        </div>

        {/* Package Details Section (If any package item was identified separately) */}
        {packagesInInvoice.length > 0 && (
            <div className="mb-6 p-4 bg-slate-50 rounded-md border border-slate-200">
                <h4 className="text-sm font-semibold uppercase text-gray-600 mb-2 tracking-wider">Rincian Paket & Layanan (Jika Teridentifikasi)</h4>
                {packagesInInvoice.map(pkgDetails => (
                    <div key={pkgDetails.id} className="mb-3 pb-2 last:mb-0 last:pb-0 border-b border-slate-200 last:border-b-0">
                        <p className="font-medium text-gray-800">{pkgDetails.name}</p>
                        {pkgDetails.duration && <p className="text-xs text-gray-500">Durasi: {pkgDetails.duration}</p>}
                        <p className="text-xs text-gray-500 mt-0.5 mb-1">Layanan Termasuk:</p>
                        <ul className="list-disc list-inside text-xs text-gray-600 pl-3 space-y-0.5">
                            {pkgDetails.services.map((service, idx) => (
                                <li key={`${pkgDetails.id}-detailservice-${idx}`}>{service}</li>
                            ))}
                        </ul>
                    </div>
                ))}
            </div>
        )}

        {/* Invoice Totals */}
        <div className="flex justify-end mb-6">
            <div className="w-full sm:w-2/5 space-y-1.5 text-sm">
                <div className="flex justify-between text-gray-700">
                    <span>Subtotal</span>
                    <span className="font-medium">{Currency.IDR} {invoice.subtotal.toLocaleString('id-ID')}</span>
                </div>
                {invoice.taxAmount != null && invoice.taxRate != null && (
                    <div className="flex justify-between text-gray-700">
                        <span>Pajak ({invoice.taxRate * 100}%)</span>
                        <span className="font-medium">{Currency.IDR} {invoice.taxAmount.toLocaleString('id-ID')}</span>
                    </div>
                )}
                <div className="flex justify-between font-bold text-lg text-indigo-700 border-t border-gray-300 pt-1.5 mt-1.5">
                    <span>Total Tagihan</span>
                    <span>{Currency.IDR} {invoice.totalAmount.toLocaleString('id-ID')}</span>
                </div>
                 <div className="flex justify-between text-green-600">
                    <span>Total Dibayar</span>
                    <span className="font-medium">- {Currency.IDR} {invoice.amountPaid.toLocaleString('id-ID')}</span>
                </div>
                <div className={`flex justify-between font-bold text-lg ${invoice.balanceDue > 0 ? 'text-red-600' : 'text-green-700'}`}>
                    <span>Sisa Tagihan</span>
                    <span>{Currency.IDR} {invoice.balanceDue.toLocaleString('id-ID')}</span>
                </div>
            </div>
        </div>

        {/* Payment History for this Invoice */}
        {invoice.paymentHistory && invoice.paymentHistory.length > 0 && (
            <div className="mb-6 p-3 bg-gray-50 rounded-md border">
                <h4 className="text-xs font-semibold uppercase text-gray-500 mb-2 tracking-wider">Riwayat Pembayaran Invoice Ini:</h4>
                <ul className="space-y-1 text-gray-700 text-xs">
                    {invoice.paymentHistory.map(payment => (
                        <li key={payment.id} className="flex justify-between p-1 bg-white rounded border border-gray-200">
                            <span>{new Date(payment.date).toLocaleDateString('id-ID')} - {payment.method || 'N/A'} ({payment.notes || 'Pembayaran'})</span>
                            <span className="font-medium">{Currency.IDR} {payment.amount.toLocaleString('id-ID')}</span>
                        </li>
                    ))}
                </ul>
            </div>
        )}

        {/* Payment Instructions & Notes */}
        <div className="border-t border-gray-300 pt-4 mt-6">
            <h4 className="text-xs font-semibold uppercase text-gray-500 mb-1 tracking-wider">Catatan & Pembayaran:</h4>
            {invoice.paymentInstructions && <p className="text-gray-600 text-xs whitespace-pre-wrap mb-2">{invoice.paymentInstructions}</p>}
            {invoice.notes && <p className="text-gray-600 text-xs whitespace-pre-wrap mb-2"><strong>Catatan Tambahan:</strong> {invoice.notes}</p>}

            {bankDetails && bankDetails.length > 0 && (
                 <div className="mt-1 text-xs text-gray-600 bg-gray-100 p-2 rounded-md inline-block">
                    <p>Pembayaran dapat dilakukan ke rekening berikut:</p>
                    <p><strong>{bankDetails[0].bankName}</strong></p>
                    <p>No. Rekening: <strong>{bankDetails[0].accountNumber}</strong></p>
                    <p>Atas Nama: <strong>{bankDetails[0].accountHolder}</strong></p>
                </div>
            )}
            <p className="text-gray-600 text-xs mt-2">Mohon sertakan nomor invoice (<strong>{invoice.invoiceNumber}</strong>) dalam keterangan transfer Anda.</p>
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-gray-400 mt-8 pt-4 border-t border-gray-300">
            {userProfile.invoiceFooter || `Terima kasih atas kepercayaan Anda kepada ${userProfile.companyName || 'Perusahaan Anda'}.`}
        </div>
    </div>
    </Modal>
  );
};

export default ViewInvoiceModal;
