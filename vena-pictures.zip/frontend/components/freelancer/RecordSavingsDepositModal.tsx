
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea } from '../ui/Input';
import { Freelancer, Currency, RecordSavingsDepositModalProps } from '../../types';

const RecordSavingsDepositModal: React.FC<RecordSavingsDepositModalProps> = ({ isOpen, onClose, onSave, freelancer, addToast }) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];
  
  const [amount, setAmount] = useState<string>('0'); 
  const [date, setDate] = useState<string>(getTodayDateString());
  const [notes, setNotes] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      setAmount('0');
      setDate(getTodayDateString());
      setNotes('');
    }
  }, [isOpen]);

  if (!freelancer) return null;

  const handleSubmit = () => {
    const amountValue = parseFloat(amount);
    if (isNaN(amountValue) || amountValue <= 0) {
      addToast?.('Jumlah setoran tabungan harus lebih besar dari 0.', 'error');
      return;
    }
    onSave(freelancer.id, amountValue, date, notes);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Catat Setoran Tabungan: ${freelancer.name}`}
      size="md"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>Simpan Setoran</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-1">
        Anggota Tim: <span className="font-semibold">{freelancer.name}</span>
      </p>
      <p className="text-sm text-gray-500 mb-4">
        Total Tabungan Saat Ini: <span className="font-semibold">{Currency.IDR} {(freelancer.savings || 0).toLocaleString('id-ID')}</span>
      </p>
      <div className="space-y-4">
        <Input
          label="Jumlah Setoran*"
          name="amount"
          type="number"
          value={amount} 
          onChange={(e) => setAmount(e.target.value)}
          placeholder={`${Currency.IDR} 0`}
        />
        <Input
          label="Tanggal Setoran*"
          name="date"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <TextArea
          label="Catatan (Opsional)"
          name="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          placeholder="Contoh: Setoran tabungan rutin, bonus kinerja."
        />
      </div>
    </Modal>
  );
};

export default RecordSavingsDepositModal;
