import React, { useState, useMemo } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import { Freelancer, FreelancerProject, Transaction, Currency, FreelancerEarningsModalProps, AppModalState } from '../../types';
import Table, { TableColumn } from '../ui/Table';
import Input, { Select } from '../ui/Input';
import { CreditCardIcon, WalletIcon, BriefcaseIcon, CalendarDaysIcon, BanknotesIcon, PlusCircleIcon as AddSavingsIcon, EyeIcon, UserGroupIcon } from '../../constants';

const InfoCard: React.FC<{title: string; value: string; icon: React.ReactNode; valueClassName?: string; subtext?: string}> =
    ({title, value, icon, valueClassName, subtext}) => (
    <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex-1 min-w-[150px]">
        <div className="flex items-center text-slate-500 text-xs mb-0.5">
            {React.cloneElement(icon as React.ReactElement<React.SVGProps<SVGSVGElement>>, {className: "w-3.5 h-3.5 mr-1.5"})}
            {title}
        </div>
        <p className={`text-xl font-semibold ${valueClassName || 'text-slate-800'}`}>{value}</p>
        {subtext && <p className="text-xs text-slate-500">{subtext}</p>}
    </div>
);

interface MonthlyEarningDetail {
    projectName: string;
    date: string;
    fee: number;
    type: string; 
    transactionId: string;
}


const FreelancerEarningsModal: React.FC<FreelancerEarningsModalProps> = ({
  isOpen,
  onClose,
  freelancer,
  freelancerProjects,
  transactions,
  setAppModals,
  openFreelancerPaymentVoucherModal,
}) => {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1; // 1-12

  const [selectedYear, setSelectedYear] = useState<number>(currentYear);
  const [selectedMonth, setSelectedMonth] = useState<number>(currentMonth);

  const yearOptions = Array.from({ length: 5 }, (_, i) => ({ value: (currentYear - i).toString(), label: (currentYear - i).toString() }));
  const monthOptions = Array.from({ length: 12 }, (_, i) => ({ value: (i + 1).toString(), label: new Date(0, i).toLocaleString('id-ID', { month: 'long' }) }));

  const monthlyData = useMemo(() => {
    if (!freelancer) return { earnings: 0, projectsInvolvedCount: 0, projectDetails: [] as MonthlyEarningDetail[] };

    let monthEarnings = 0;
    const uniqueProjectsInMonth = new Set<string>();

    const paymentTransactionsInMonth = transactions.filter(t => {
        if (t.linkedFreelancerId !== freelancer.id || t.type !== 'Pengeluaran') return false;
        if (t.category !== 'Fee Proyek') return false; 
        const transactionDate = new Date(t.date);
        return transactionDate.getFullYear() === selectedYear && transactionDate.getMonth() + 1 === selectedMonth;
    });

    paymentTransactionsInMonth.forEach(t => {
        monthEarnings += t.amount;
        if (t.linkedFreelancerProjectId) {
            uniqueProjectsInMonth.add(t.linkedFreelancerProjectId);
        }
    });
    
    const projectDetailsForTable: MonthlyEarningDetail[] = paymentTransactionsInMonth.map(t => {
        const fp = freelancerProjects.find(p => p.id === t.linkedFreelancerProjectId);
        return {
            projectName: fp ? fp.projectName : t.description, 
            date: t.date,
            fee: t.amount,
            type: t.category, 
            transactionId: t.id,
        };
    });

    return {
      earnings: monthEarnings,
      projectsInvolvedCount: uniqueProjectsInMonth.size,
      projectDetails: projectDetailsForTable,
    };
  }, [freelancer, freelancerProjects, transactions, selectedYear, selectedMonth]);

  if (!freelancer) return null;

  const handleOpenPayFeeModal = () => {
    if (!freelancer) return;
    setAppModals(prev => ({
        ...prev,
        payFreelancer: { isOpen: true, freelancerId: freelancer.id, context: 'fee' }
    }));
  };

  const handleOpenSavingsWithdrawalModal = () => {
    if (!freelancer || freelancer.type !== 'Tim Internal') return;
    setAppModals(prev => ({
        ...prev,
        savingsWithdrawal: { isOpen: true, freelancerId: freelancer.id }
    }));
  };

  const handleOpenRecordSavingsDepositModal = () => {
    if (!freelancer || freelancer.type !== 'Tim Internal') return;
    setAppModals(prev => ({
        ...prev,
        recordSavingsDeposit: { isOpen: true, freelancerId: freelancer.id }
    }));
  };

  const handleViewPaymentVoucher = (transactionId: string) => {
    if (openFreelancerPaymentVoucherModal) {
        openFreelancerPaymentVoucherModal(transactionId);
    }
  };

  const columns: TableColumn<MonthlyEarningDetail>[] = [
    { key: 'projectName', header: 'Proyek/Deskripsi Fee'},
    { key: 'date', header: 'Tanggal Bayar', render: (item) => new Date(item.date).toLocaleDateString('id-ID') },
    { key: 'type', header: 'Jenis Pembayaran', render: (item) => <Badge text={item.type} color={'blue'} /> },
    { key: 'fee', header: 'Jumlah (Rp)', render: (item) => item.fee.toLocaleString('id-ID') },
    { 
      key: 'actions', 
      header: 'Aksi', 
      render: (item) => (
        <Button 
            variant="ghost" 
            size="xs" 
            onClick={() => handleViewPaymentVoucher(item.transactionId)}
            title="Lihat Bukti Pembayaran"
        >
            <EyeIcon className="w-4 h-4 text-gray-500 hover:text-indigo-600"/>
        </Button>
      )
    },
  ];
  
  const modalTitle = (
    <div className="flex items-center justify-between w-full">
        <span>Detail Penghasilan & Tabungan - {freelancer.name} <Badge text={freelancer.type} color={freelancer.type === 'Tim Internal' ? 'purple' : 'gray'} size="sm" className="ml-2"/></span>
        <div className="flex space-x-2">
            <Button onClick={handleOpenPayFeeModal} size="sm" variant="primary" leftIcon={<BanknotesIcon className="w-4 h-4"/>}>Bayar Fee Proyek</Button>
            {freelancer.type === 'Tim Internal' && (
            <>
                <Button onClick={handleOpenRecordSavingsDepositModal} size="sm" variant="outline" leftIcon={<AddSavingsIcon className="w-4 h-4"/>}>Catat Setoran Tabungan</Button>
                <Button onClick={handleOpenSavingsWithdrawalModal} size="sm" variant="outline" leftIcon={<WalletIcon className="w-4 h-4"/>}>Catat Penarikan Tabungan</Button>
            </>
            )}
        </div>
    </div>
  );


  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={modalTitle}
      size="3xl"
      footer={<Button onClick={onClose}>Tutup</Button>}
    >
      <div className="space-y-5 p-1 max-h-[70vh] overflow-y-auto">
        <p className="text-sm text-gray-500">Detail penghasilan dan tabungan untuk {freelancer.name} ({freelancer.role}).</p>
        
        <div className="flex flex-wrap gap-4">
            <InfoCard title="Fee Standar (Jika Ada)" value={`${Currency.IDR} ${freelancer.standardFee?.toLocaleString('id-ID') ?? 'N/A'}`} icon={<CreditCardIcon />} />
            <InfoCard title="Total Penghasilan (All-Time)" value={`${Currency.IDR} ${(freelancer.totalEarnings || 0).toLocaleString('id-ID')}`} icon={<UserGroupIcon />} valueClassName="text-green-600"/>
            {freelancer.type === 'Tim Internal' && (
                <InfoCard title="Total Tabungan Tersedia" value={`${Currency.IDR} ${(freelancer.savings || 0).toLocaleString('id-ID')}`} icon={<WalletIcon />} valueClassName="text-blue-600" />
            )}
        </div>

        <div className="pt-4 border-t">
            <h4 className="text-md font-semibold text-gray-700 mb-3">Riwayat Penghasilan Bulanan</h4>
            <div className="flex gap-3 items-end mb-4 p-3 bg-gray-50 rounded-md border">
                <Select
                    label="Bulan"
                    options={monthOptions}
                    value={selectedMonth.toString()}
                    onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                    wrapperClassName="flex-grow"
                />
                <Select
                    label="Tahun"
                    options={yearOptions}
                    value={selectedYear.toString()}
                    onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                    wrapperClassName="flex-grow"
                />
            </div>
            <div className="flex flex-wrap gap-4 mb-4">
                <InfoCard title="Penghasilan Bulan Ini" value={`${Currency.IDR} ${monthlyData.earnings.toLocaleString('id-ID')}`} icon={<CalendarDaysIcon />} subtext={`${monthOptions.find(m=>m.value === selectedMonth.toString())?.label} ${selectedYear}`} />
                <InfoCard title="Proyek Terlibat (Bulan Ini)" value={monthlyData.projectsInvolvedCount.toString()} icon={<BriefcaseIcon />} subtext={`${monthOptions.find(m=>m.value === selectedMonth.toString())?.label} ${selectedYear}`} />
            </div>
             <Table
                columns={columns}
                data={monthlyData.projectDetails}
                rowKey={(item) => `${item.transactionId}`}
                emptyStateMessage={`Tidak ada penghasilan tercatat untuk ${monthOptions.find(m=>m.value === selectedMonth.toString())?.label} ${selectedYear}.`}
             />
        </div>
      </div>
    </Modal>
  );
};

export default FreelancerEarningsModal;