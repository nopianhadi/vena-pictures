// frontend/components/freelancer/AddFreelancerOrTeamModal.tsx
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { Select, TextArea } from '../ui/Input';
import { Freelancer, FreelancerRole, Currency, FreelancerType, SystemOptions, ToastMessage, AddFreelancerOrTeamModalProps } from '../../types';
import { FREELANCER_ROLE_VALUES } from '../../constants';

const AddFreelancerOrTeamModal: React.FC<AddFreelancerOrTeamModalProps> = ({ isOpen, onClose, onSave, existingFreelancer, defaultType, systemOptions, addToast }) => {
  
  const currentFreelancerRoles = systemOptions?.freelancerRoles || FREELANCER_ROLE_VALUES;
  
  type FreelancerFormState = Omit<Freelancer, 'id' | 'projectCount' | 'totalEarnings' | 'savings' | 'standardFee'> & { standardFee?: string };

  const initialFormState = (type: FreelancerType): FreelancerFormState => ({
    name: '',
    role: (currentFreelancerRoles.find(r => r !== 'Tim Internal') || 'Fotografer') as FreelancerRole, 
    standardFee: '0', // Keep as string for input, even if it's mostly for Tim Internal now
    status: 'Aktif', 
    phone: '',
    email: '',
    type: type, 
    skills: [],
    portfolioLink: '',
    availabilityNotes: '',
    contractLink: '',
    contractStartDate: '',
    contractEndDate: '',
    address: '',
    joinDate: '',
    equipment: [],
    equipmentNotes: '',
    bankName: '',
    accountNumber: '',
    accountHolderName: '',
  });
  
  const [freelancer, setFreelancer] = useState(initialFormState(defaultType));

  useEffect(() => {
    if (isOpen) { 
      if (existingFreelancer) {
        setFreelancer({
          name: existingFreelancer.name,
          role: existingFreelancer.role,
          standardFee: (existingFreelancer.standardFee || 0).toString(),
          status: existingFreelancer.status,
          phone: existingFreelancer.phone || '',
          email: existingFreelancer.email || '',
          type: existingFreelancer.type,
          skills: existingFreelancer.skills || [],
          portfolioLink: existingFreelancer.portfolioLink || '',
          availabilityNotes: existingFreelancer.availabilityNotes || '',
          contractLink: existingFreelancer.contractLink || '',
          contractStartDate: existingFreelancer.contractStartDate || '',
          contractEndDate: existingFreelancer.contractEndDate || '',
          address: existingFreelancer.address || '',
          joinDate: existingFreelancer.joinDate ? new Date(existingFreelancer.joinDate).toISOString().split('T')[0] : (existingFreelancer.contractStartDate ? new Date(existingFreelancer.contractStartDate).toISOString().split('T')[0] : ''),
          equipment: existingFreelancer.equipment || [],
          equipmentNotes: existingFreelancer.equipmentNotes || '',
          bankName: existingFreelancer.bankName || '',
          accountNumber: existingFreelancer.accountNumber || '',
          accountHolderName: existingFreelancer.accountHolderName || '',
        });
      } else {
        const determinedDefaultRole = currentFreelancerRoles.includes(initialFormState(defaultType).role as FreelancerRole) 
                                        ? initialFormState(defaultType).role 
                                        : (currentFreelancerRoles.find(r => r !== 'Tim Internal') || 'Fotografer' as FreelancerRole);
        setFreelancer({...initialFormState(defaultType), role: determinedDefaultRole as FreelancerRole});
      }
    }
  }, [existingFreelancer, isOpen, defaultType, currentFreelancerRoles]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFreelancer(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (action: 'saveAndClose' | 'saveAndAddNew' = 'saveAndClose') => {
    if (!freelancer.name || !freelancer.role) {
      addToast?.('Nama dan Role harus diisi.', 'error');
      return;
    }
    const standardFeeValue = parseFloat(freelancer.standardFee || '0');
    if (isNaN(standardFeeValue) || standardFeeValue < 0) {
        addToast?.('Fee Standar/Gaji Bulanan harus berupa angka valid dan tidak negatif.', 'error');
        return;
    }

    const finalFreelancer: Freelancer = {
        id: existingFreelancer?.id || `fl-${Date.now().toString()}`,
        projectCount: existingFreelancer?.projectCount || 0,
        totalEarnings: existingFreelancer?.totalEarnings || 0,
        savings: existingFreelancer?.savings ?? (freelancer.type === 'Tim Internal' ? 0 : undefined),
        ...(freelancer as Omit<Freelancer, 'id' | 'projectCount' | 'totalEarnings' | 'savings' | 'standardFee'>),
        standardFee: standardFeeValue,
        availabilityNotes: freelancer.availabilityNotes || '',
        address: freelancer.address || undefined,
        joinDate: freelancer.joinDate || freelancer.contractStartDate || undefined,
        equipment: freelancer.equipment || undefined,
        equipmentNotes: freelancer.equipmentNotes || undefined,
        bankName: freelancer.bankName || undefined,
        accountNumber: freelancer.accountNumber || undefined,
        accountHolderName: freelancer.accountHolderName || undefined,
    };
    onSave(finalFreelancer, action);
  };
  
  const roleOptions = currentFreelancerRoles
    .filter(role => freelancer.type === 'Tim Internal' ? true : role !== 'Tim Internal') 
    .map(role => ({ value: role, label: role as string}));

  const statusOptions = [
    { value: 'Aktif', label: 'Aktif' },
    { value: 'Nonaktif', label: 'Nonaktif' },
  ];
  
  const typeOptions = [
    { value: 'Tim Internal' as FreelancerType, label: 'Anggota Tim Internal' },
    { value: 'Freelancer Eksternal' as FreelancerType, label: 'Freelancer Eksternal' },
  ];

  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={existingFreelancer ? `Edit Data ${freelancer.type}` : `Tambah ${freelancer.type === 'Tim Internal' ? 'Anggota Tim Baru' : 'Freelancer Baru'}`}
        size="3xl" 
        footer={
            <>
                <Button variant="outline" onClick={onClose}>Batal</Button>
                {existingFreelancer ? (
                    <Button onClick={() => handleSubmit('saveAndClose')}>Simpan Perubahan</Button>
                ) : (
                    <>
                        <Button variant="secondary" onClick={() => handleSubmit('saveAndAddNew')}>Simpan dan Tambah Baru</Button>
                        <Button variant="primary" onClick={() => handleSubmit('saveAndClose')}>Simpan Data</Button>
                    </>
                )}
            </>
        }
    >
      <p className="text-sm text-gray-500 mb-6">
        Masukkan informasi detail di bawah ini.
      </p>
      <div className="space-y-3 max-h-[65vh] overflow-y-auto pr-2">
        <Select 
            label="Tipe" 
            name="type" 
            value={freelancer.type} 
            onChange={handleChange} 
            options={typeOptions} 
            disabled={!!existingFreelancer}
            className={existingFreelancer ? "bg-gray-100" : ""}
        />
        <Input label="Nama Lengkap*" name="name" value={freelancer.name} onChange={handleChange} placeholder="Nama lengkap" />
        <Select label="Role*" name="role" value={freelancer.role as string} onChange={handleChange} options={roleOptions} />
        <Input label="Fee Standar / Gaji Bulanan*" name="standardFee" type="number" value={freelancer.standardFee} onChange={handleChange} placeholder={`${Currency.IDR} 0`} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <Input label="Nomor Telepon" name="phone" value={freelancer.phone} onChange={handleChange} placeholder="0812..." />
          <Input label="Email" name="email" type="email" value={freelancer.email} onChange={handleChange} placeholder="email@example.com" />
        </div>
        <Input label="Alamat (Opsional)" name="address" value={freelancer.address || ''} onChange={handleChange} placeholder="Alamat tempat tinggal"/>
        <Input label="Tanggal Bergabung (Opsional)" name="joinDate" type="date" value={freelancer.joinDate || ''} onChange={handleChange} />

        <TextArea 
            label="Catatan Ketersediaan (opsional)" 
            name="availabilityNotes" 
            value={freelancer.availabilityNotes} 
            onChange={handleChange} 
            rows={2}
            placeholder="Cth: Hanya available di akhir pekan, Full-time."
        />
         <TextArea 
            label="Peralatan Dimiliki (Opsional, satu per baris)" 
            name="equipmentNotes" 
            value={freelancer.equipmentNotes} 
            onChange={handleChange} 
            rows={3}
            placeholder="Kamera Sony A7III&#10;Lensa GM 24-70mm f2.8&#10;Drone DJI Mavic 3"
        />
        
        <div className="pt-3 mt-3 border-t">
            <h4 className="text-md font-semibold text-gray-700 mb-1">Informasi Bank (Untuk Pembayaran)</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Input label="Nama Bank" name="bankName" value={freelancer.bankName || ''} onChange={handleChange} placeholder="Cth: BCA, Mandiri"/>
                <Input label="Nomor Rekening" name="accountNumber" value={freelancer.accountNumber || ''} onChange={handleChange} placeholder="Nomor rekening bank"/>
                <Input label="Nama Pemilik Rekening" name="accountHolderName" value={freelancer.accountHolderName || ''} onChange={handleChange} placeholder="Sesuai buku tabungan"/>
            </div>
        </div>
        
        <Select label="Status" name="status" value={freelancer.status} onChange={handleChange} options={statusOptions} />
      </div>
    </Modal>
  );
};

export default AddFreelancerOrTeamModal;
