import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { Select, TextArea } from '../ui/Input';
import { Freelancer, Currency, PayFreelancerModalProps, FreelancerProject, PaymentStatus } from '../../types';
import { TRANSACTION_METHOD_OPTIONS } from '../../constants';

const PayFreelancerModal: React.FC<PayFreelancerModalProps> = ({ isOpen, onClose, onSave, freelancer, freelancerProjects, context, addToast }) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];
  
  const [paymentAmount, setPaymentAmount] = useState<string>('0'); 
  const [paymentDate, setPaymentDate] = useState<string>(getTodayDateString());
  const [paymentMethod, setPaymentMethod] = useState<string>(TRANSACTION_METHOD_OPTIONS[0] || '');
  const [notes, setNotes] = useState<string>('');
  const [selectedFreelancerProjectId, setSelectedFreelancerProjectId] = useState<string>('');

  useEffect(() => {
    if (isOpen && freelancer) {
      setPaymentDate(getTodayDateString());
      setPaymentMethod(TRANSACTION_METHOD_OPTIONS[0] || '');
      
      if (freelancer.type === 'Tim Internal') {
        setSelectedFreelancerProjectId('FEE_UMUM_INTERNAL');
        setPaymentAmount('0'); // Default to 0 for Tim Internal, user needs to input
        setNotes(`Pembayaran fee umum untuk ${freelancer.name}`);
      } else { 
        setSelectedFreelancerProjectId('');
        setPaymentAmount('0');
        setNotes(`Pembayaran fee proyek untuk ${freelancer.name}`);
      }
    }
  }, [isOpen, freelancer]);

  useEffect(() => {
    if (isOpen && freelancer) {
      if (selectedFreelancerProjectId) {
        if (selectedFreelancerProjectId === 'FEE_UMUM_INTERNAL' && freelancer.type === 'Tim Internal') {
          setPaymentAmount('0'); // Keep 0 for Tim Internal fee umum for manual input
          setNotes(`Pembayaran fee umum untuk ${freelancer.name}`);
        } else {
            const selectedFP = freelancerProjects.find(fp => fp.id === selectedFreelancerProjectId);
            if (selectedFP) {
              setPaymentAmount((selectedFP.remainingAmount || 0).toString());
              setNotes(`Pembayaran fee proyek: ${selectedFP.projectName} untuk ${freelancer.name}`);
            } else {
              if (freelancer.type === 'Freelancer Extern') {
                setPaymentAmount('0');
                setNotes(`Pembayaran fee proyek untuk ${freelancer.name}`);
              }
            }
        }
      } else {
         if (freelancer.type === 'Tim Internal') {
             setPaymentAmount('0'); 
             setNotes(`Pembayaran fee umum untuk ${freelancer.name}`);
        } else { 
            setPaymentAmount('0'); 
            setNotes(`Pembayaran fee proyek untuk ${freelancer.name}`);
        }
      }
    }
  }, [isOpen, freelancer, selectedFreelancerProjectId, freelancerProjects]);


  if (!freelancer) return null;

  const handleProjectSelectionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const projectId = e.target.value;
    setSelectedFreelancerProjectId(projectId);
  };

  const handleSubmit = () => {
    const amountValue = parseFloat(paymentAmount);
    if (isNaN(amountValue) || amountValue <= 0) { 
      addToast?.('Jumlah pembayaran fee harus lebih besar dari 0.', 'error');
      return;
    }
    
    let finalLinkedFpId = selectedFreelancerProjectId;
    if (selectedFreelancerProjectId === 'FEE_UMUM_INTERNAL' || selectedFreelancerProjectId === '') {
        finalLinkedFpId = undefined;
    }

    onSave(freelancer.id, amountValue, paymentDate, paymentMethod, notes, finalLinkedFpId);
    onClose();
  };

  const methodOptions = TRANSACTION_METHOD_OPTIONS.map(m => ({ value: m, label: m }));
  
  const availableProjects = freelancerProjects.filter(fp => fp.paymentStatus !== PaymentStatus.Paid && (fp.remainingAmount || 0) > 0);
  
  let projectAssignmentOptions = [
      { value: '', label: '-- Pilih Penugasan Proyek --' },
      ...availableProjects.map(fp => ({ 
          value: fp.id, 
          label: `${fp.projectName} (Sisa: ${Currency.IDR} ${(fp.remainingAmount || 0).toLocaleString('id-ID')})` 
      }))
  ];

  if (freelancer.type === 'Tim Internal') {
    projectAssignmentOptions.push({ value: 'FEE_UMUM_INTERNAL', label: 'Fee Umum (Tidak terkait proyek spesifik)' });
  } else if (availableProjects.length === 0) {
      projectAssignmentOptions = [{ value: '', label: 'Tidak ada proyek aktif dengan sisa tagihan' }];
  }
  
  const modalTitle = `Pembayaran Fee Proyek: ${freelancer.name}`;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={modalTitle}
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>Simpan Pembayaran</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-1">
        {freelancer.type === 'Tim Internal' ? 'Anggota Tim' : 'Freelancer'}: <span className="font-semibold">{freelancer.name}</span> ({freelancer.role})
      </p>
      <p className="text-sm text-gray-500 mb-4">
        Fee Standar Proyek (Info): <span className="font-semibold">{freelancer.standardFee != null ? `${Currency.IDR} ${freelancer.standardFee.toLocaleString('id-ID')}` : 'N/A'}</span>
      </p>
      <div className="space-y-4">
        <Select
            label="Alokasikan ke Penugasan Proyek*"
            name="selectedFreelancerProjectId"
            value={selectedFreelancerProjectId}
            onChange={handleProjectSelectionChange}
            options={projectAssignmentOptions}
            disabled={freelancer.type === 'Freelancer Extern' && availableProjects.length === 0 && selectedFreelancerProjectId !== 'FEE_UMUM_INTERNAL'}
        />
        <Input
          label="Jumlah Pembayaran*"
          name="paymentAmount"
          type="number"
          value={paymentAmount} 
          onChange={(e) => setPaymentAmount(e.target.value)}
          placeholder={`${Currency.IDR} 0`}
          disabled={freelancer.type === 'Freelancer Extern' && (!selectedFreelancerProjectId || selectedFreelancerProjectId === '')}
        />
        <Input
          label="Tanggal Pembayaran*"
          name="paymentDate"
          type="date"
          value={paymentDate}
          onChange={(e) => setPaymentDate(e.target.value)}
        />
        <Select
          label="Metode Pembayaran*"
          name="paymentMethod"
          value={paymentMethod}
          onChange={(e) => setPaymentMethod(e.target.value)}
          options={methodOptions}
          placeholder="-- Pilih Metode --"
        />
        <TextArea
          label="Catatan (Deskripsi Transaksi Otomatis)"
          name="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          placeholder={ freelancer.type === 'Tim Internal' ? `Cth: Pembayaran fee umum untuk ${freelancer.name}` : "Cth: Pembayaran termin 1 proyek X"}
        />
      </div>
    </Modal>
  );
};

export default PayFreelancerModal;