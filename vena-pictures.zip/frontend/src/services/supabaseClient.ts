// frontend/src/services/supabaseClient.ts
// This file is intentionally left empty as Supabase is no longer used.
// Firebase is now initialized and used via frontend/src/services/api.ts
export {};
