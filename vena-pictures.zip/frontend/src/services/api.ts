// frontend/src/services/api.ts
import firebase from 'firebase/compat/app'; 
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

import { firebaseConfig } from '../firebaseConfig'; // Corrected path
import { 
  Client, Project, Transaction, Freelancer, FreelancerProject, 
  Package, AddOn, UserProfile, 
  ActivityItem, Invoice, ExpenseVoucher, Task, ProjectDocument,
  BankDetail, SystemOptions, Kantong, AutoBudgetRule, ScheduledTransfer, ChatEvaluationEntry, NotificationItem, CalendarEvent
} from '../types'; // Corrected path
import { mockUser, mockSystemOptions } from '../data/mockData'; // Corrected path

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
} else {
  firebase.app(); 
}

export const auth = firebase.auth();
export const db = firebase.firestore();

// --- User Profile Functions ---
export const updateUserProfileInFirestore = async (userId: string, profileData: Partial<UserProfile>): Promise<void> => {
  const userDocRef = db.collection('users').doc(userId);
  const { id, ...dataToSet } = profileData; 
  await userDocRef.set(dataToSet, { merge: true });
};

export const getUserProfileFromFirestore = async (userId: string): Promise<UserProfile | null> => {
  const userDocRef = db.collection('users').doc(userId);
  const docSnap = await userDocRef.get();
  if (docSnap.exists) {
    return { id: docSnap.id, ...docSnap.data() } as UserProfile;
  }
  return null;
};


// Generic Firestore CRUD functions
const getCollection = <T>(collectionName: string) => db.collection(collectionName) as firebase.firestore.CollectionReference<T>;

export const fetchData = async <T>(collectionName: string): Promise<T[]> => {
  const snapshot = await getCollection<Omit<T, 'id'>>(collectionName).get();
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as T));
};

export const addData = async <T extends { id?: string }>(collectionName: string, data: Omit<T, 'id'>): Promise<T> => {
  const docRef = await getCollection<Omit<T, 'id'>>(collectionName).add(data);
  return { id: docRef.id, ...data } as T;
};

export const updateData = async <T extends { id: string }>(collectionName: string, id: string, data: Partial<Omit<T, 'id'>>): Promise<void> => {
  await getCollection<Omit<T, 'id'>>(collectionName).doc(id).update(data);
};

export const deleteData = async (collectionName: string, id: string): Promise<void> => {
  await getCollection<any>(collectionName).doc(id).delete();
};

export const setupFirestoreListener = <T>(
  collectionName: string,
  callback: (data: T[]) => void,
  queryConstraints: ((ref: firebase.firestore.CollectionReference) => firebase.firestore.Query) | null = null
): (() => void) => { 
  let query: firebase.firestore.Query = getCollection<Omit<T, 'id'>>(collectionName);
  if (queryConstraints) {
    query = queryConstraints(getCollection<Omit<T, 'id'>>(collectionName));
  }
  return query.onSnapshot(snapshot => {
    const dataList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as T));
    callback(dataList);
  }, (error) => {
    console.error(`Error listening to ${collectionName}:`, error);
    callback([]); // Send empty array on error to prevent crashes
  });
};

// User-specific sub-collection functions
export const setupUserSubCollectionListener = <T>(
  userId: string,
  subCollectionName: string,
  callback: (data: T[]) => void,
  queryConstraints: ((ref: firebase.firestore.CollectionReference) => firebase.firestore.Query) | null = null
): (() => void) => {
  if (!userId) {
    console.warn(`Cannot setup listener for ${subCollectionName}: userId is missing.`);
    callback([]); // Send empty array
    return () => {}; 
  }
  let query: firebase.firestore.Query = db.collection('users').doc(userId).collection(subCollectionName);
  if (queryConstraints) {
    query = queryConstraints(db.collection('users').doc(userId).collection(subCollectionName) as firebase.firestore.CollectionReference);
  }
  return query.onSnapshot(snapshot => {
    const dataList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as T));
    callback(dataList);
  }, (error) => {
    console.error(`Error listening to ${subCollectionName} for user ${userId}:`, error);
    callback([]); // Send empty array on error
  });
};

export const addUserSubCollectionData = async <T extends { id?: string }>(
  userId: string,
  subCollectionName: string,
  data: Omit<T, 'id'>
): Promise<T> => {
  const docRef = await db.collection('users').doc(userId).collection(subCollectionName).add(data);
  return { id: docRef.id, ...data } as T;
};

export const updateUserSubCollectionData = async <T extends { id?: string }>(
  userId: string,
  subCollectionName: string,
  id: string,
  data: Partial<Omit<T, 'id'>>
): Promise<void> => {
  await db.collection('users').doc(userId).collection(subCollectionName).doc(id).update(data);
};

export const deleteUserSubCollectionData = async (
  userId: string,
  subCollectionName: string,
  id: string
): Promise<void> => {
  await db.collection('users').doc(userId).collection(subCollectionName).doc(id).delete();
};


// --- Specific Collection Functions ---

// Clients (Top-level)
export const onClientsSnapshot = (callback: (data: Client[]) => void) => setupFirestoreListener<Client>('clients', callback);

// Projects (Top-level)
export const onProjectsSnapshot = (callback: (data: Project[]) => void) => setupFirestoreListener<Project>('projects', callback);

// Transactions (Top-level)
export const onTransactionsSnapshot = (callback: (data: Transaction[]) => void) => 
  setupFirestoreListener<Transaction>('transactions', callback, ref => ref.orderBy('date', 'desc').limit(500)); // Increased limit

// Freelancers (Top-level)
export const onFreelancersSnapshot = (callback: (data: Freelancer[]) => void) => setupFirestoreListener<Freelancer>('freelancers', callback);

// FreelancerProjects (Top-level)
export const onFreelancerProjectsSnapshot = (callback: (data: FreelancerProject[]) => void) => setupFirestoreListener<FreelancerProject>('freelancerProjects', callback);

// Kantongs (User-specific)
export const onKantongsSnapshot = (userId: string, callback: (data: Kantong[]) => void) => setupUserSubCollectionListener<Kantong>(userId, 'kantongs', callback);

// Packages (User-specific)
export const onPackagesSnapshot = (userId: string, callback: (data: Package[]) => void) => setupUserSubCollectionListener<Package>(userId, 'packages', callback);

// AddOns (User-specific)
export const onAddOnsSnapshot = (userId: string, callback: (data: AddOn[]) => void) => setupUserSubCollectionListener<AddOn>(userId, 'addOns', callback);

// BankDetails (User-specific) 
export const onBankDetailsSnapshot = (userId: string, callback: (data: BankDetail[]) => void) => setupUserSubCollectionListener<BankDetail>(userId, 'bankDetails', callback);
export const updateBankDetailsFS = async (userId: string, details: BankDetail[]): Promise<void> => {
  const collectionRef = db.collection('users').doc(userId).collection('bankDetails');
  const batch = db.batch();
  const snapshot = await collectionRef.get();
  snapshot.docs.forEach(doc => batch.delete(doc.ref));
  details.forEach(detail => {
    const docRef = detail.id && !detail.id.startsWith('new-bank-') ? collectionRef.doc(detail.id) : collectionRef.doc(); 
    batch.set(docRef, { ...detail, id: docRef.id }); 
  });
  await batch.commit();
};


// SystemOptions (User-specific document)
export const getSystemOptionsFS = async (userId: string): Promise<SystemOptions | null> => {
  const docRef = db.collection('users').doc(userId).collection('settings').doc('systemOptions');
  const docSnap = await docRef.get();
  return docSnap.exists ? docSnap.data() as SystemOptions : null;
};
export const updateSystemOptionsFS = async (userId: string, data: SystemOptions): Promise<void> => {
  await db.collection('users').doc(userId).collection('settings').doc('systemOptions').set(data, { merge: true });
};

// CalendarEvents (User-specific)
export const onCalendarEventsSnapshot = (userId: string, callback: (data: CalendarEvent[]) => void) => setupUserSubCollectionListener<CalendarEvent>(userId, 'calendarEvents', callback);

// ActivityLog (User-specific)
export const onActivityLogSnapshot = (userId: string, callback: (data: ActivityItem[]) => void) => 
  setupUserSubCollectionListener<ActivityItem>(userId, 'activityLog', callback, ref => ref.orderBy('timestamp', 'desc').limit(100));
export const addActivityLogItemFS = (userId: string, item: Omit<ActivityItem, 'id'>) => addUserSubCollectionData<ActivityItem>(userId, 'activityLog', item);

// AutoBudgetRules (User-specific)
export const onAutoBudgetRulesSnapshot = (userId: string, callback: (data: AutoBudgetRule[]) => void) => setupUserSubCollectionListener<AutoBudgetRule>(userId, 'autoBudgetRules', callback);

// ScheduledTransfers (User-specific)
export const onScheduledTransfersSnapshot = (userId: string, callback: (data: ScheduledTransfer[]) => void) => setupUserSubCollectionListener<ScheduledTransfer>(userId, 'scheduledTransfers', callback);

// ChatEvaluationEntries (User-specific)
export const onChatEvaluationEntriesSnapshot = (userId: string, callback: (data: ChatEvaluationEntry[]) => void) => setupUserSubCollectionListener<ChatEvaluationEntry>(userId, 'chatEvaluationEntries', callback);

// GeneralReceipts (User-specific)
export const onGeneralReceiptsSnapshot = (userId: string, callback: (data: Invoice[]) => void) => setupUserSubCollectionListener<Invoice>(userId, 'generalReceipts', callback);
export const addGeneralReceiptFS = (userId: string, data: Omit<Invoice, 'id'>) => addUserSubCollectionData<Invoice>(userId, 'generalReceipts', data);


// ExpenseVouchers (User-specific)
export const onExpenseVouchersSnapshot = (userId: string, callback: (data: ExpenseVoucher[]) => void) => setupUserSubCollectionListener<ExpenseVoucher>(userId, 'expenseVouchers', callback);
export const addExpenseVoucherFS = (userId: string, data: Omit<ExpenseVoucher, 'id'>) => addUserSubCollectionData<ExpenseVoucher>(userId, 'expenseVouchers', data);


// Notifications (User-specific)
export const onNotificationsSnapshot = (userId: string, callback: (data: NotificationItem[]) => void) => 
  setupUserSubCollectionListener<NotificationItem>(userId, 'notifications', callback, ref => ref.orderBy('date', 'desc').limit(50));
export const addNotificationFS = (userId: string, data: Omit<NotificationItem, 'id'>) => addUserSubCollectionData<NotificationItem>(userId, 'notifications', data);
export const updateNotificationFS = (userId: string, id: string, data: Partial<NotificationItem>) => updateUserSubCollectionData<NotificationItem>(userId, 'notifications', id, data);
export const clearAllNotificationsFS = async (userId: string): Promise<void> => {
  const snapshot = await db.collection('users').doc(userId).collection('notifications').get();
  const batch = db.batch();
  snapshot.docs.forEach(doc => batch.delete(doc.ref));
  await batch.commit();
};

// Specific logic for updating project tasks or documents (if stored as arrays within the project doc)
export const updateProjectTasksFS = async (projectId: string, tasks: Task[]): Promise<void> => {
  await db.collection('projects').doc(projectId).update({ tasks });
};
export const updateProjectDocumentsFS = async (projectId: string, documents: ProjectDocument[]): Promise<void> => {
  await db.collection('projects').doc(projectId).update({ documents });
};
