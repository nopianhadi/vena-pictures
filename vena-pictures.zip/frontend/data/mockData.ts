// frontend/data/mockData.ts
import { Client, PaymentStatus, Project, ProjectStatus, ActivityItem, Package, AddOn, Currency, FreelancerProject, Transaction, Freelancer, UserProfile, CalendarEvent, PaymentRecord, CommunicationEntry, Task, PackageType, FreelancerRole, ProjectDocument, DetailedDeliverable, Invoice, InvoiceStatus, InvoiceItem, ExpenseVoucher, Kantong, BankDetail, SystemOptions, KantongType, KANTONG_TYPES, AutoBudgetRule, ScheduledTransfer, ChatEvaluationEntry, ClientRegion, ChatChannel, ChatStatus, SystemOptionValueLabel, NotificationSettings } from '../types';
import { USER_PROFILE_DATA as constantsUserProfileData, PROJECT_STATUS_VALUES, PAYMENT_STATUS_VALUES, FREELANCER_ROLE_VALUES, PACKAGE_TYPE_VALUES, TRANSACTION_CATEGORY_OPTIONS, TRANSACTION_METHOD_OPTIONS, PROJECT_TYPE_OPTIONS, CALENDAR_EVENT_TYPE_OPTIONS, CALENDAR_EVENT_COLOR_OPTIONS, DEFAULT_AVATAR_URL } from '../constants';

// --- Date Helper ---
const formatDate = (date: Date): string => date.toISOString().split('T')[0];

const MOCK_TODAY_BASE = new Date(2025, 4, 28); // May 28, 2025 (consistent date for mock data)

const getDateRelativeToMockToday = (daysOffset: number): string => {
    const date = new Date(MOCK_TODAY_BASE);
    date.setDate(date.getDate() + daysOffset);
    return formatDate(date);
};

const generateMockId = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2,8)}`;

const initialNotificationSettings: NotificationSettings = {
  deadlineProject: true,
  deadlineTask: true,
  contractEnd: true,
  lowBalance: true,
  paymentReceived: true,
  generalReminder: true,
};

export const mockUser: UserProfile = {
    id: 'user-mock-main', 
    avatarUrl: DEFAULT_AVATAR_URL,
    fullName: 'Admin Vena (Mock)',
    email: 'admin@mock.vena.pictures',
    username: 'admin_mock',
    phone: '08123456789',
    companyName: 'Vena Pictures (Mock)',
    companyAddress: 'Jl. Mock No. 1, Mock City',
    companyPhone: '021-000-MOCK',
    companyEmail: 'info@mock.vena.pictures',
    companyWebsite: 'https://mock.vena.pictures',
    bio: 'Mock bio for Vena Pictures admin.',
    address: 'Jl. Pribadi Mock No. 1',
    website: 'https://portfolio.mock.vena.pictures',
    invoiceLogoUrl: 'https://via.placeholder.com/200x80.png?text=Vena+Mock+Logo',
    invoiceTerms: 'Mock Terms: Payment due upon receipt.',
    invoiceFooter: 'Mock Footer: Thank you!',
    notificationSettings: initialNotificationSettings,
};

export const mockBankDetails: BankDetail[] = [];
export const mockInitialPackages: Package[] = [];
export const mockInitialAddOns: AddOn[] = [];
export const mockFreelancers: Freelancer[] = [];
export const mockClients: Client[] = [];
export const mockProjects: Project[] = [];
export const mockFreelancerProjects: FreelancerProject[] = [];
export const mockTransactions: Transaction[] = [];
export const mockKantongs: Kantong[] = [];

export const mockSystemOptions: SystemOptions = {
  projectTypes: ["Wedding Photography", "Prewedding Photo", "Event Documentation", "Corporate Video", "Product Shoot", "Engagement Photo", "Dokumentasi Korporat", "Other"],
  transactionCategories: ["Pemasukan Proyek", "Fee Proyek", "Biaya Operasional", "Sewa Alat", "Transportasi", "Gaji Tim", "Pemasukan Lain", "Pengeluaran Lain", "Transfer Antar Kantong", "Setoran Tabungan Tim", "Penarikan Tabungan Tim"],
  transactionMethods: ["Transfer Bank BCA", "Transfer Bank Mandiri", "Tunai", "QRIS", "Lainnya", "Internal", "Transfer Bank BSI"],
  freelancerRoles: ["Fotografer", "Videografer", "Editor", "Editor Foto", "Editor Video", "Asisten", "Asisten Fotografer", "MUA", "Tim Internal", "Pilot Drone", "Desainer Grafis", "Admin Media Sosial"],
  packageTypes: ["Pernikahan", "Prewedding", "Lainnya", "Lamaran", "Korporat", "Acara Korporat", "Acara Pribadi", "Produk"],
  calendarEventTypes: [
    { value: 'projectClient', label: 'Acara Klien' },
    { value: 'projectDeadline', label: 'Deadline Proyek Klien' },
    { value: 'projectFreelancerMilestone', label: 'Milestone Proyek Freelancer' },
    { value: 'projectTaskDeadline', label: 'Deadline Tugas Proyek' },
    { value: 'contractReminder', label: 'Pengingat Kontrak' },
    { value: 'reminder', label: 'Pengingat Umum' },
    { value: 'meeting', label: 'Rapat' },
    { value: 'personal', label: 'Pribadi' },
    { value: 'projectFreelancer', label: 'Proyek Freelancer (Umum)' },
  ],
  clientSources: ["Instagram", "Facebook", "Rekomendasi Teman", "Website", "Pameran Wedding", "Vendor Lain"],
  clientTags: ["VIP", "Budget Terbatas", "Luar Kota", "Bridestory"],
  communicationTypes: [ {value: 'Telepon', label: 'Telepon'}, {value: 'Rapat', label: 'Rapat'}, {value: 'Email', label: 'Email'}, {value: 'WhatsApp', label: 'WhatsApp'}, {value: 'Zoom Meeting', label: 'Zoom Meeting'}, {value: 'Lainnya', label: 'Lainnya'} ],
  taskPriorities: [ {value: 'Rendah', label: 'Rendah'}, {value: 'Sedang', label: 'Sedang'}, {value: 'Tinggi', label: 'Tinggi'}],
  detailedDeliverableStatusOptions: [ {value: 'Pending', label: 'Pending'}, {value: 'Submitted', label: 'Submitted'}, {value: 'Approved', label: 'Approved'}, {value: 'Revision Needed', label: 'Revision Needed'} ], // Corrected to English
  kantongTypes: KANTONG_TYPES.map(kt => ({value: kt, label: kt})),
  clientRegions: ["Jakarta", "Bandung", "Surabaya", "Bali", "Luar Jawa", "Internasional"],
  chatChannels: ["WhatsApp Admin 1", "WhatsApp Admin 2", "Instagram DM", "Email Utama", "Telepon Kantor"],
  chatStatuses: ["Baru Masuk", "Sedang Ditangani", "Menunggu Respon Klien", "Selesai (Deal)", "Selesai (Tidak Deal)", "Follow Up Berkala"],
};

export const mockActivityLog: ActivityItem[] = [];
export const mockCalendarEvents: CalendarEvent[] = [];
export const mockScheduledTransfers: ScheduledTransfer[] = [];
export const mockAutoBudgetRules: AutoBudgetRule[] = [];
export const mockChatEvaluationEntries: ChatEvaluationEntry[] = [];
export const mockGeneralReceipts: Invoice[] = [];
export const mockExpenseVouchers: ExpenseVoucher[] = [];
